# Methodology: Clean Numerical Columns Skill

## Purpose

This skill is the second step in the AI Data Cleaning pipeline. It takes the output of the `detect-data-types` skill and applies targeted cleaning to all columns flagged as `numerical`. The output contains only those columns, cleaned and ready for analysis or further transformation.

---

## Folder Structure

```
skill/
├── detect_data_types/
│   └── output/
│       ├── <name>_copy.csv          ← input: data copy
│       └── <name>_type_flags.csv    ← input: type flags
└── clean_numerical/
    ├── clean_numerical.py
    ├── METHODOLOGY.md
    └── output/
        └── <name>_numerical.csv     ← output: cleaned numerical columns
```

---

## Inputs

| File | Source |
|---|---|
| `<name>_raw_copy.csv` | Output of `detect-data-types` skill |
| `<name>_type_flags.csv` | Output of `detect-data-types` skill |
| `<name>_type_flags_context.csv` | Output of `context-numerical` skill (optional) |

---

## Output

| File | Description |
|---|---|
| `<name>_numerical_cleaned.csv` | Only the numerical columns, with cleaned dtypes and proper missing values |

---

## Cleaning Steps

The function `clean_numerical_columns()` applies five steps to every numerical column, in order.

### Step 1 — Filter numerical columns
The type flags file is read to identify columns with `detected_type == 'numerical'`. Only those columns are loaded from the data copy.

If a `context_flags` file from the `context-numerical` skill is present it is loaded into a `{column_name: semantic_type}` map and used to drive dtype and format decisions in Step 5.

### Step 2 — Null-like token replacement
String values that represent missing data but are not encoded as proper `NaN` are replaced. The check is case-insensitive and applied after stripping whitespace.

Default token vocabulary:

| Token | Variants handled |
|---|---|
| `na`, `n/a` | Common English |
| `n.v.t.`, `nvt` | Dutch (niet van toepassing) |
| `null`, `none`, `nil`, `nan` | Programming conventions |
| `-`, `--`, `---` | Placeholder dashes |
| `?` | Unknown marker |
| `onbekend`, `unknown` | Natural language |
| `missing`, `leeg` | Explicit missing labels |
| `` (empty string) | Empty cell stored as string |

To add tokens, extend `NULL_LIKE_TOKENS` in the script.

### Step 3 — Currency symbol stripping
Leading or trailing currency symbols and ISO currency codes are removed from string values before locale parsing is attempted.

Supported formats:

| Input | Output |
|---|---|
| `€1.000,50` | `1.000,50` |
| `€ 2.500,00` | `2.500,00` |
| `EUR 750,99` | `750,99` |
| `1.000,50 €` | `1.000,50` |
| `1,000.50 USD` | `1,000.50` |

All common Unicode currency symbols are covered (`€ $ £ ¥ ₹ ₩ ₺ ₦ ₿ …`) as well as any three-letter ISO code appearing as a prefix or suffix. A `[info]` message is printed showing how many values were stripped.

This step is skipped for columns that are already a numeric dtype.

### Step 4 — Locale-aware thousands separator normalisation
Detects and normalises number strings that use a locale-specific thousands separator before handing off to numeric coercion.

Two formats are supported:

| Format | Example | Rule |
|---|---|---|
| Dutch / European | `1.000,50` | dot = thousands separator, comma = decimal point |
| US / English | `1,000.50` | comma = thousands separator, dot = decimal point |

**Detection:** up to 50 non-null string values are sampled per column and matched against strict regular expressions that require at least one full thousands group (i.e. groups of exactly 3 digits). Plain decimals like `61.2` or `999.99` do **not** match and are left untouched.

**Disambiguation:** if both formats are detected in the sample, the format with more matches wins. A `[info]` message is printed for every column where normalisation is applied.

This step is skipped for columns that are already a numeric dtype.

### Step 5 — Dtype coercion
If a column was not parsed as numeric by pandas (e.g. numbers stored as strings), it is coerced using `pd.to_numeric`. Any value that cannot be converted is set to `NaN` and a `[warn]` message is printed.

### Step 6 — Context-aware format standardisation
If a semantic context label is available (from the `context-numerical` skill), dtype and rounding decisions are made per label:

| Context label | Rule applied |
|---|---|
| `price` | `float64`, rounded to 2 decimal places |
| `count` | `Int64` (nullable integer) |
| `duration` | `float64` (never collapsed to integer) |
| `measure` | `float64` |
| `ratio` | `float64` |
| `percentage` | `float64` |
| `score` | `float64` |
| `unknown` / no context | Generic fallback: whole-number floats → `Int64`; others stay `float64` |

The generic fallback can be disabled by setting `CONVERT_WHOLE_FLOATS_TO_INT = False`.

---

## Tuning Parameters

| Constant | Default | Effect |
|---|---|---|
| `NULL_LIKE_TOKENS` | see above | Add or remove strings treated as missing values |
| `LOCALE_PARSING` | `True` | Set to `False` to disable thousands separator detection |
| `CONVERT_WHOLE_FLOATS_TO_INT` | `True` | Set to `False` to keep fallback numerics as float64 (context-driven rules are unaffected) |

---

## Known Boundary Cases

- **`aantal_uitzendingen`** (personeel_hr): context label `count` → converted to `Int64`.
- **`kosten_eur`** (onderhoud_materieel): context label `price` → stays `float64`, rounded to 2 dp.
- **`hersteltijd_uur`** (onderhoud_materieel): context label `duration` → stays `float64`, never collapsed to integer even if all values are whole numbers.
- **Mixed locale columns**: if a column contains both `1.000,50` and `1,000.50` style values, the majority format wins and a warning is printed for values that still fail coercion.
- **Plain decimals** (`61.2`, `999.99`): correctly ignored by the locale detector — the regex requires at least one full thousands group of exactly 3 digits.
- **Currency-prefixed values** (`€1.000,50`, `EUR 750,99`): Step 3 strips the symbol/code first, then the locale detector handles the remaining number string normally.
- **Three-letter ISO codes as currency prefix**: any sequence matching `[A-Z]{3}` at the start or end of a value is treated as a currency code and stripped. If a column contains genuine three-letter string codes for other reasons, disable symbol stripping for that column before calling this skill.
