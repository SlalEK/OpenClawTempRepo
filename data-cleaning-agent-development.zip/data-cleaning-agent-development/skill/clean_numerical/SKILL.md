---
name: clean-numerical
description: 'Third step in the AI Data Cleaning pipeline, runs after detect-data-types and context-numerical. Filters numerical columns from the detect_data_types output, replaces null-like tokens with proper missing values, strips currency symbols (€, $, £, EUR, USD …), normalises locale-specific thousands separators (Dutch 1.000,50 / US 1,000.50), coerces values to the correct numeric dtype, and applies context-aware format rules (price→float64 2dp, count→Int64, duration/measure/ratio/percentage/score→float64). Outputs a CSV containing only the cleaned numerical columns.'
argument-hint: 'Dataset stem name, e.g. onderhoud_materieel'
---

# Clean Numerical Columns

## Purpose
Isolate and clean all numerical columns from a dataset so they are ready for analysis or further transformation.

## Prerequisites
The `detect-data-types` skill must have been run first. Optionally run `context-numerical` before this skill to enable semantic-type-aware dtype and format rules. Inputs are read from `skill/detect_data_types/output/` and `skill/context_numerical/output/`.

## What It Does
1. **Filter** — selects only columns flagged as `numerical`; loads semantic context from `context-numerical` output if present
2. **Null-like token replacement** — converts non-standard missing value representations (`N/A`, `-`, `onbekend`, `?`, etc.) to proper `NaN`
3. **Currency symbol stripping** — removes leading/trailing currency symbols and ISO codes (`€1.000,50` → `1.000,50`, `EUR 750,99` → `750,99`)
4. **Locale-aware parsing** — normalises Dutch (`1.000,50`) and US/EN (`1,000.50`) thousands separators
5. **Dtype coercion** — ensures every column is a proper numeric type; warns if any values cannot be coerced
6. **Context-aware format standardisation** — `price`→`float64` rounded to 2 dp; `count`→`Int64`; `duration/measure/ratio/percentage/score`→`float64`; fallback: whole-number floats→`Int64`

## Procedure

### Run on all configured datasets
```bash
python skill/clean_numerical/clean_numerical.py
```

### Run on a specific dataset
```bash
python skill/clean_numerical/clean_numerical.py onderhoud_materieel
```

### Import in another skill
```python
from skill.clean_numerical import clean_numerical_columns

cleaned = clean_numerical_columns(
    copy_path='skill/detect_data_types/output/onderhoud_materieel_raw_copy.csv',
    flags_path='skill/detect_data_types/output/onderhoud_materieel_type_flags.csv',
    context_flags_path='skill/context_numerical/output/onderhoud_materieel_type_flags_context.csv',  # optional
)
```

## Inputs

| File | Source folder | Description |
|---|---|---|
| `<name>_raw_copy.csv` | `skill/detect_data_types/output/` | Unmodified data copy |
| `<name>_type_flags.csv` | `skill/detect_data_types/output/` | Column type flags |
| `<name>_type_flags_context.csv` | `skill/context_numerical/output/` | Semantic type labels (optional) |

## Output
Written to `skill/clean_numerical/output/`:

| File | Description |
|---|---|
| `<name>_numerical_cleaned.csv` | Only numerical columns, fully cleaned |

## Dependencies
```bash
pip install -r skill/clean_numerical/requirements.txt
```

## References
- [Detection logic and tuning parameters](./METHODOLOGY.md)
