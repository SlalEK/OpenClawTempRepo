"""
Clean Numerical Columns Skill
------------------------------
Reads the output of the detect_data_types skill (data copy + type flags),
filters to numerical columns only, and applies:

    1. Null-like token replacement  — common non-standard missing value
                                      representations → NaN
    2. Currency symbol stripping     — removes leading/trailing currency symbols
                                      and ISO codes (€, $, £, EUR, USD, …) so
                                      values like €1.000,50 become 1.000,50
    3. Locale-aware parsing          — thousands separators in Dutch (1.000,50)
                                      and US/EN (1,000.50) formats are normalised
    4. Dtype coercion               — ensures every column is a proper numeric type
    5. Context-aware format rules   — if a context_type_flags CSV is available:
                                        price    → float64, rounded to 2 dp
                                        count    → Int64 (nullable integer)
                                        duration / measure / ratio /
                                        percentage / score → float64
                                      Falls back to generic whole-number → Int64
                                      rule when no context is present.

Outlier detection, negative-value flagging, and missing value handling
are deferred to dedicated later skills.

Output:
    <filename>_numerical_cleaned.csv   — only the numerical columns, cleaned
"""

import pandas as pd
import numpy as np
import re
from pathlib import Path
import sys


# ── Folder layout ─────────────────────────────────────────────────────────────
# skill/clean_numerical/
#   clean_numerical.py     ← this file
#   output/                ← cleaned files land here
# skill/detect_data_types/output/   ← input files are read from here

BASE_DIR     = Path(__file__).parent
OUTPUT_DIR   = BASE_DIR / 'output'
FLAGS_DIR    = BASE_DIR.parent / 'detect_data_types' / 'output'
CONTEXT_DIR  = BASE_DIR.parent / 'context_numerical' / 'output'


# ── Tuning parameters ─────────────────────────────────────────────────────────

# Strings (case-insensitive) that represent missing values in the source data
NULL_LIKE_TOKENS = {
    'na', 'n/a', 'n.v.t.', 'nvt',
    'null', 'none', 'nil',
    'nan', '-', '--', '---',
    '?', 'onbekend', 'unknown',
    'missing', 'leeg', '',
}

# If a float column has all non-null values that are whole numbers,
# convert to pandas nullable integer (Int64)
CONVERT_WHOLE_FLOATS_TO_INT = True

# Enable locale-aware parsing of thousands separators.
# Dutch format  : 1.000,50  (dot = thousands, comma = decimal)
# US/EN format  : 1,000.50  (comma = thousands, dot = decimal)
# Detection requires at least one full thousands group (≥4-digit numbers).
LOCALE_PARSING = True

# Patterns that positively identify a thousands-separator format.
# Using + (not *) so plain decimals like 61.2 do not match.
_DUTCH_THOUSANDS = re.compile(r'^-?\d{1,3}(\.\d{3})+(,\d+)?$')
_US_THOUSANDS    = re.compile(r'^-?\d{1,3}(,\d{3})+(\.\d+)?$')

# Currency symbol / ISO-code prefix or suffix to strip.
# Symbols: €  $  £  ¥  ₹  ₩  ₺  ₴  ₦  ₫  ฿  ₭  ₮  ₱  ₲  ₵  ₡  ₢  ₣  ₤  ₥  ₧  ₨  ₪  ₯  ₰  ₳  ₶  ₷  ₸  ₾  ₿
# ISO codes (3-letter): EUR USD GBP JPY CHF CAD AUD etc.
_CURRENCY_RE = re.compile(
    r'^(?P<sym>[€$£¥₹₩₺₴₦₫฿₭₮₱₲₵₡₢₣₤₥₧₨₪₯₰₳₶₷₸₾₿]|[A-Z]{3})\s*'
    r'|'
    r'\s*(?P<sym2>[€$£¥₹₩₺₴₦₫฿₭₮₱₲₵₡₢₣₤₥₧₨₪₯₰₳₶₷₸₾₿]|[A-Z]{3})$'
)

# ── Core cleaning logic ───────────────────────────────────────────────────────

def _strip_currency_symbols(series: pd.Series, col_name: str) -> pd.Series:
    """
    Remove leading/trailing currency symbols and ISO currency codes.

    Handles:
        €1.000,50   →  1.000,50
        $ 1,000.50  →  1,000.50
        EUR 1.000,50→  1.000,50
        1.000,50 €  →  1.000,50
        1,000.50 USD→  1,000.50

    Only operates on object-dtype columns (string-represented values).
    Logs a message when at least one value was stripped.
    """
    if pd.api.types.is_numeric_dtype(series):
        return series

    stripped = series.astype(str).str.strip().str.replace(
        _CURRENCY_RE, '', regex=True
    ).str.strip()

    # Restore NaN where original was null
    null_mask = series.isna()
    stripped[null_mask] = np.nan

    changed = (~null_mask) & (stripped != series.astype(str).str.strip())
    if changed.any():
        print(f'  [info] {col_name}: currency symbol stripped from {changed.sum()} value(s)')
        return stripped
    return series


def _replace_null_like(series: pd.Series) -> pd.Series:
    """Replace null-like string tokens with NaN."""
    if series.dtype == object:
        mask = series.astype(str).str.strip().str.lower().isin(NULL_LIKE_TOKENS)
        series = series.copy()
        series[mask] = np.nan
    return series


def _normalise_locale_numbers(series: pd.Series, col_name: str) -> pd.Series:
    """
    Detect and normalise thousands-separator number formats.

    Samples up to 50 non-null string values to determine whether the column
    uses Dutch (1.000,50) or US/EN (1,000.50) formatting, then normalises
    the entire column to standard float strings.
    """
    if not LOCALE_PARSING or pd.api.types.is_numeric_dtype(series):
        return series

    str_vals = series.dropna().astype(str).str.strip()
    sample   = str_vals.head(50)

    dutch_hits = sample.str.match(_DUTCH_THOUSANDS).sum()
    us_hits    = sample.str.match(_US_THOUSANDS).sum()

    if dutch_hits == 0 and us_hits == 0:
        return series  # no locale formatting detected

    if dutch_hits >= us_hits:
        # Dutch: remove dots (thousands), replace comma with dot (decimal)
        fmt = 'Dutch (1.000,50)'
        normalised = (series.astype(str).str.strip()
                      .str.replace('.', '', regex=False)
                      .str.replace(',', '.', regex=False))
    else:
        # US/EN: remove commas (thousands), dot is already the decimal
        fmt = 'US/EN (1,000.50)'
        normalised = series.astype(str).str.strip().str.replace(',', '', regex=False)

    # Reapply NaN where the original was null
    normalised[series.isna()] = np.nan
    print(f'  [info] {col_name}: {fmt} format detected — thousands separators normalised')
    return normalised


def _coerce_to_numeric(series: pd.Series, col_name: str) -> pd.Series:
    """Coerce a column to numeric, warning if values are lost."""
    if pd.api.types.is_numeric_dtype(series):
        return series
    coerced = pd.to_numeric(series.astype(str).str.strip(), errors='coerce')
    lost = series.notna().sum() - coerced.notna().sum()
    if lost > 0:
        print(f'  [warn] {col_name}: {lost} value(s) could not be coerced to '
              f'numeric and were set to NaN')
    return coerced


def _standardise_dtype(series: pd.Series, context: str = '') -> pd.Series:
    """
    Apply context-aware dtype and format rules.

    context = 'price'                    → float64, rounded to 2 dp
    context = 'count'                    → Int64 (nullable integer)
    context in duration/measure/ratio/
              percentage/score           → float64 (never Int64)
    context = '' / 'unknown'             → generic: whole-number floats → Int64
    """
    if context == 'price':
        return series.round(2)

    if context == 'count':
        if pd.api.types.is_float_dtype(series):
            return series.astype('Int64')
        return series

    if context in ('duration', 'measure', 'ratio', 'percentage', 'score'):
        # These are always decimal-valued; never collapse to integer
        return series

    # Generic fallback: whole-number floats → Int64
    if not CONVERT_WHOLE_FLOATS_TO_INT:
        return series
    if series.dtype not in (np.float64, np.float32):
        return series
    non_null = series.dropna()
    if len(non_null) == 0:
        return series
    if (non_null % 1 == 0).all():
        return series.astype('Int64')
    return series


def clean_numerical_columns(
    copy_path: str,
    flags_path: str,
    context_flags_path: str | None = None,
) -> pd.DataFrame:
    """
    Filter, clean and standardise numerical columns.

    Parameters
    ----------
    copy_path          : path to <name>_raw_copy.csv from detect_data_types output
    flags_path         : path to <name>_type_flags.csv from detect_data_types output
    context_flags_path : (optional) path to <name>_type_flags_context.csv from
                         context_numerical output. When provided, context-aware
                         dtype and format rules are applied per column.

    Returns
    -------
    pd.DataFrame with only the cleaned numerical columns
    """
    flags    = pd.read_csv(flags_path)
    num_cols = flags[flags['detected_type'] == 'numerical']['column_name'].tolist()

    if not num_cols:
        print('  No numerical columns found — skipping.')
        return pd.DataFrame()

    # Load context map {column_name: semantic_type} if available
    context_map: dict[str, str] = {}
    if context_flags_path and Path(context_flags_path).exists():
        ctx_flags = pd.read_csv(context_flags_path)
        if 'context' in ctx_flags.columns:
            context_map = (
                ctx_flags[ctx_flags['context'].notna() & (ctx_flags['context'] != '')]
                .set_index('column_name')['context']
                .to_dict()
            )
            print(f'  [info] Context loaded: {context_map}')

    df = pd.read_csv(copy_path, usecols=num_cols)

    for col in num_cols:
        df[col] = _replace_null_like(df[col])
        df[col] = _strip_currency_symbols(df[col], col)
        df[col] = _normalise_locale_numbers(df[col], col)
        df[col] = _coerce_to_numeric(df[col], col)
        df[col] = _standardise_dtype(df[col], context=context_map.get(col, ''))

    return df


# ── Main pipeline ─────────────────────────────────────────────────────────────

def save_outputs(stem: str) -> None:
    """Run cleaning for a dataset identified by its stem name."""
    copy_path          = FLAGS_DIR   / f'{stem}_raw_copy.csv'
    flags_path         = FLAGS_DIR   / f'{stem}_type_flags.csv'
    context_flags_path = CONTEXT_DIR / f'{stem}_type_flags_context.csv'

    print(f'\n{"=" * 60}')
    print(f'Processing: {stem}')
    print('=' * 60)

    cleaned = clean_numerical_columns(
        str(copy_path), str(flags_path), str(context_flags_path)
    )

    if cleaned.empty:
        return

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    out_path = OUTPUT_DIR / f'{stem}_numerical_cleaned.csv'
    cleaned.to_csv(out_path, index=False)

    print(f'Output      → {out_path}')
    print(f'Shape       : {cleaned.shape[0]} rows × {cleaned.shape[1]} columns')
    print()
    print(cleaned.dtypes.rename('dtype').to_frame().to_string())
    print()
    print('Missing values:')
    print(cleaned.isna().sum().rename('n_missing').to_frame().to_string())


if __name__ == '__main__':
    # Usage: python clean_numerical.py [stem1 stem2 ...]
    # stem = filename without extension, e.g. onderhoud_materieel
    stems = sys.argv[1:] if len(sys.argv) > 1 else [
        'onderhoud_materieel',
        'personeel_hr',
    ]
    for stem in stems:
        save_outputs(stem)
