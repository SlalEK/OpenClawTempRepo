"""
clean-numerical skill — public API for downstream skills.

Usage
-----
    from skill.clean_numerical import clean_numerical_columns

    cleaned = clean_numerical_columns(
        copy_path='skill/detect_data_types/output/onderhoud_materieel_raw_copy.csv',
        flags_path='skill/detect_data_types/output/onderhoud_materieel_type_flags.csv',
    )
"""

from .clean_numerical import clean_numerical_columns

__all__ = ['clean_numerical_columns']
