# Skill: analyse_distribution_numerical

Analyses the distribution shape, detects anomalies, checks temporal stability, and classifies each numerical column in the cleaned dataset.

## Pipeline position

```
detect_data_types
context_numerical
clean_numerical
profile_numerical
analyse_missing_numerical
analyse_outliers_numerical      ← must run before this skill
→ analyse_distribution_numerical   ← this skill
```

> **Temporal analysis note:** The current temporal stability check uses the raw date column from `_raw_copy.csv` as a rough approximation. When the `clean_datetime` skill is available, the cleaned date column from the date/time pipeline should be passed instead as `raw_copy_path`. Always run `clean_datetime` before this skill for accurate temporal analysis.

## Inputs

| File | Source skill | Required | Purpose |
|------|-------------|----------|---------|
| `<stem>_numerical_cleaned.csv` | `clean_numerical` | ✅ Required | Values to analyse |
| `<stem>_outlier_flags.csv` | `analyse_outliers_numerical` | ⚠️ Strongly recommended | Exclude `invalid` and `suspicious` outliers from shape analysis |
| `<stem>_type_flags_context.csv` | `context_numerical` | Optional | Context-aware severity overrides |
| `<stem>_raw_copy.csv` | `detect_data_types` | Optional | Date column for temporal stability (replace with clean datetime output once available) |

> **Outlier exclusion policy (all classes excluded):**
> - `invalid` — excluded (domain violations).
> - `suspicious` — excluded (statistical outliers in the extreme tail).
> - `structural` — excluded (sentinel values that produce artificial spikes).
> - `legitimate` — **excluded** (genuine extreme values are still removed so the distribution describes the non-outlier core of the data).
>
> Only rows with **no outlier flag** contribute to shape statistics and the histogram.

## Outputs

| File | Description |
|------|-------------|
| `<stem>_distribution_temporal.csv` | One row per column per time window — period, n, median, std, Q1, Q3, shift flag |
| `<stem>_distribution_summary.csv` | One row per column with shape metrics and overall class |
| `<stem>_distribution_report.html` | Self-contained HTML report with SVG histograms and temporal charts |

## Classification labels

| Class | Meaning |
|-------|---------|
| `data_quality_issue` | Truncation, unexpected zero-inflation, spike (dominant single value) |
| `suspicious` | Bimodal distribution, extreme skew (non-natural context), temporal shift |
| `legitimate` | Right-skew / zero-inflation that is natural for the column's context |
| `no_issue` | Normal-like or minor variation — no action needed |

## Usage

```python
from skill.analyse_distribution_numerical.analyse_distribution_numerical import (
    analyse_distribution, render_html, save_outputs,
)

# High-level: run and write all outputs
save_outputs("onderhoud_materieel")

# Low-level: programmatic access
temporal_df, summary_df, meta, col_details = analyse_distribution(
    cleaned_path="skill/clean_numerical/output/onderhoud_materieel_numerical_cleaned.csv",
    outlier_flags_path="skill/analyse_outliers_numerical/output/onderhoud_materieel_outlier_flags.csv",
    context_flags_path="skill/context_numerical/output/onderhoud_materieel_type_flags_context.csv",
    raw_copy_path="skill/detect_data_types/output/onderhoud_materieel_raw_copy.csv",
)
```

## CLI

```bash
python -m skill.analyse_distribution_numerical.analyse_distribution_numerical
python -m skill.analyse_distribution_numerical.analyse_distribution_numerical onderhoud_materieel
```

## Anomaly types detected

| Anomaly type | Default class | Context override |
|---|---|---|
| `truncation_high` | `data_quality_issue` | — |
| `truncation_low` | `data_quality_issue` | — |
| `zero_inflation` | `data_quality_issue` | `count` context → `legitimate` |
| `spike` | `data_quality_issue` | — |
| `right_skew` | `suspicious` | `amount/cost/price/duration/count` → `legitimate` |
| `left_skew` | `suspicious` | — |
| `heavy_tail` | `suspicious` | `amount/cost/price/duration/count` → `legitimate` |
| `bimodal` | `suspicious` | — |
| `temporal_shift` | `suspicious` | — |

## Histogram colour coding

| Colour | Meaning |
|--------|---------|
| Indigo (#5c6bc0) | Normal bins (includes legitimate outliers) |
| Amber (#f57f17) | Bin contains a detected spike value |
| Red (#c62828) | Truncation boundary bin |

_Note: invalid, suspicious, and structural outlier rows are all removed before the histogram is built and do not appear in any bin._
