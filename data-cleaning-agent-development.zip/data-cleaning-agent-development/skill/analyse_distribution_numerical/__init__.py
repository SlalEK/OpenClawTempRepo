"""
Analyse Distribution — Numerical Columns
-----------------------------------------
Seventh step in the AI Data Cleaning pipeline.

Usage
-----
from skill.analyse_distribution_numerical.analyse_distribution_numerical import (
    analyse_distribution, render_html, save_outputs,
)

temporal_df, summary_df, meta, col_details = analyse_distribution(...)
    cleaned_path,
    outlier_flags_path=...,   # optional
    context_flags_path=...,   # optional
    raw_copy_path=...,        # optional – for temporal analysis
)
"""
from .analyse_distribution_numerical import analyse_distribution, render_html, save_outputs

__all__ = ["analyse_distribution", "render_html", "save_outputs"]
