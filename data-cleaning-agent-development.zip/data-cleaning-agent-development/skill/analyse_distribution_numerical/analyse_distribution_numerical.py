"""
Analyse Distribution — Numerical Columns
-----------------------------------------
Analyses the shape, anomalies, and temporal stability of every numerical column
that has been cleaned by clean_numerical.

Pipeline position
-----------------
    detect_data_types
    context_numerical
    analyse_missing_numerical
    analyse_outliers_numerical
    clean_numerical
    profile_numerical
 →  analyse_distribution_numerical   ← this skill

Inputs
------
    <stem>_numerical_cleaned.csv        from clean_numerical/output/        (required)
    <stem>_outlier_flags.csv            from analyse_outliers_numerical/output/ (optional)
    <stem>_type_flags_context.csv       from context_numerical/output/      (optional)
    <stem>_raw_copy.csv                 from detect_data_types/output/      (optional, for temporal)

Outputs
-------
    <stem>_distribution_flags.csv       one row per detected anomaly
    <stem>_distribution_summary.csv     one row per column
    <stem>_distribution_report.html     self-contained HTML report with histograms
"""

import math
import sys
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd
from jinja2 import BaseLoader, Environment

# ── Folder layout ──────────────────────────────────────────────────────────────
BASE_DIR     = Path(__file__).parent
OUTPUT_DIR   = BASE_DIR / "output"
INPUT_DIR    = BASE_DIR.parent / "clean_numerical" / "output"
OUTLIER_DIR  = BASE_DIR.parent / "analyse_outliers_numerical" / "output"
CONTEXT_DIR  = BASE_DIR.parent / "context_numerical" / "output"
RAW_DIR      = BASE_DIR.parent / "detect_data_types" / "output"

STEMS = ["onderhoud_materieel", "personeel_hr"]

# ── Tuning parameters ──────────────────────────────────────────────────────────
SKEWNESS_MODERATE         = 0.5    # |skew| > this → moderate skew
SKEWNESS_HIGH             = 1.5    # |skew| > this → high skew
KURTOSIS_HEAVY_TAIL       = 4.0    # absolute kurtosis > this → heavy-tailed
KURTOSIS_LIGHT_TAIL       = 2.0    # absolute kurtosis < this → light-tailed
ZERO_INFLATION_THRESHOLD  = 0.30   # >30% zeros (non-count) → zero-inflation
ZERO_INFLATION_COUNT      = 0.80   # >80% zeros (count)     → zero-inflation
SPIKE_FREQ_THRESHOLD      = 0.10   # single value > 10% of valid values → spike
TRUNCATION_PILE_THRESHOLD = 0.02   # >2% of values at the exact max/min → truncation
BIMODAL_VALLEY_RATIO      = 0.30   # valley < 30% of shorter peak → bimodal confirmed
MIN_SAMPLE                = 10     # skip detailed analysis below this
MIN_TEMPORAL_WINDOW       = 30     # minimum rows per time window
TEMPORAL_SHIFT_MAD_MULT   = 3.0    # median shift > N × overall_MAD → flag

# Contexts whose right-skew is naturally expected (no alarm)
NATURALLY_SKEWED_CONTEXTS = {"amount", "cost", "price", "duration", "count"}


# ── Histogram helpers (mirrored from profile_numerical) ────────────────────────
def _fmt_tick(v: float) -> str:
    if v == int(v) and abs(v) < 1_000_000:
        return str(int(v))
    return f"{v:.3g}"


def _nice_ticks(lo: float, hi: float, n: int = 5) -> list:
    if lo == hi:
        return [lo]
    span = hi - lo
    raw_step = span / max(n - 1, 1)
    magnitude = 10 ** math.floor(math.log10(abs(raw_step)))
    step = magnitude
    for nice in (1, 2, 2.5, 5, 10):
        if nice * magnitude >= raw_step:
            step = nice * magnitude
            break
    start = math.ceil(lo / step) * step
    ticks, v = [], start
    while v <= hi + step * 0.01:
        ticks.append(round(v, 10))
        v = round(v + step, 10)
    return ticks


def _histogram_data(
    series: pd.Series,
    n_bins: int = 20,
    lo: float | None = None,
    hi: float | None = None,
    spike_values: set | None = None,
    structural_values: set | None = None,
    truncated_high: bool = False,
    truncated_low: bool = False,
) -> dict:
    """Return histogram bins dict ready for the Jinja template.

    Each bin has: label, left, right, count, color
    color: 'normal' | 'spike' | 'structural' | 'truncation'
    """
    clean = series.dropna().astype(float)
    if len(clean) == 0:
        return {"bins": [], "ticks": []}

    actual_lo = lo if lo is not None else float(clean.min())
    actual_hi = hi if hi is not None else float(clean.max())

    if actual_lo == actual_hi:
        return {
            "bins": [
                {
                    "label": _fmt_tick(actual_lo),
                    "left": actual_lo,
                    "right": actual_lo,
                    "count": int(len(clean)),
                    "color": "normal",
                }
            ],
            "ticks": [{"x_frac": 0.5, "label": _fmt_tick(actual_lo)}],
        }

    clipped = clean.clip(actual_lo, actual_hi)
    counts, edges = np.histogram(clipped, bins=n_bins, range=(actual_lo, actual_hi))

    spike_vals  = spike_values or set()
    struct_vals = structural_values or set()
    max_bin_idx = len(counts) - 1

    def _bin_color(i: int, left: float, right: float) -> str:
        # Note: structural rows are excluded from the series before this is
        # called, so the 'structural' color case is intentionally absent.
        if truncated_high and i == max_bin_idx:
            return "truncation"
        if truncated_low and i == 0:
            return "truncation"
        if any(left <= v <= right for v in spike_vals):
            return "spike"
        return "normal"

    bins = []
    for i in range(len(counts)):
        bins.append(
            {
                "label": f"{_fmt_tick(edges[i])}–{_fmt_tick(edges[i + 1])}",
                "left": float(edges[i]),
                "right": float(edges[i + 1]),
                "count": int(counts[i]),
                "color": _bin_color(i, float(edges[i]), float(edges[i + 1])),
            }
        )

    span = actual_hi - actual_lo
    ticks = [
        {
            "x_frac": round(min(1.0, max(0.0, (v - actual_lo) / span)), 6),
            "label": _fmt_tick(v),
        }
        for v in _nice_ticks(actual_lo, actual_hi, n=5)
        if actual_lo - span * 0.001 <= v <= actual_hi + span * 0.001
    ]
    return {"bins": bins, "ticks": ticks}


# ── Data loading ───────────────────────────────────────────────────────────────
def _load_context_map(path) -> dict:
    if path is None or not Path(path).exists():
        return {}
    df = pd.read_csv(path)
    if "column_name" not in df.columns or "context" not in df.columns:
        return {}
    return {
        str(row["column_name"]): str(row["context"])
        for _, row in df.iterrows()
        if pd.notna(row["context"])
    }


def _load_outlier_info(flags_path) -> tuple:
    """Return (exclude_map, structural_map) keyed by column name.

    exclude_map:    col -> set of row indices classified as 'invalid' or 'suspicious'.
                    Both are removed before distribution shape analysis so that
                    domain violations and statistical outliers do not distort the
                    distribution metrics.  'legitimate' and 'structural' rows are
                    kept: structural sentinels are kept because they produce visible
                    spikes in the histogram and are highlighted in a separate colour;
                    legitimate outliers are genuine extreme values that belong to
                    the natural distribution.
    structural_map: col -> set of values classified as 'structural' (value set
                    retained for the spike-detector guard only).
    Note: ALL outlier classes are excluded from shape analysis — invalid,
    suspicious, structural, and legitimate. Only non-flagged rows remain.
    """
    if flags_path is None or not Path(flags_path).exists():
        return {}, {}
    try:
        df = pd.read_csv(flags_path)
    except Exception:
        return {}, {}
    exclude_map: dict = {}
    structural_map: dict = {}
    for _, row in df.iterrows():
        col = str(row["column_name"])
        # Exclude ALL outlier classes from shape analysis.
        # Even legitimate outliers (genuine extreme values) are removed so that
        # the distribution describes the core data, unaffected by any flagged row.
        if row.get("outlier_class") in ("invalid", "suspicious", "structural", "legitimate"):
            exclude_map.setdefault(col, set()).add(int(row["row_index"]))
        if row.get("outlier_class") == "structural":
            try:
                structural_map.setdefault(col, set()).add(float(row["value"]))
            except (ValueError, TypeError):
                pass
    return exclude_map, structural_map


def _detect_date_column(df: pd.DataFrame):
    """Return the name of the first column that looks like a date series.

    Uses format='mixed' to handle the varied Dutch date formats
    (DD-MM-YYYY, YYYY/MM/DD, DD/MM/YYYY, etc.) that appear in practice.
    Requires ≥ 50% of non-null values to parse successfully.
    """
    date_hints = ("datum", "date", "tijd", "time", "jaar", "year", "month", "maand")

    def _parse_rate(series):
        try:
            parsed = pd.to_datetime(series, errors="coerce", format="mixed", dayfirst=True)
            return parsed.notna().mean()
        except Exception:
            try:
                parsed = pd.to_datetime(series, errors="coerce", dayfirst=True)
                return parsed.notna().mean()
            except Exception:
                return 0.0

    for col in df.columns:
        if any(h in col.lower() for h in date_hints):
            if _parse_rate(df[col]) >= 0.50:
                return col

    for col in df.select_dtypes(include=["object", "str"]).columns:
        if _parse_rate(df[col]) >= 0.50:
            return col

    return None


# ── Shape helpers ──────────────────────────────────────────────────────────────
def _detect_modality(counts: list) -> str:
    """Detect unimodal / bimodal / multimodal from bin counts."""
    if len(counts) < 5:
        return "unimodal"
    max_count = max(counts)
    if max_count == 0:
        return "unimodal"
    n = len(counts)
    smoothed = [
        (counts[max(0, i - 1)] + counts[i] + counts[min(n - 1, i + 1)]) / 3.0
        for i in range(n)
    ]
    threshold = max(smoothed) * 0.10
    peaks = [
        i
        for i in range(1, n - 1)
        if smoothed[i] > smoothed[i - 1]
        and smoothed[i] > smoothed[i + 1]
        and smoothed[i] > threshold
    ]
    if len(peaks) < 2:
        return "unimodal"
    top_peaks = sorted(peaks, key=lambda i: -smoothed[i])[:2]
    p1, p2 = min(top_peaks), max(top_peaks)
    valley = min(smoothed[p1 : p2 + 1])
    if (
        valley < smoothed[p1] * BIMODAL_VALLEY_RATIO
        and valley < smoothed[p2] * BIMODAL_VALLEY_RATIO
    ):
        return "multimodal" if len(peaks) >= 3 else "bimodal"
    return "unimodal"


def _is_round_boundary(v: float) -> bool:
    """True if v looks like an artificial cap (100, 1000, 9999 …)."""
    if v != math.floor(v):
        return False
    n = int(v)
    if n <= 0:
        return False
    for base in (100, 1000, 10_000, 100_000):
        if n % base == 0:
            return True
    s = str(n)
    if len(s) >= 2 and all(c == "9" for c in s):
        return True
    return False


def _shape_label(skew: float, kurt: float, modality: str) -> str:
    if modality in ("bimodal", "multimodal"):
        return modality
    if abs(skew) < SKEWNESS_MODERATE and KURTOSIS_LIGHT_TAIL <= kurt <= KURTOSIS_HEAVY_TAIL:
        return "normal_like"
    if skew > SKEWNESS_HIGH:
        return "right_skewed_high"
    if skew > SKEWNESS_MODERATE:
        return "right_skewed"
    if skew < -SKEWNESS_HIGH:
        return "left_skewed_high"
    if skew < -SKEWNESS_MODERATE:
        return "left_skewed"
    if kurt > KURTOSIS_HEAVY_TAIL:
        return "heavy_tailed"
    if kurt < KURTOSIS_LIGHT_TAIL:
        return "light_tailed"
    return "normal_like"


# ── Temporal stability ─────────────────────────────────────────────────────────
def _temporal_stability(
    series: pd.Series,
    timestamps: pd.Series,
) -> tuple:
    """Window-based median shift detection (no scipy required).

    Returns (anomalies: list[dict], window_records: list[dict]).
    """
    anomalies: list = []
    window_records: list = []

    ts = timestamps.copy()
    ts.index = series.index

    valid_mask = series.notna() & ts.notna()
    s = series[valid_mask].astype(float)
    t = ts[valid_mask]

    if len(s) < MIN_TEMPORAL_WINDOW * 2:
        return anomalies, window_records

    try:
        t_parsed = pd.to_datetime(t, errors="coerce", format="mixed", dayfirst=True)
    except Exception:
        try:
            t_parsed = pd.to_datetime(t, errors="coerce", dayfirst=True)
        except Exception:
            return anomalies, window_records

    if t_parsed.notna().mean() < 0.5:
        return anomalies, window_records

    s_df = pd.DataFrame({"val": s.values, "ts": t_parsed.values})
    s_df["ts"] = pd.to_datetime(s_df["ts"])

    for freq, label in (("ME", "month"), ("QE", "quarter")):
        s_df["window"] = s_df["ts"].dt.to_period(freq[0]).astype(str)
        groups = s_df.groupby("window")["val"].apply(list)
        groups = groups[groups.apply(len) >= MIN_TEMPORAL_WINDOW]
        if len(groups) >= 2:
            break
    else:
        return anomalies, window_records

    overall_vals = s.values.astype(float)
    overall_median = float(np.median(overall_vals))
    overall_mad = float(np.median(np.abs(overall_vals - overall_median))) or 1.0
    threshold = TEMPORAL_SHIFT_MAD_MULT * overall_mad

    for period, vals in groups.items():
        arr = np.array(vals, dtype=float)
        median = float(np.median(arr))
        window_records.append(
            {
                "period": period,
                "n": len(arr),
                "median": round(median, 3),
                "std": round(float(np.std(arr)), 3),
                "q1": round(float(np.percentile(arr, 25)), 3),
                "q3": round(float(np.percentile(arr, 75)), 3),
                "shift": abs(median - overall_median) > threshold,
            }
        )

    shifted = [w for w in window_records if w["shift"]]
    if shifted:
        shown = ", ".join(w["period"] for w in shifted[:3])
        extra = f" (+{len(shifted) - 3} more)" if len(shifted) > 3 else ""
        anomalies.append(
            {
                "anomaly_type": "temporal_shift",
                "severity": "suspicious",
                "detail": (
                    f"Distribution median shifts significantly from the overall median "
                    f"({overall_median:.3g}) in {len(shifted)} window(s): {shown}{extra}. "
                    f"Threshold: ±{threshold:.3g} ({TEMPORAL_SHIFT_MAD_MULT}×MAD)."
                ),
                "mitigation": (
                    "Investigate changes in data collection, measurement methodology, or "
                    "seasonal effects around the flagged periods. If systematic, consider "
                    "period-specific normalisation or stratified modelling."
                ),
            }
        )

    return anomalies, window_records


# ── Temporal chart data ───────────────────────────────────────────────────────
def _temporal_chart_data(window_records: list, overall_median: float) -> dict:
    """Compute SVG rendering coordinates for the temporal stability chart.

    Enriches each window_record in-place with:
        svg_x        -- x centre of the period's marker
        svg_med_y    -- SVG y of the median dot
        svg_q1_y     -- SVG y of the Q1 tick
        svg_q3_y     -- SVG y of the Q3 tick
        show_label   -- whether to render the period label on the X axis

    Returns a chart metadata dict consumed by the Jinja template.
    """
    if not window_records:
        return {}

    CHART_W = 472
    CHART_H = 110
    LEFT_M  = 52        # pixels reserved for Y-axis labels
    PLOT_W  = CHART_W - LEFT_M - 8

    all_q1 = [w["q1"]     for w in window_records]
    all_q3 = [w["q3"]     for w in window_records]

    y_raw_lo = min(all_q1 + [overall_median])
    y_raw_hi = max(all_q3 + [overall_median])
    pad      = (y_raw_hi - y_raw_lo) * 0.15 or 1.0
    y_lo     = y_raw_lo - pad
    y_hi     = y_raw_hi + pad

    def _to_y(v: float) -> float:
        frac = (v - y_lo) / (y_hi - y_lo)
        return round(CHART_H * (1.0 - frac), 2)

    n          = len(window_records)
    bar_slot   = round(PLOT_W / n, 3)
    bw         = round(max(bar_slot * 0.55, 4.0), 2)
    label_step = max(1, n // 8)   # at most ~8 visible X-axis labels

    for i, w in enumerate(window_records):
        x_center        = round(LEFT_M + (i + 0.5) * bar_slot, 2)
        w["svg_x"]      = x_center
        w["svg_med_y"]  = _to_y(w["median"])
        w["svg_q1_y"]   = _to_y(w["q1"])
        w["svg_q3_y"]   = _to_y(w["q3"])
        w["show_label"] = (i % label_step == 0) or (i == n - 1)

    y_ticks = _nice_ticks(y_lo, y_hi, n=5)
    ticks   = [
        {"label": _fmt_tick(v), "y": _to_y(v)}
        for v in y_ticks
        if y_lo - pad * 0.1 <= v <= y_hi + pad * 0.1
    ]
    polyline_pts = " ".join(f"{w['svg_x']},{w['svg_med_y']}" for w in window_records)

    return {
        "chart_w":        CHART_W,
        "chart_h":        CHART_H,
        "left_m":         LEFT_M,
        "bw":             bw,
        "overall_med_y":  _to_y(overall_median),
        "overall_median": round(overall_median, 4),
        "y_ticks":        ticks,
        "n":              n,
        "polyline_pts":   polyline_pts,
    }


# ── Column analysis ────────────────────────────────────────────────────────────
def _analyse_column(
    col: str,
    series: pd.Series,
    context: str,
    invalid_indices: set,
    structural_values: set,
    timestamps=None,
) -> tuple:
    """Return (stats_dict, anomalies, window_records)."""
    all_valid = series.dropna()
    n_all = len(all_valid)

    # Mask out invalid- and suspicious-flagged rows for shape analysis.
    # Legitimate outliers are intentionally kept — they belong to the natural
    # distribution tail and should not be hidden from shape metrics.
    clean = series.copy()
    if invalid_indices:
        clean.loc[list(invalid_indices)] = np.nan
    clean_vals = clean.dropna().astype(float)
    n_clean = len(clean_vals)

    anomalies: list = []
    window_records: list = []
    spike_vals_for_hist: set = set()
    truncation_high = False
    truncation_low = False

    if n_clean < 2:
        stats = {
            "column_name": col,
            "context": context,
            "n_valid": n_all,
            "n_clean": n_clean,
            "n_excluded": n_all - n_clean,
            "mean": None,
            "median": None,
            "std": None,
            "min": None,
            "max": None,
            "p05": None,
            "p25": None,
            "p75": None,
            "p95": None,
            "skewness": None,
            "kurtosis": None,
            "zeros_pct": None,
            "shape": "insufficient_data",
            "modality": "unknown",
            "overall_class": "no_issue",
            "n_anomalies": 0,
            "histogram": {"bins": [], "ticks": []},
            "anomalies": [],
            "window_records": [],
            "temporal_chart": {},
        }
        return stats, anomalies, window_records

    arr = clean_vals.values
    mean = float(np.mean(arr))
    med  = float(np.median(arr))
    std  = float(np.std(arr, ddof=1)) if n_clean > 1 else 0.0
    vmin = float(np.min(arr))
    vmax = float(np.max(arr))
    p05  = float(np.percentile(arr, 5))
    p25  = float(np.percentile(arr, 25))
    p75  = float(np.percentile(arr, 75))
    p95  = float(np.percentile(arr, 95))
    skew = float(clean_vals.skew())
    kurt = float(clean_vals.kurtosis() + 3.0)  # pandas returns excess kurtosis; +3 → absolute
    zeros_n   = int((clean_vals == 0).sum())
    zeros_pct = round(zeros_n / n_clean * 100, 2) if n_clean > 0 else 0.0

    # Modality
    hist_raw   = _histogram_data(clean_vals, n_bins=20)
    bin_counts = [b["count"] for b in hist_raw.get("bins", [])]
    modality   = _detect_modality(bin_counts)
    shape      = _shape_label(skew, kurt, modality)

    # ── Shape anomalies ────────────────────────────────────────────────────────
    if modality in ("bimodal", "multimodal"):
        anomalies.append(
            {
                "anomaly_type": "bimodal",
                "severity": "suspicious",
                "detail": (
                    f"Distribution appears {modality} "
                    f"(skewness={skew:.2f}, kurtosis={kurt:.2f}). "
                    "Two or more distinct peaks detected in the histogram."
                ),
                "mitigation": (
                    "Investigate whether multiple sub-populations are mixed "
                    "(e.g. different equipment types, job roles, or measurement methods). "
                    "Consider stratifying the analysis by a relevant categorical variable."
                ),
            }
        )

    elif shape in ("right_skewed_high", "right_skewed"):
        sev = (
            "legitimate"
            if context in NATURALLY_SKEWED_CONTEXTS
            else ("suspicious" if shape == "right_skewed_high" else "no_issue")
        )
        if sev != "no_issue":
            anomalies.append(
                {
                    "anomaly_type": "right_skew",
                    "severity": sev,
                    "detail": (
                        f"Right-skewed distribution (skewness={skew:.2f}). "
                        "Values concentrate near the lower end with a long upper tail."
                    ),
                    "mitigation": (
                        "Natural for this column type. "
                        "Consider log-transform before linear modelling."
                    )
                    if sev == "legitimate"
                    else (
                        "Investigate cause. Check for data-entry errors at the high end. "
                        "Consider log or square-root transform before modelling."
                    ),
                }
            )

    elif shape in ("left_skewed_high", "left_skewed"):
        sev = "suspicious" if shape == "left_skewed_high" else "no_issue"
        if sev != "no_issue":
            anomalies.append(
                {
                    "anomaly_type": "left_skew",
                    "severity": sev,
                    "detail": (
                        f"Left-skewed distribution (skewness={skew:.2f}). "
                        "Values concentrate near the upper end with a long lower tail."
                    ),
                    "mitigation": (
                        "Investigate cause. Check for floor effects or censoring at the low end."
                    ),
                }
            )

    elif shape == "heavy_tailed":
        sev = "legitimate" if context in NATURALLY_SKEWED_CONTEXTS else "suspicious"
        anomalies.append(
            {
                "anomaly_type": "heavy_tail",
                "severity": sev,
                "detail": (
                    f"Heavy-tailed distribution (kurtosis={kurt:.2f} > {KURTOSIS_HEAVY_TAIL}). "
                    "More extreme values than expected under normality."
                ),
                "mitigation": (
                    "Natural for this column type. Prefer robust statistics "
                    "(median, MAD) over mean/std."
                )
                if sev == "legitimate"
                else (
                    "Consider Winsorization or log-transform. "
                    "Extreme values may distort mean-based models."
                ),
            }
        )

    # ── Zero-inflation ─────────────────────────────────────────────────────────
    if zeros_n > 0:
        threshold = (
            ZERO_INFLATION_COUNT if context == "count" else ZERO_INFLATION_THRESHOLD
        )
        if zeros_pct / 100.0 > threshold:
            sev = "legitimate" if context == "count" else "data_quality_issue"
            anomalies.append(
                {
                    "anomaly_type": "zero_inflation",
                    "severity": sev,
                    "detail": (
                        f"{zeros_pct}% of valid values are exactly 0 "
                        f"(threshold for {context or 'this'} context: {threshold*100:.0f}%)."
                    ),
                    "mitigation": (
                        "High zero rate is natural for count data. "
                        "Verify zeros represent genuine 'no events', not missing values."
                    )
                    if sev == "legitimate"
                    else (
                        "High proportion of zeros in a non-count column. "
                        "Verify whether zeros represent true measurements or "
                        "are used as a missing-value proxy."
                    ),
                }
            )

    # ── Truncation (pile-up at boundary) ──────────────────────────────────────
    if n_clean >= MIN_SAMPLE:
        pct_at_max = float((clean_vals == vmax).sum()) / n_clean
        pct_at_min = float((clean_vals == vmin).sum()) / n_clean

        if pct_at_max > TRUNCATION_PILE_THRESHOLD and _is_round_boundary(vmax):
            truncation_high = True
            spike_vals_for_hist.add(vmax)
            anomalies.append(
                {
                    "anomaly_type": "truncation_high",
                    "severity": "data_quality_issue",
                    "detail": (
                        f"{pct_at_max*100:.1f}% of values equal the maximum "
                        f"({_fmt_tick(vmax)}), which is a round boundary. "
                        "Possible database cap or entry limit."
                    ),
                    "mitigation": (
                        f"Investigate whether values above {_fmt_tick(vmax)} exist but are capped. "
                        "Consult the data owner about the true upper bound; "
                        "consider marking capped values explicitly as NaN."
                    ),
                }
            )

        if (
            pct_at_min > TRUNCATION_PILE_THRESHOLD
            and _is_round_boundary(vmin)
            and vmin != 0.0
        ):
            truncation_low = True
            anomalies.append(
                {
                    "anomaly_type": "truncation_low",
                    "severity": "data_quality_issue",
                    "detail": (
                        f"{pct_at_min*100:.1f}% of values equal the minimum "
                        f"({_fmt_tick(vmin)}), which is a round boundary. "
                        "Possible lower cap or entry constraint."
                    ),
                    "mitigation": (
                        f"Investigate whether values below {_fmt_tick(vmin)} exist but are capped. "
                        "Consult the data owner about the intended minimum value."
                    ),
                }
            )

    # ── Spike (dominant single value inside distribution) ─────────────────────
    if n_clean >= MIN_SAMPLE:
        n_distinct = clean_vals.nunique()
        expected_uniform_frac = 1.0 / max(n_distinct, 1)
        # Spike only if value appears well above the expected uniform frequency.
        # Threshold: max(SPIKE_FREQ_THRESHOLD, 2.5 × expected_uniform_frac).
        # This prevents integer columns with few distinct values (e.g. 0-8)
        # from being flagged when the distribution is simply near-uniform.
        spike_min_frac = max(SPIKE_FREQ_THRESHOLD, 2.5 * expected_uniform_frac)
        value_counts = clean_vals.value_counts(normalize=True)
        for val, frac in value_counts.items():
            if frac >= spike_min_frac and float(val) not in structural_values:
                spike_vals_for_hist.add(float(val))
                anomalies.append(
                    {
                        "anomaly_type": "spike",
                        "severity": "data_quality_issue",
                        "detail": (
                            f"Value {_fmt_tick(float(val))} accounts for "
                            f"{frac*100:.1f}% of valid values "
                            f"({frac/expected_uniform_frac:.1f}× expected uniform frequency). "
                            "A dominant single value suggests a default, "
                            "rounding artefact, or sentinel."
                        ),
                        "mitigation": (
                            f"Verify whether {_fmt_tick(float(val))} is a genuine measurement, "
                            "a data-entry default, or a proxy for 'unknown'. "
                            "If a proxy, replace with NaN."
                        ),
                    }
                )

    # ── Temporal stability ─────────────────────────────────────────────────────
    temporal_chart: dict = {}
    if timestamps is not None and n_clean >= MIN_TEMPORAL_WINDOW * 2:
        temp_anomalies, window_records = _temporal_stability(clean, timestamps)
        anomalies.extend(temp_anomalies)
        if window_records:
            temporal_chart = _temporal_chart_data(window_records, med)

    # ── Overall class ──────────────────────────────────────────────────────────
    severity_order = ["data_quality_issue", "suspicious", "legitimate", "no_issue"]
    classes_present = {a["severity"] for a in anomalies}
    overall_class = "no_issue"
    for cls in severity_order:
        if cls in classes_present:
            overall_class = cls
            break

    # ── Build coloured histogram ───────────────────────────────────────────────
    histogram = _histogram_data(
        clean_vals,
        n_bins=20,
        spike_values=spike_vals_for_hist,
        structural_values=structural_values,
        truncated_high=truncation_high,
        truncated_low=truncation_low,
    )

    stats = {
        "column_name":        col,
        "context":            context,
        "n_valid":            n_all,
        "n_clean":            n_clean,
        "n_excluded": n_all - n_clean,
        "mean":       round(mean, 4),
        "median":             round(med, 4),
        "std":                round(std, 4),
        "min":                round(vmin, 4),
        "max":                round(vmax, 4),
        "p05":                round(p05, 4),
        "p25":                round(p25, 4),
        "p75":                round(p75, 4),
        "p95":                round(p95, 4),
        "skewness":           round(skew, 4),
        "kurtosis":           round(kurt, 4),
        "zeros_pct":          zeros_pct,
        "shape":              shape,
        "modality":           modality,
        "overall_class":      overall_class,
        "n_anomalies":        len(anomalies),
        "histogram":          histogram,
        "anomalies":          anomalies,
        "window_records":     window_records,
        "temporal_chart":     temporal_chart,
    }

    return stats, anomalies, window_records


# ── Build outputs ──────────────────────────────────────────────────────────────
def _build_outputs(df, context_map, exclude_map, structural_map, df_raw=None):
    """Run analysis on all columns; return (temporal_df, summary_df, meta, col_details)."""
    time_col = None
    timestamps = None
    if df_raw is not None:
        time_col = _detect_date_column(df_raw)
        if time_col:
            timestamps = df_raw[time_col].reset_index(drop=True)
            print(f"  [info] Temporal analysis using column: '{time_col}'")

    temporal_records: list = []
    summary_records: list = []
    col_details: list = []

    for col in df.columns:
        series  = df[col]
        context = context_map.get(col, "")
        inv_idx = exclude_map.get(col, set())
        str_val = structural_map.get(col, set())

        ts = timestamps
        if ts is not None and len(ts) != len(series):
            ts = None

        stats, anomalies, window_records = _analyse_column(
            col, series, context, inv_idx, str_val, ts
        )

        for w in window_records:
            temporal_records.append(
                {
                    "column_name": col,
                    "period":      w["period"],
                    "n":           w["n"],
                    "median":      w["median"],
                    "std":         w["std"],
                    "q1":          w["q1"],
                    "q3":          w["q3"],
                    "shift":       w["shift"],
                }
            )

        summary_records.append(
            {
                "column_name":        stats["column_name"],
                "context":            stats["context"],
                "n_valid":            stats["n_valid"],
                "n_clean":            stats["n_clean"],
                "n_excluded": stats["n_excluded"],
                "mean":       stats["mean"],
                "median":             stats["median"],
                "std":                stats["std"],
                "min":                stats["min"],
                "max":                stats["max"],
                "skewness":           stats["skewness"],
                "kurtosis":           stats["kurtosis"],
                "zeros_pct":          stats["zeros_pct"],
                "shape":              stats["shape"],
                "modality":           stats["modality"],
                "overall_class":      stats["overall_class"],
                "n_anomalies":        stats["n_anomalies"],
            }
        )
        col_details.append(stats)

    temporal_df = pd.DataFrame(temporal_records)
    summary_df  = pd.DataFrame(summary_records)

    def _cnt(cls):
        return int((summary_df["overall_class"] == cls).sum()) if not summary_df.empty else 0

    meta = {
        "n_rows":               len(df),
        "n_cols":               len(df.columns),
        "n_data_quality_issue": _cnt("data_quality_issue"),
        "n_suspicious":         _cnt("suspicious"),
        "n_legitimate":         _cnt("legitimate"),
        "n_no_issue":           _cnt("no_issue"),
        "time_col":             time_col or "",
        "outlier_flags_used":   bool(exclude_map or structural_map),
    }

    return temporal_df, summary_df, meta, col_details


# ── Public API ─────────────────────────────────────────────────────────────────
def analyse_distribution(
    cleaned_path,
    outlier_flags_path=None,
    context_flags_path=None,
    raw_copy_path=None,
):
    """Run distribution analysis on all numerical columns.

    Returns (temporal_df, summary_df, meta, col_details).
    temporal_df  -- one row per column per time window (temporal stability data)
    summary_df   -- one row per column with shape metrics and overall class
    meta         -- run metadata dict
    col_details  -- list of per-column dicts including histogram and anomaly data for HTML
    """
    cleaned_path = Path(cleaned_path)
    df = pd.read_csv(cleaned_path)

    context_map = _load_context_map(
        Path(context_flags_path) if context_flags_path else None
    )
    exclude_map, structural_map = _load_outlier_info(
        Path(outlier_flags_path) if outlier_flags_path else None
    )

    if not exclude_map and not structural_map:
        print("  [warn] Outlier flags not found -- all values included in shape analysis.")
        print("         Run analyse_outliers_numerical first for best results.")
        print("         Without flags, invalid and suspicious outliers will distort shape metrics.")

    df_raw = None
    if raw_copy_path and Path(raw_copy_path).exists():
        df_raw = pd.read_csv(Path(raw_copy_path), dtype=str)

    return _build_outputs(df, context_map, exclude_map, structural_map, df_raw)


# ── HTML template ──────────────────────────────────────────────────────────────
_HTML_TEMPLATE = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Distribution Analysis — {{ stem }}</title>
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Segoe UI', system-ui, sans-serif; background: #f7f8fa; color: #1a1a2e; font-size: 14px; }
  h1 { font-size: 1.4rem; font-weight: 700; padding: 24px 32px 4px; }
  .subtitle { color: #666; font-size: 0.82rem; padding: 0 32px 16px; }
  /* summary strip */
  .strip { display: flex; gap: 12px; padding: 0 32px 20px; flex-wrap: wrap; }
  .strip-item { background: #fff; border: 1px solid #e0e0e0; border-radius: 8px;
                padding: 10px 18px; min-width: 130px; text-align: center; }
  .strip-num  { font-size: 1.5rem; font-weight: 700; }
  .strip-lbl  { font-size: 0.72rem; color: #888; text-transform: uppercase; letter-spacing: .04em; }
  .strip-num.dq  { color: #c62828; }
  .strip-num.sus { color: #f57f17; }
  .strip-num.leg { color: #2e7d32; }
  .strip-num.ok  { color: #888; }
  /* legend */
  .legend { display: flex; gap: 16px; padding: 0 32px 20px; flex-wrap: wrap; }
  .legend-item { display: flex; align-items: center; gap: 6px; font-size: 0.78rem; }
  .legend-dot { width: 12px; height: 12px; border-radius: 50%; flex-shrink: 0; }
  /* overview table */
  .overview { padding: 0 32px 24px; }
  .overview h2 { font-size: 1rem; font-weight: 600; margin-bottom: 10px; }
  table { width: 100%; border-collapse: collapse; background: #fff;
          border: 1px solid #e0e0e0; border-radius: 8px; overflow: hidden; font-size: 0.82rem; }
  th { background: #f0f0f5; font-weight: 600; padding: 8px 12px; text-align: left;
       border-bottom: 1px solid #e0e0e0; white-space: nowrap; }
  td { padding: 7px 12px; border-bottom: 1px solid #f0f0f0; vertical-align: middle; }
  tr:last-child td { border-bottom: none; }
  tr:hover td { background: #fafafa; }
  /* badges */
  .badge { display: inline-block; padding: 2px 8px; border-radius: 12px;
           font-size: 0.72rem; font-weight: 600; white-space: nowrap; }
  .badge-dq  { background: #ffebee; color: #c62828; }
  .badge-sus { background: #fff8e1; color: #f57f17; }
  .badge-leg { background: #e8f5e9; color: #2e7d32; }
  .badge-ok  { background: #f5f5f5; color: #888; }
  .badge-ctx { background: #e8eaf6; color: #3949ab; }
  .badge-shape { background: #fce4ec; color: #880e4f; font-weight: 500; }
  /* cards */
  .cards { padding: 0 32px 40px; display: grid;
           grid-template-columns: repeat(auto-fill, minmax(540px, 1fr)); gap: 18px; }
  .card { background: #fff; border: 1px solid #e0e0e0; border-radius: 10px; padding: 18px 20px; }
  .card-header { display: flex; align-items: center; gap: 8px; flex-wrap: wrap;
                 margin-bottom: 12px; border-bottom: 1px solid #f0f0f0; padding-bottom: 10px; }
  .card-title { font-size: 1rem; font-weight: 700; flex: 1; min-width: 0;
                overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  /* stats grid */
  .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 6px 4px;
                margin-bottom: 14px; }
  .stat { background: #f8f9fb; border-radius: 6px; padding: 6px 8px; }
  .stat-label { font-size: 0.64rem; color: #aaa; text-transform: uppercase; letter-spacing:.04em; }
  .stat-value { font-size: 0.9rem; font-weight: 600; }
  /* histogram */
  .chart-wrap { width: 100%; overflow-x: auto; margin-bottom: 4px; }
  svg.hist { display: block; width: 100%; }
  .bar rect { transition: opacity .15s; }
  .bar rect:hover { opacity: .7; }
  .axis-label { font-size: 9px; fill: #888; }
  .tick-line { stroke: #ddd; stroke-width: 1; }
  /* histogram legend */
  .hist-legend { display: flex; gap: 12px; font-size: 0.7rem; color: #666;
                 margin-bottom: 12px; flex-wrap: wrap; }
  .hist-legend-item { display: flex; align-items: center; gap: 4px; }
  .hist-legend-dot { width: 10px; height: 10px; border-radius: 2px; }
  /* anomaly findings */
  .section-label { font-size: 0.72rem; color: #aaa; text-transform: uppercase;
                   letter-spacing:.05em; margin: 12px 0 6px; }
  .finding { border-radius: 6px; padding: 8px 12px; margin-bottom: 8px; }
  .finding-dq  { background: #ffebee; border-left: 3px solid #c62828; }
  .finding-sus { background: #fff8e1; border-left: 3px solid #f57f17; }
  .finding-leg { background: #e8f5e9; border-left: 3px solid #2e7d32; }
  .finding-ok  { background: #f5f5f5; border-left: 3px solid #bdbdbd; }
  .finding-top { display: flex; align-items: center; gap: 8px; margin-bottom: 4px; }
  .finding-type { font-size: 0.72rem; font-weight: 700; text-transform: uppercase;
                  letter-spacing:.04em; }
  .finding-detail { font-size: 0.82rem; color: #333; margin-bottom: 6px; }
  .rec-box { background: rgba(255,255,255,.6); border-radius: 4px; padding: 5px 8px;
             font-size: 0.78rem; color: #555; }
  .rec-label { font-size: 0.68rem; font-weight: 700; text-transform: uppercase;
               letter-spacing:.04em; color: #999; margin-bottom: 2px; }
  .no-anomalies { color: #2e7d32; font-size: 0.82rem; font-style: italic; padding: 6px 0; }
  /* warn banner */
  .warn-banner { background: #fff8e1; border: 1px solid #ffe082; border-radius: 6px;
                 padding: 10px 16px; margin: 0 32px 20px; font-size: 0.84rem; color: #7a5c00; }
</style>
</head>
<body>

<h1>Distribution Analysis — {{ stem }}</h1>
<div class="subtitle">
  Source: {{ source_file }} &nbsp;·&nbsp;
  {{ meta.n_rows }} rows &nbsp;·&nbsp;
  {{ meta.n_cols }} column{{ 's' if meta.n_cols != 1 else '' }} &nbsp;·&nbsp;
  {% if meta.time_col %}Temporal analysis on <strong>{{ meta.time_col }}</strong> &nbsp;·&nbsp;{% endif %}
  {% if meta.outlier_flags_used %}Outlier flags applied &nbsp;·&nbsp;{% endif %}
  Generated {{ generated }}
</div>

{% if not meta.outlier_flags_used %}
<div class="warn-banner">
  &#9888; Outlier flags were not found. All values — including invalid and suspicious outliers — are included in shape analysis.
  For best results, run <code>analyse_outliers_numerical</code> first.
  Without outlier flags, shape metrics (skewness, kurtosis, truncation) may be distorted.
</div>
{% endif %}

<!-- Summary strip -->
<div class="strip">
  <div class="strip-item">
    <div class="strip-num">{{ meta.n_cols }}</div>
    <div class="strip-lbl">Columns</div>
  </div>
  <div class="strip-item">
    <div class="strip-num dq">{{ meta.n_data_quality_issue }}</div>
    <div class="strip-lbl">Data quality issue</div>
  </div>
  <div class="strip-item">
    <div class="strip-num sus">{{ meta.n_suspicious }}</div>
    <div class="strip-lbl">Suspicious</div>
  </div>
  <div class="strip-item">
    <div class="strip-num leg">{{ meta.n_legitimate }}</div>
    <div class="strip-lbl">Legitimate</div>
  </div>
  <div class="strip-item">
    <div class="strip-num ok">{{ meta.n_no_issue }}</div>
    <div class="strip-lbl">No issue</div>
  </div>
</div>

<!-- Legend -->
<div class="legend">
  <div class="legend-item"><div class="legend-dot" style="background:#c62828"></div> Data quality issue</div>
  <div class="legend-item"><div class="legend-dot" style="background:#f57f17"></div> Suspicious</div>
  <div class="legend-item"><div class="legend-dot" style="background:#2e7d32"></div> Legitimate</div>
  <div class="legend-item"><div class="legend-dot" style="background:#bdbdbd"></div> No issue</div>
</div>

<!-- Overview table -->
<div class="overview">
  <h2>Column Overview</h2>
  <table>
    <thead>
      <tr>
        <th>Column</th>
        <th>Context</th>
        <th>Shape</th>
        <th>Skewness</th>
        <th>Kurtosis</th>
        <th>Zeros %</th>
        <th>Anomalies</th>
        <th>Class</th>
      </tr>
    </thead>
    <tbody>
    {% for col in columns %}
      <tr>
        <td><strong>{{ col.column_name }}</strong></td>
        <td>{% if col.context %}<span class="badge badge-ctx">{{ col.context }}</span>{% else %}—{% endif %}</td>
        <td><span class="badge badge-shape">{{ col.shape }}</span></td>
        <td>{{ col.skewness if col.skewness is not none else '—' }}</td>
        <td>{{ col.kurtosis if col.kurtosis is not none else '—' }}</td>
        <td>{{ col.zeros_pct if col.zeros_pct is not none else '—' }}{% if col.zeros_pct is not none %}%{% endif %}</td>
        <td>{{ col.n_anomalies }}</td>
        <td>
          {% if col.overall_class == 'data_quality_issue' %}<span class="badge badge-dq">data quality issue</span>
          {% elif col.overall_class == 'suspicious' %}<span class="badge badge-sus">suspicious</span>
          {% elif col.overall_class == 'legitimate' %}<span class="badge badge-leg">legitimate</span>
          {% else %}<span class="badge badge-ok">no issue</span>{% endif %}
        </td>
      </tr>
    {% endfor %}
    </tbody>
  </table>
</div>

<!-- Histogram macro -->
{% macro render_hist(hist) %}
{% if hist and hist.bins %}
<div class="chart-wrap">
  {% set bins = hist.bins %}
  {% set max_count = bins | map(attribute='count') | max %}
  {% set chart_w = 472 %}
  {% set chart_h = 90 %}
  {% set bar_w = (chart_w / bins|length) - 1 %}
  <svg class="hist" viewBox="0 0 {{ chart_w }} {{ chart_h + 26 }}" xmlns="http://www.w3.org/2000/svg">
    {% for bin in bins %}
      {% set bar_h = (bin.count / max_count * chart_h) if max_count > 0 else 0 %}
      {% set x = loop.index0 * (bar_w + 1) %}
      {% if bin.color == 'spike' %}{% set fill = '#f57f17' %}
      {% elif bin.color == 'structural' %}{% set fill = '#e65100' %}
      {% elif bin.color == 'truncation' %}{% set fill = '#c62828' %}
      {% else %}{% set fill = '#5c6bc0' %}{% endif %}
      <g class="bar">
        <rect x="{{ x }}" y="{{ chart_h - bar_h }}"
              width="{{ bar_w }}" height="{{ bar_h }}"
              fill="{{ fill }}" rx="1">
          <title>{{ bin.label }}: {{ bin.count }}</title>
        </rect>
      </g>
    {% endfor %}
    {% for tick in hist.ticks %}
      {% set tx = tick.x_frac * chart_w %}
      <line class="tick-line" x1="{{ tx }}" y1="{{ chart_h }}" x2="{{ tx }}" y2="{{ chart_h + 5 }}"/>
      <text class="axis-label"
            x="{{ tx }}" y="{{ chart_h + 18 }}"
            text-anchor="{{ 'start' if tick.x_frac < 0.1 else ('end' if tick.x_frac > 0.9 else 'middle') }}">
        {{ tick.label }}
      </text>
    {% endfor %}
  </svg>
</div>
{% endif %}
{% endmacro %}

<!-- Temporal stability chart macro -->
{% macro render_temporal_chart(window_records, chart) %}
{% if window_records and chart %}
<div class="chart-wrap">
  <svg class="hist" viewBox="0 0 {{ chart.chart_w }} {{ chart.chart_h + 34 }}" xmlns="http://www.w3.org/2000/svg">
    <!-- Y-axis gridlines and tick labels -->
    {% for tick in chart.y_ticks %}
    <line x1="{{ chart.left_m }}" y1="{{ tick.y }}" x2="{{ chart.chart_w - 6 }}" y2="{{ tick.y }}"
          stroke="#f0f0f0" stroke-width="1"/>
    <text x="{{ chart.left_m - 4 }}" y="{{ tick.y + 3 }}" text-anchor="end"
          style="font-size:8px;fill:#aaa">{{ tick.label }}</text>
    {% endfor %}
    <!-- Overall median reference line -->
    <line x1="{{ chart.left_m }}" y1="{{ chart.overall_med_y }}"
          x2="{{ chart.chart_w - 6 }}" y2="{{ chart.overall_med_y }}"
          stroke="#2196f3" stroke-width="1.5" stroke-dasharray="5,3" opacity="0.85"/>
    <text x="{{ chart.chart_w - 4 }}" y="{{ chart.overall_med_y - 3 }}"
          text-anchor="end" style="font-size:7px;fill:#2196f3;font-weight:600">overall median</text>
    <!-- IQR bands (Q1-Q3 rectangles per window) -->
    {% for w in window_records %}
    {% if w.shift %}{% set fill = '#f57f17' %}{% else %}{% set fill = '#5c6bc0' %}{% endif %}
    <rect x="{{ w.svg_x - chart.bw / 2 }}" y="{{ w.svg_q3_y }}"
          width="{{ chart.bw }}" height="{{ w.svg_q1_y - w.svg_q3_y }}"
          fill="{{ fill }}" opacity="0.18" rx="1">
      <title>{{ w.period }} (n={{ w.n }}): Q1={{ w.q1 }}, median={{ w.median }}, Q3={{ w.q3 }}</title>
    </rect>
    {% endfor %}
    <!-- Connecting polyline through medians -->
    <polyline points="{{ chart.polyline_pts }}"
              fill="none" stroke="#9fa8da" stroke-width="1.2" opacity="0.55"/>
    <!-- Median dots -->
    {% for w in window_records %}
    {% if w.shift %}{% set fill = '#f57f17' %}{% else %}{% set fill = '#5c6bc0' %}{% endif %}
    <circle cx="{{ w.svg_x }}" cy="{{ w.svg_med_y }}" r="3.5" fill="{{ fill }}" opacity="0.9">
      <title>{{ w.period }} (n={{ w.n }}): median={{ w.median }}{% if w.shift %} -- significant shift{% endif %}</title>
    </circle>
    {% endfor %}
    <!-- X-axis baseline -->
    <line x1="{{ chart.left_m }}" y1="{{ chart.chart_h }}"
          x2="{{ chart.chart_w - 6 }}" y2="{{ chart.chart_h }}"
          stroke="#ddd" stroke-width="1"/>
    <!-- X-axis period labels (rotated 40 degrees) -->
    {% for w in window_records %}
    {% if w.show_label %}
    <text transform="rotate(-40, {{ w.svg_x }}, {{ chart.chart_h + 5 }})"
          x="{{ w.svg_x }}" y="{{ chart.chart_h + 5 }}"
          text-anchor="end" style="font-size:7px;fill:#888">{{ w.period }}</text>
    {% endif %}
    {% endfor %}
  </svg>
</div>
<div class="hist-legend">
  <div class="hist-legend-item">
    <svg width="16" height="10" style="vertical-align:middle"><line x1="1" y1="5" x2="15" y2="5" stroke="#2196f3" stroke-width="1.5" stroke-dasharray="4,2"/></svg>
    Overall median
  </div>
  <div class="hist-legend-item"><div class="hist-legend-dot" style="background:#5c6bc0"></div> Within range</div>
  <div class="hist-legend-item"><div class="hist-legend-dot" style="background:#f57f17"></div> Significant shift</div>
  <div class="hist-legend-item"><div class="hist-legend-dot" style="background:#9fa8da;border-radius:2px;width:12px;height:8px;display:inline-block"></div> IQR band (Q1-Q3)</div>
</div>
{% endif %}
{% endmacro %}

<!-- Column cards -->
<div class="cards">
{% for col in columns %}
<div class="card">
  <!-- Header -->
  <div class="card-header">
    <div class="card-title">{{ col.column_name }}</div>
    {% if col.context %}<span class="badge badge-ctx">{{ col.context }}</span>{% endif %}
    <span class="badge badge-shape">{{ col.shape }}</span>
    {% if col.overall_class == 'data_quality_issue' %}<span class="badge badge-dq">data quality issue</span>
    {% elif col.overall_class == 'suspicious' %}<span class="badge badge-sus">suspicious</span>
    {% elif col.overall_class == 'legitimate' %}<span class="badge badge-leg">legitimate</span>
    {% else %}<span class="badge badge-ok">no issue</span>{% endif %}
  </div>

  <!-- Stats grid -->
  <div class="stats-grid">
    <div class="stat"><div class="stat-label">N valid</div><div class="stat-value">{{ col.n_valid }}</div></div>
    <div class="stat"><div class="stat-label">N analysed</div><div class="stat-value">{{ col.n_clean }}<span style="font-size:0.7rem;color:#aaa;font-weight:400"> (−{{ col.n_excluded }})</span></div></div>
    <div class="stat"><div class="stat-label">Mean</div><div class="stat-value">{{ col.mean if col.mean is not none else '—' }}</div></div>
    <div class="stat"><div class="stat-label">Median</div><div class="stat-value">{{ col.median if col.median is not none else '—' }}</div></div>
    <div class="stat"><div class="stat-label">Std</div><div class="stat-value">{{ col.std if col.std is not none else '—' }}</div></div>
    <div class="stat"><div class="stat-label">Min</div><div class="stat-value">{{ col.min if col.min is not none else '—' }}</div></div>
    <div class="stat"><div class="stat-label">Max</div><div class="stat-value">{{ col.max if col.max is not none else '—' }}</div></div>
    <div class="stat"><div class="stat-label">Zeros %</div><div class="stat-value">{{ col.zeros_pct if col.zeros_pct is not none else '—' }}{% if col.zeros_pct is not none %}%{% endif %}</div></div>
    <div class="stat"><div class="stat-label">Skewness</div><div class="stat-value">{{ col.skewness if col.skewness is not none else '—' }}</div></div>
    <div class="stat"><div class="stat-label">Kurtosis</div><div class="stat-value">{{ col.kurtosis if col.kurtosis is not none else '—' }}</div></div>
    <div class="stat"><div class="stat-label">p05 / p95</div><div class="stat-value">{{ col.p05 if col.p05 is not none else '—' }} / {{ col.p95 if col.p95 is not none else '—' }}</div></div>
    <div class="stat"><div class="stat-label">p25 / p75</div><div class="stat-value">{{ col.p25 if col.p25 is not none else '—' }} / {{ col.p75 if col.p75 is not none else '—' }}</div></div>
  </div>

  <!-- Histogram -->
  {% if col.histogram and col.histogram.bins %}
  <div class="section-label">Distribution (all flagged outliers excluded; non-flagged values only)</div>
  {{ render_hist(col.histogram) }}
  {% if col.histogram.bins | selectattr('color', 'ne', 'normal') | list | length > 0 %}
  <div class="hist-legend">
    {% if col.histogram.bins | selectattr('color', 'equalto', 'spike') | list | length > 0 %}
    <div class="hist-legend-item"><div class="hist-legend-dot" style="background:#f57f17"></div> Spike</div>
    {% endif %}
    {% if col.histogram.bins | selectattr('color', 'equalto', 'truncation') | list | length > 0 %}
    <div class="hist-legend-item"><div class="hist-legend-dot" style="background:#c62828"></div> Truncation boundary</div>
    {% endif %}
  </div>
  {% endif %}
  {% endif %}

  <!-- Anomaly findings -->
  <div class="section-label">Findings</div>
  {% if col.anomalies %}
    {% for a in col.anomalies %}
    {% if a.severity == 'data_quality_issue' %}{% set fc = 'finding-dq' %}
    {% elif a.severity == 'suspicious' %}{% set fc = 'finding-sus' %}
    {% elif a.severity == 'legitimate' %}{% set fc = 'finding-leg' %}
    {% else %}{% set fc = 'finding-ok' %}{% endif %}
    <div class="finding {{ fc }}">
      <div class="finding-top">
        <span class="badge {% if a.severity == 'data_quality_issue' %}badge-dq{% elif a.severity == 'suspicious' %}badge-sus{% elif a.severity == 'legitimate' %}badge-leg{% else %}badge-ok{% endif %}">
          {{ a.severity | replace('_', ' ') }}
        </span>
        <span class="finding-type">{{ a.anomaly_type | replace('_', ' ') }}</span>
      </div>
      <div class="finding-detail">{{ a.detail }}</div>
      <div class="rec-box">
        <div class="rec-label">Mitigation</div>
        {{ a.mitigation }}
      </div>
    </div>
    {% endfor %}
  {% else %}
    <div class="no-anomalies">✓ No anomalies detected for this column.</div>
  {% endif %}

  <!-- Temporal stability chart -->
  {% if col.window_records %}
  <div class="section-label">Temporal stability (per {{ 'month' if col.window_records[0].period | length <= 7 else 'quarter' }}) &mdash; median &amp; IQR per window</div>
  {{ render_temporal_chart(col.window_records, col.temporal_chart) }}
  {% endif %}

</div>
{% endfor %}
</div>

</body>
</html>
"""


# ── Render HTML ────────────────────────────────────────────────────────────────
def render_html(col_details, summary_df, meta, stem, source_file):
    env = Environment(loader=BaseLoader(), autoescape=False)
    tmpl = env.from_string(_HTML_TEMPLATE)
    return tmpl.render(
        stem=stem,
        source_file=source_file,
        meta=meta,
        columns=col_details,
        generated=datetime.now().strftime("%Y-%m-%d %H:%M"),
    )


# ── Save outputs ───────────────────────────────────────────────────────────────
def save_outputs(stem: str) -> None:
    print(f"\n{'='*60}")
    print(f"  analyse_distribution_numerical  ->  {stem}")
    print(f"{'='*60}")

    cleaned_path       = INPUT_DIR    / f"{stem}_numerical_cleaned.csv"
    outlier_flags_path = OUTLIER_DIR  / f"{stem}_outlier_flags.csv"
    context_flags_path = CONTEXT_DIR  / f"{stem}_type_flags_context.csv"
    raw_copy_path      = RAW_DIR      / f"{stem}_raw_copy.csv"

    temporal_df, summary_df, meta, col_details = analyse_distribution(
        cleaned_path,
        outlier_flags_path=outlier_flags_path,
        context_flags_path=context_flags_path,
        raw_copy_path=raw_copy_path,
    )

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    temporal_path = OUTPUT_DIR / f"{stem}_distribution_temporal.csv"
    summary_path  = OUTPUT_DIR / f"{stem}_distribution_summary.csv"
    report_path   = OUTPUT_DIR / f"{stem}_distribution_report.html"

    temporal_df.to_csv(temporal_path, index=False)
    summary_df.to_csv(summary_path, index=False)

    html = render_html(col_details, summary_df, meta, stem, cleaned_path.name)
    report_path.write_text(html, encoding="utf-8")

    print(f"  Columns analysed : {meta['n_cols']}")
    print(f"  Data quality     : {meta['n_data_quality_issue']}")
    print(f"  Suspicious       : {meta['n_suspicious']}")
    print(f"  Legitimate       : {meta['n_legitimate']}")
    print(f"  No issue         : {meta['n_no_issue']}")
    print(f"  Temporal windows : {len(temporal_df)}")
    print(f"  Temporal col     : {meta['time_col'] or '(none detected)'}")
    print(f"  -> {temporal_path.name}")
    print(f"  -> {summary_path.name}")
    print(f"  -> {report_path.name}")


# ── Entry point ────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    stems = [sys.argv[1]] if len(sys.argv) > 1 else STEMS
    for stem in stems:
        save_outputs(stem)
