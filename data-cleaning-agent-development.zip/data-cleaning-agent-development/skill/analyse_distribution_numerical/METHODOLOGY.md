# Methodology: analyse_distribution_numerical

## Overview

This skill analyses the shape, anomalies, and temporal stability of numerical columns after the cleaning step. It focuses on properties of the **distribution** rather than individual outlier values.

## Data preparation

1. The cleaned CSV (`_numerical_cleaned.csv`) is read as the primary input.
2. **Outlier exclusion** — if outlier flags are available, **all** flagged rows are removed before any statistics are computed:
   - `invalid` — excluded (domain violations; would corrupt shape metrics).
   - `suspicious` — excluded (statistical outliers; would distort skewness and kurtosis).
   - `structural` — excluded (sentinel values produce artificial spikes that mask the true shape).
   - `legitimate` — excluded (genuine extreme values are still removed so the shape statistics describe the non-outlier core of the distribution, free of any tail inflation).

   Only rows that carry **no outlier flag** contribute to the distribution analysis.
3. The `N analysed` figure in the report reflects the count after invalid and suspicious rows are removed. The `N excluded` sub-figure shows how many rows were removed.
4. If a context map is available, each column is assigned a semantic context (`amount`, `cost`, `price`, `duration`, `count`, `ratio`, `percentage`, etc.) that modulates anomaly severity.

> **Warning:** If no outlier flags are provided, all values are used without filtering. This may produce misleading shape metrics. Always run `analyse_outliers_numerical` before this skill.

## Statistics computed

All statistics are computed on the **filtered series** (invalid, suspicious, and structural outliers removed).

| Statistic | Notes |
|-----------|-------|
| Mean, median, std | On filtered values (all outlier classes excluded — invalid, suspicious, structural, legitimate) |
| Min, max, p05, p25, p75, p95 | Percentiles of filtered values |
| Skewness | Fisher's definition (pandas default) |
| Kurtosis | Absolute kurtosis (pandas excess + 3) — normal distribution ≈ 3 |
| Zeros % | Fraction of filtered values equal to exactly 0 |

## Shape classification

Shape is determined by a combination of skewness, kurtosis, and modality.

| Shape label | Criteria |
|-------------|----------|
| `normal_like` | `|skew| < 0.5` and `2.0 ≤ kurt ≤ 4.0` |
| `right_skewed` | `0.5 ≤ skew < 1.5` |
| `right_skewed_high` | `skew ≥ 1.5` |
| `left_skewed` | `-1.5 < skew ≤ -0.5` |
| `left_skewed_high` | `skew ≤ -1.5` |
| `heavy_tailed` | `kurt > 4.0` (after skew checks) |
| `light_tailed` | `kurt < 2.0` (after skew checks) |
| `bimodal` | Two distinct peaks in histogram with valley depth < 30% of shorter peak |
| `multimodal` | Three or more such peaks |
| `insufficient_data` | Fewer than 2 valid cleaned values |

## Modality detection

1. A 20-bin histogram is computed from cleaned values.
2. Bin counts are smoothed with a 3-point moving average.
3. Local maxima above 10% of the tallest bin are identified.
4. If ≥ 2 peaks exist, the valley between the two tallest peaks must be less than `BIMODAL_VALLEY_RATIO` (30%) of the shorter peak to confirm bimodality.

## Anomaly detection

### Truncation (pile-up at boundary)

- The fraction of values equal to the max (or min) is computed.
- A boundary is considered "round" if it is a multiple of 100/1000/10000/100000 or a `9...9` pattern (99, 999, 9999…).
- Flagged as `data_quality_issue` if: `fraction_at_boundary > 2%` AND `boundary is round`.

### Zero-inflation

- Compute the fraction of cleaned values equal to exactly 0.
- Threshold is context-dependent:
  - `count` context: flagged if zeros > 80% (`ZERO_INFLATION_COUNT`).
  - All other contexts: flagged if zeros > 30% (`ZERO_INFLATION_THRESHOLD`).
- Severity: `legitimate` for `count`, `data_quality_issue` for others.

### Spike (dominant single value)

- A value counts are computed (normalised).
- Any value with frequency > 10% (`SPIKE_FREQ_THRESHOLD`) that is **not** already in the structural sentinel set is flagged.
- Severity: `data_quality_issue`.

### Shape anomalies (skewness, kurtosis, bimodality)

- Right skew is `legitimate` for contexts: `amount`, `cost`, `price`, `duration`, `count`.
- Right skew is `suspicious` for other contexts if `|skew| ≥ 1.5`.
- Left skew is `suspicious` if `|skew| ≥ 1.5`.
- Heavy tail (`kurt > 4.0`) is `legitimate` for naturally-skewed contexts, `suspicious` for others.
- Bimodal/multimodal is always `suspicious`.

## Temporal stability

> **Pipeline dependency:** The temporal stability check uses the raw date column from `_raw_copy.csv` as a time axis. This is the best available approximation in the **numerical data stream**. Once the `clean_datetime` skill has been built and run, its cleaned date output should be passed in instead, and `clean_datetime` should precede this skill in the pipeline.

When a date column is available (auto-detected from `_raw_copy.csv`):

1. Values are grouped into monthly windows (falls back to quarterly if monthly windows are too small).
2. Windows with fewer than `MIN_TEMPORAL_WINDOW` (30) rows are excluded.
3. For each window the median is computed.
4. A window is flagged as shifted if: `|window_median − overall_median| > TEMPORAL_SHIFT_MAD_MULT × overall_MAD`.
5. The default multiplier is 3.0 (robust, avoids false positives from seasonal variation).
6. Flagged windows are reported in the HTML table with ⚠ markers.
7. Severity: `suspicious`.

No scipy dependency — only numpy is used for all computations.

## Overall column classification

The worst severity across all detected anomalies determines the column's `overall_class`:

```
data_quality_issue  >  suspicious  >  legitimate  >  no_issue
```

## Histogram colour coding

Histogram bins are coloured by the type of anomaly they contain:

| Colour | Meaning |
|--------|---------|
| Indigo | Normal |
| Amber | Spike value |
| Red | Truncation boundary bin |

_Note: all flagged outlier rows (invalid, suspicious, structural, legitimate) are excluded before the histogram is built and cannot appear in any bin._

## Key tuning constants

| Constant | Default | Meaning |
|----------|---------|---------|
| `SKEWNESS_MODERATE` | 0.5 | Threshold for moderate skew |
| `SKEWNESS_HIGH` | 1.5 | Threshold for high skew |
| `KURTOSIS_HEAVY_TAIL` | 4.0 | Absolute kurtosis above which distribution is heavy-tailed |
| `KURTOSIS_LIGHT_TAIL` | 2.0 | Absolute kurtosis below which distribution is light-tailed |
| `ZERO_INFLATION_THRESHOLD` | 0.30 | Zero fraction threshold for non-count columns |
| `ZERO_INFLATION_COUNT` | 0.80 | Zero fraction threshold for count columns |
| `SPIKE_FREQ_THRESHOLD` | 0.10 | Single-value dominance threshold |
| `TRUNCATION_PILE_THRESHOLD` | 0.02 | Boundary pile-up fraction threshold |
| `BIMODAL_VALLEY_RATIO` | 0.30 | Valley-to-peak ratio for bimodality confirmation |
| `MIN_SAMPLE` | 10 | Minimum valid values for detailed analysis |
| `MIN_TEMPORAL_WINDOW` | 30 | Minimum rows per time window |
| `TEMPORAL_SHIFT_MAD_MULT` | 3.0 | MAD multiplier for temporal shift detection |
