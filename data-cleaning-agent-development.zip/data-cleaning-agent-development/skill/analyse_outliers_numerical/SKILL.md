---
name: analyse-outliers-numerical
description: 'Sixth step in the AI Data Cleaning pipeline, runs after clean-numerical. Detects outlier candidates in every numerical column using three independent methods (IQR, z-score, modified z-score / MAD), classifies each column as structural (same extreme value repeated ≥ 20% — likely a coding error) or incidental (diverse one-off extremes), validates candidates against context-aware hard bounds (negative count / duration / ratio → invalid) and cross-column corroboration (two or more columns simultaneously extreme → legitimate), then classifies each instance as invalid, structural, suspicious, or legitimate with a scaled mitigation recommendation. Raises a warning for negative values in amount/cost/price columns. Outputs a per-instance flags CSV, a per-column summary CSV, and a self-contained HTML report. Does NOT impute or modify any data.'
argument-hint: 'Dataset stem name, e.g. onderhoud_materieel'
---

# Analyse Outliers — Numerical Columns

## Purpose
Detect and classify extreme values in all **numerical** columns before any imputation or transformation is applied. The skill distinguishes between data entry errors (structural patterns, invalid values) and genuine extreme events (corroborated across columns), and scales its recommendation with the strength of the outlier signal.

## Prerequisites
The `clean-numerical` skill must have been run first. The `context-numerical` skill should be run first too — without its output the `invalid` classification is disabled and no domain-bound warnings are raised. A warning is printed to the console and shown at the top of the HTML report if the context file is missing.

## What It Does
1. **Detect** — flags outlier candidates per column using three independent methods; records a `detection_strength` (0–3)
2. **Structural vs incidental** — classifies each column's pattern: structural (any individual value accounting for ≥ 20% of statistical outlier instances — may be multiple sentinel values) or incidental (diverse extremes)
3. **Validate** — applies context-aware hard bounds (negative count / duration → invalid) and checks cross-column corroboration (≥ 2 columns extreme on same row → legitimate)
4. **Classify** — assigns each instance as `invalid`, `legitimate`, or `suspicious`; generates a mitigation recommendation scaled to detection strength
5. **Render** — writes a per-instance flags CSV, a per-column summary CSV, and a self-contained HTML report

## Detection Methods

| Method | Threshold | Notes |
|---|---|---|
| IQR (Tukey) | outside Q1 − 1.5×IQR / Q3 + 1.5×IQR | standard; robust to non-normal distributions |
| IQR severe | outside Q1 − 3×IQR / Q3 + 3×IQR | additional severity flag, not a separate method |
| Z-score | \|z\| > 3.0 | assumes approximate normality; skipped when std = 0 |
| Modified z-score (MAD) | \|mz\| > 3.5 | Iglewicz & Hoaglin (1993); robust to existing outliers |

## Classification Labels

| Class | Condition | Recommended action |
|---|---|---|
| `invalid` | Violates a hard domain bound (e.g. negative count, ratio > 100%) | Set to NaN and investigate the data source |
| `structural` | A repeating sentinel value accounts for ≥ 20% of statistical outliers in the column | Confirm meaning with data owner; apply bulk substitution |
| `suspicious` | Statistically extreme; no bound violation or structural pattern | Review individually; winsorize at IQR fences or set to NaN |
| `legitimate` | Row corroborated by ≥ 2 outlier columns simultaneously; not invalid or structural | Retain and document; consider robust scaling for downstream modelling |

Classification is evaluated in strict priority order: `invalid` → `structural` → `legitimate` → `suspicious`.

Multiple values can qualify as structural simultaneously; all are reported in the `structural_values` summary field.

**Negative value warning:** columns with context `amount`, `cost`, or `price` receive a soft warning note appended to the mitigation text when negative values are present. These are not classified as `invalid` because negatives may be valid credits or refunds.

## Procedure

### Run on all configured datasets
```bash
python skill/analyse_outliers_numerical/analyse_outliers_numerical.py
```

### Run on a specific dataset
```bash
python skill/analyse_outliers_numerical/analyse_outliers_numerical.py onderhoud_materieel
```

### Import in another skill
```python
from skill.analyse_outliers_numerical import analyse_outliers

flags_df, summary_df, co_occurrence, meta = analyse_outliers(
    cleaned_path='skill/clean_numerical/output/onderhoud_materieel_numerical_cleaned.csv',
    context_flags_path='skill/context_numerical/output/onderhoud_materieel_type_flags_context.csv',
)
```

## Inputs
| File | Source folder | Required |
|---|---|---|
| `<name>_numerical_cleaned.csv` | `skill/clean_numerical/output/` | Yes |
| `<name>_type_flags_context.csv` | `skill/context_numerical/output/` | Strongly recommended — without it `invalid` classification is disabled |

## Outputs
Written to `skill/analyse_outliers_numerical/output/`:

| File | Description |
|---|---|
| `<name>_outlier_flags.csv` | One row per outlier instance: value, detection methods, detection strength, structural flag, corroboration flag, class, mitigation |
| `<name>_outlier_summary.csv` | One row per column: count/%, class breakdown (`n_invalid`, `n_structural`, `n_suspicious`, `n_legitimate`), structural value(s) (`structural_values`), IQR bounds, method availability, negative-value warning |
| `<name>_outlier_report.html` | Self-contained HTML report — no internet required |

## Reading the Report

| Section | What to look for |
|---|---|
| Summary strip | Rows affected %; columns with outliers; count breakdown by class (invalid / structural / suspicious / legitimate) |
| Column overview table | Outlier bar (green ≤ 2%, amber 2–10%, red > 10%); Structural badge; ⚠ negative values warning; IQR = 0 badge |
| Co-occurrence table | Rows with 2+ outlier columns — corroborated extreme events |
| Column analysis cards | IQR bounds; method availability; class counts; structural/negative-value warning box; per-instance table with detection method breakdown |

## Dependencies
```bash
pip install -r skill/analyse_outliers_numerical/requirements.txt
```

## References
- [Statistical methodology and classification logic](./METHODOLOGY.md)
