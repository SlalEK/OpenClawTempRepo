"""
Analyse Outliers — Numerical Columns
--------------------------------------
Reads the clean_numerical output and optionally the context_numerical output,
then runs a four-step outlier analysis:

    1. Detect      -- flags outlier candidates per numerical column using three
                      independent methods (IQR, z-score, modified z-score / MAD)
                      and records a detection_strength (0–3)
    2. Structural  -- classifies each column's outlier pattern as structural
                      (same extreme value repeated ≥ 50% of instances, suggesting
                      a coding error) or incidental (diverse one-off extremes)
    3. Validate    -- applies context-aware hard bounds (negative count / duration
                      / ratio are always invalid) and checks cross-column
                      corroboration (two or more columns simultaneously extreme
                      on the same row → likely a genuine extreme event)
    4. Classify    -- assigns each outlier instance as:
                         invalid    -- violates a hard domain bound
                         legitimate -- corroborated by other extreme columns
                         suspicious -- everything else; mitigation scales with
                                       detection strength and structural flag

The skill does NOT modify any data. It recommends a mitigation strategy.

Inputs
    <name>_numerical_cleaned.csv        from skill/clean_numerical/output/
    <name>_type_flags_context.csv       from skill/context_numerical/output/ (optional)

Outputs
    <name>_outlier_flags.csv     -- one row per outlier instance
    <name>_outlier_summary.csv   -- one row per column
    <name>_outlier_report.html   -- self-contained HTML report
"""

import sys
from pathlib import Path
from datetime import datetime

import numpy as np
import pandas as pd
from jinja2 import Environment, BaseLoader

# ── Paths ──────────────────────────────────────────────────────────────────────

ROOT        = Path(__file__).resolve().parents[2]
INPUT_DIR   = ROOT / 'skill' / 'clean_numerical'  / 'output'
CONTEXT_DIR = ROOT / 'skill' / 'context_numerical' / 'output'
OUTPUT_DIR  = Path(__file__).resolve().parent / 'output'
OUTPUT_DIR.mkdir(exist_ok=True)

STEMS = ['onderhoud_materieel', 'personeel_hr']

# ── Constants ──────────────────────────────────────────────────────────────────

IQR_MULTIPLIER         = 1.5
IQR_EXTREME_MULTIPLIER = 3.0
ZSCORE_THRESHOLD       = 3.0
MZSCORE_THRESHOLD      = 3.5   # Iglewicz & Hoaglin (1993)
STRUCTURAL_VALUE_MIN_FREQ = 0.20  # any single value accounting for ≥ 20% of outlier
                                   # instances (among statistically detected outliers)
                                   # is treated as a structural placeholder
MIN_SAMPLE_FOR_STATS   = 10

# Hard bounds: values outside these ranges are classified as invalid
CONTEXT_HARD_BOUNDS: dict[str, dict] = {
    'count':      {'min': 0.0},
    'ratio':      {'min': 0.0, 'max': 100.0},
    'percentage': {'min': 0.0, 'max': 100.0},
    'duration':   {'min': 0.0},
}

# Soft warning: negative values are unusual but not necessarily impossible
CONTEXT_WARN_NEGATIVE: set[str] = {'amount', 'cost', 'price'}


# ── Helper: context map ────────────────────────────────────────────────────────

def _load_context_map(path: Path | None) -> dict[str, str]:
    if path is None or not path.exists():
        return {}
    df = pd.read_csv(path)
    if 'column_name' not in df.columns or 'context' not in df.columns:
        return {}
    return {
        row['column_name']: str(row['context'])
        for _, row in df.iterrows()
        if pd.notna(row['context'])
    }


# ── Step 1: Column statistics ──────────────────────────────────────────────────

def _col_stats(series: pd.Series) -> dict | None:
    s = series.dropna().astype(float)
    n = len(s)
    if n == 0:
        return None
    q1     = float(s.quantile(0.25))
    q3     = float(s.quantile(0.75))
    iqr    = q3 - q1
    median = float(s.median())
    mean   = float(s.mean())
    std    = float(s.std(ddof=1)) if n > 1 else 0.0
    mad    = float((s - median).abs().median())
    return {
        'n':             n,
        'q1':            q1,
        'q3':            q3,
        'iqr':           iqr,
        'iqr_lower':     q1 - IQR_MULTIPLIER * iqr,
        'iqr_upper':     q3 + IQR_MULTIPLIER * iqr,
        'iqr_ext_lower': q1 - IQR_EXTREME_MULTIPLIER * iqr,
        'iqr_ext_upper': q3 + IQR_EXTREME_MULTIPLIER * iqr,
        'median':        median,
        'mean':          mean,
        'std':           std,
        'mad':           mad,
        'iqr_zero':      iqr == 0.0,
        'zscore_ok':     std > 0.0 and n >= MIN_SAMPLE_FOR_STATS,
        'mzscore_ok':    mad > 0.0 and n >= MIN_SAMPLE_FOR_STATS,
        'reliable':      n >= MIN_SAMPLE_FOR_STATS,
    }


# ── Step 2: Detect outlier candidates ─────────────────────────────────────────

def _detect_column(series: pd.Series, stats: dict) -> pd.DataFrame:
    """Return a DataFrame of outlier instances for one column (detection_strength ≥ 1)."""
    s = series.dropna().astype(float)
    records = []
    for idx, val in s.items():
        by_iqr     = bool(val < stats['iqr_lower'] or val > stats['iqr_upper'])
        iqr_severe = bool(val < stats['iqr_ext_lower'] or val > stats['iqr_ext_upper'])
        by_zscore  = False
        by_mzscore = False
        if stats['zscore_ok']:
            by_zscore = bool(abs((val - stats['mean']) / stats['std']) > ZSCORE_THRESHOLD)
        if stats['mzscore_ok']:
            by_mzscore = bool(
                abs(0.6745 * (val - stats['median']) / stats['mad']) > MZSCORE_THRESHOLD
            )
        strength = int(by_iqr) + int(by_zscore) + int(by_mzscore)
        if strength > 0:
            records.append({
                'row_index':          idx,
                'value':              val,
                'by_iqr':             by_iqr,
                'iqr_severe':         iqr_severe,
                'by_zscore':          by_zscore,
                'by_mzscore':         by_mzscore,
                'detection_strength': strength,
            })
    _empty = pd.DataFrame(columns=[
        'row_index', 'value', 'by_iqr', 'iqr_severe',
        'by_zscore', 'by_mzscore', 'detection_strength',
    ])
    return pd.DataFrame(records) if records else _empty


def _check_hard_bounds_column(series: pd.Series, context: str) -> pd.DataFrame:
    """Return rows that violate hard domain bounds, regardless of statistical extremity.

    These rows must be classified as invalid even if they are too small (e.g. −1
    in a count column) to be detected by IQR / z-score / MAD.
    """
    _empty = pd.DataFrame(columns=[
        'row_index', 'value', 'by_iqr', 'iqr_severe',
        'by_zscore', 'by_mzscore', 'detection_strength',
    ])
    bounds = CONTEXT_HARD_BOUNDS.get(context, {})
    if not bounds:
        return _empty
    min_bound = bounds.get('min')
    max_bound = bounds.get('max')
    s = series.dropna().astype(float)
    records = [
        {
            'row_index':          idx,
            'value':              float(val),
            'by_iqr':             False,
            'iqr_severe':         False,
            'by_zscore':          False,
            'by_mzscore':         False,
            'detection_strength': 0,
        }
        for idx, val in s.items()
        if (min_bound is not None and float(val) < min_bound)
        or (max_bound is not None and float(val) > max_bound)
    ]
    return pd.DataFrame(records) if records else _empty


# ── Step 3: Structural vs incidental ──────────────────────────────────────────

def _is_structural(
    outlier_values: pd.Series,
) -> tuple[bool, list[tuple[float, float]]]:
    """Return (is_structural, [(value, pct), ...]) for all values that individually
    account for ≥ STRUCTURAL_VALUE_MIN_FREQ of the statistically-detected outlier instances."""
    if len(outlier_values) == 0:
        return False, []
    counts = outlier_values.value_counts()
    n_total = len(outlier_values)
    structural_vals = [
        (float(val), float(cnt / n_total * 100))
        for val, cnt in counts.items()
        if cnt / n_total >= STRUCTURAL_VALUE_MIN_FREQ
    ]
    return bool(structural_vals), structural_vals


# ── Step 4: Mitigation text helpers ───────────────────────────────────────────

def _invalid_mitigation(context: str, value: float) -> str:
    bounds    = CONTEXT_HARD_BOUNDS.get(context, {})
    min_bound = bounds.get('min')
    max_bound = bounds.get('max')
    if min_bound is not None and value < min_bound:
        if context == 'count':
            return (
                f'Negative count ({value}) is impossible — '
                'set to NaN, or correct to abs(value) if a sign error is suspected.'
            )
        if context == 'duration':
            return (
                f'Negative duration ({value}) is impossible — '
                'set to NaN, or correct to abs(value) if a sign error is suspected.'
            )
        if context in ('ratio', 'percentage'):
            return f'Negative {context} ({value}) is impossible — set to NaN.'
        return (
            f'Value {value} is below the minimum allowed for context {context!r} — '
            'set to NaN or correct based on domain rules.'
        )
    if max_bound is not None and value > max_bound:
        if context in ('ratio', 'percentage'):
            return f'Value {value} exceeds 100% — physically impossible — set to NaN.'
        return (
            f'Value {value} exceeds the maximum allowed for context {context!r} — '
            'set to NaN or correct based on domain rules.'
        )
    return 'Domain constraint violated — set to NaN or correct based on domain rules.'


def _suspicious_mitigation(
    detection_strength: int,
    iqr_lower: float,
    iqr_upper: float,
    structural: bool,
    structural_vals: list[tuple[float, float]],
) -> str:
    if structural:
        vals_str  = ', '.join(f'{v:g} ({p:.0f}%)' for v, p in structural_vals)
        total_pct = sum(p for _, p in structural_vals)
        return (
            f'Structural pattern — value(s) {vals_str} collectively account for '
            f'{total_pct:.0f}% of outlier instances in this column, '
            'suggesting systematic coding errors or sentinel placeholders. '
            'Bulk correction recommended; consult the data owner to determine '
            'the correct replacement value.'
        )
    if detection_strength == 1:
        return (
            'Single-method detection — borderline outlier. '
            'Flag for manual review; may be a legitimate extreme value.'
        )
    if detection_strength == 2:
        return (
            'Detected by 2 methods — likely outlier. '
            f'Winsorize (cap at IQR fence: {iqr_lower:.2f}–{iqr_upper:.2f}) '
            'or set to NaN after domain review.'
        )
    # detection_strength == 3
    return (
        'Detected by all 3 methods — strong outlier signal. '
        f'Cap at IQR fence ({iqr_lower:.2f}–{iqr_upper:.2f}) '
        'or treat as missing; consult data owner.'
    )


# ── Step 5: Classify each outlier instance ────────────────────────────────────

def _classify_outlier(
    value: float,
    context: str,
    detection_strength: int,
    corroborated: bool,
    stats: dict,
    structural: bool,
    structural_vals: list[tuple[float, float]],
) -> tuple[str, str]:
    bounds    = CONTEXT_HARD_BOUNDS.get(context, {})
    min_bound = bounds.get('min')
    max_bound = bounds.get('max')
    neg_warn  = context in CONTEXT_WARN_NEGATIVE and value < 0
    neg_note  = (
        f' Note: negative value in {context!r} column — '
        'may be a credit/refund or sign error; verify with data owner before correcting.'
    ) if neg_warn else ''

    # Invalid: violates hard domain bound
    if (min_bound is not None and value < min_bound) or \
       (max_bound is not None and value > max_bound):
        return 'invalid', _invalid_mitigation(context, value)

    # Structural: coding artefact — takes priority over corroboration.
    # A sentinel placeholder (e.g. 999 for unknown repair time) co-occurring
    # with a high value in another column is still a coding error, not a
    # genuine extreme event.
    if structural:
        return 'structural', _suspicious_mitigation(
            detection_strength,
            stats['iqr_lower'],
            stats['iqr_upper'],
            structural,
            structural_vals,
        ) + neg_note

    # Legitimate: corroborated by another outlier column on the same row
    if corroborated:
        return 'legitimate', (
            'Extreme value corroborated by other outlier columns on the same row — '
            'likely a genuine extreme event. Retain as-is; consider log-transform '
            'or robust scaling for downstream modelling.' + neg_note
        )

    # Suspicious: borderline or strong outlier, no corroboration
    return 'suspicious', _suspicious_mitigation(
        detection_strength,
        stats['iqr_lower'],
        stats['iqr_upper'],
        structural,
        structural_vals,
    ) + neg_note


# ── Core analysis ──────────────────────────────────────────────────────────────

def _build_outputs(
    df: pd.DataFrame,
    context_map: dict[str, str],
) -> tuple[pd.DataFrame, pd.DataFrame, dict]:
    n_rows = len(df)

    # Pass 1: per-column stats + raw outlier detection
    stats_map    : dict[str, dict]         = {}
    col_out_dfs  : dict[str, pd.DataFrame] = {}
    outlier_masks: dict[str, pd.Series]    = {}

    for col in df.columns:
        context = context_map.get(col, '')
        stats = _col_stats(df[col])
        if stats is None:
            continue
        stats_map[col] = stats
        out_df         = _detect_column(df[col], stats)

        # Merge hard bound violations not already caught by statistical detection.
        # A value like -1 in a count column may fall inside the IQR fence and
        # score detection_strength = 0, yet is still domain-invalid.
        bounds_df = _check_hard_bounds_column(df[col], context)
        if not bounds_df.empty:
            already_flagged = set(out_df['row_index'].values) if not out_df.empty else set()
            new_invalid = bounds_df[~bounds_df['row_index'].isin(already_flagged)]
            if not new_invalid.empty:
                out_df = pd.concat([out_df, new_invalid], ignore_index=True)

        col_out_dfs[col]  = out_df
        mask              = pd.Series(False, index=df.index)
        if not out_df.empty:
            mask.loc[out_df['row_index'].values] = True
        outlier_masks[col] = mask

    # Row-level outlier count (cross-column corroboration)
    if outlier_masks:
        outlier_matrix     = pd.DataFrame(outlier_masks, index=df.index)
        row_outlier_counts = outlier_matrix.sum(axis=1)
    else:
        row_outlier_counts = pd.Series(0, index=df.index)

    # Structural info per column.
    # Only consider statistically-detected rows (detection_strength > 0).
    # Bounds-violation rows (detection_strength = 0) are domain-invalid entries
    # added after statistical detection; including them would dilute the
    # structural frequency and cause genuine sentinel patterns to be missed.
    structural_info: dict[str, tuple] = {
        col: _is_structural(
            out_df.loc[out_df['detection_strength'] > 0, 'value']
            if not out_df.empty else pd.Series(dtype=float)
        )
        for col, out_df in col_out_dfs.items()
    }

    # Pass 2: classify each instance
    flags_records   = []
    summary_records = []

    for col in df.columns:
        if col not in stats_map:
            continue
        stats   = stats_map[col]
        out_df  = col_out_dfs[col]
        context = context_map.get(col, '')
        structural, s_vals = structural_info[col]
        s_val     = s_vals[0][0] if s_vals else None
        s_pct     = sum(p for _, p in s_vals) if s_vals else None
        s_vals_str = ', '.join(f'{v:g} ({p:.0f}%)' for v, p in s_vals) if s_vals else None

        n_invalid = n_legitimate = n_suspicious = n_structural = 0
        neg_warn_col = False

        for _, row in out_df.iterrows():
            idx          = row['row_index']
            val          = float(row['value'])
            strength     = int(row['detection_strength'])
            corroborated = bool(row_outlier_counts.loc[idx] >= 2)

            if context in CONTEXT_WARN_NEGATIVE and val < 0:
                neg_warn_col = True

            cls, mitigation = _classify_outlier(
                value=val,
                context=context,
                detection_strength=strength,
                corroborated=corroborated,
                stats=stats,
                structural=structural,
                structural_vals=s_vals,
            )

            if   cls == 'invalid':    n_invalid    += 1
            elif cls == 'legitimate': n_legitimate += 1
            elif cls == 'structural': n_structural += 1
            else:                     n_suspicious += 1

            flags_records.append({
                'column_name':        col,
                'row_index':          int(idx),
                'value':              val,
                'iqr_lower':          round(stats['iqr_lower'], 4),
                'iqr_upper':          round(stats['iqr_upper'], 4),
                'by_iqr':             bool(row['by_iqr']),
                'iqr_severe':         bool(row['iqr_severe']),
                'by_zscore':          bool(row['by_zscore']),
                'by_mzscore':         bool(row['by_mzscore']),
                'detection_strength': strength,
                'structural':         structural,
                'corroborated':       corroborated,
                'outlier_class':      cls,
                'mitigation':         mitigation,
            })

        n_out   = len(out_df)
        pct_out = round(n_out / n_rows * 100, 2) if n_rows > 0 else 0.0

        summary_records.append({
            'column_name':        col,
            'detected_type':      'numerical',
            'context':            context,
            'n_non_null':         int(df[col].notna().sum()),
            'n_outliers':         n_out,
            'pct_outliers':       pct_out,
            'n_invalid':          n_invalid,
            'n_legitimate':       n_legitimate,
            'n_suspicious':       n_suspicious,
            'n_structural':       n_structural,
            'structural':         structural,
            'structural_value':   s_val,
            'structural_pct':     int(round(s_pct)) if s_pct is not None else None,
            'structural_values':  s_vals_str,
            'iqr_lower':          round(stats['iqr_lower'], 4),
            'iqr_upper':          round(stats['iqr_upper'], 4),
            'iqr_zero':           stats['iqr_zero'],
            'zscore_available':   stats['zscore_ok'],
            'mzscore_available':  stats['mzscore_ok'],
            'neg_amount_warning': neg_warn_col,
        })

    flags_df   = pd.DataFrame(flags_records)
    summary_df = pd.DataFrame(summary_records)

    n_cols_with = int((summary_df['n_outliers'] > 0).sum()) if not summary_df.empty else 0
    n_rows_out  = int((row_outlier_counts > 0).sum())

    meta = {
        'n_rows':                  n_rows,
        'n_cols':                  len(df.columns),
        'n_cols_with_outliers':    n_cols_with,
        'total_outlier_instances': len(flags_df),
        'n_invalid':               int(flags_df['outlier_class'].eq('invalid').sum())    if not flags_df.empty else 0,
        'n_legitimate':            int(flags_df['outlier_class'].eq('legitimate').sum()) if not flags_df.empty else 0,
        'n_suspicious':            int(flags_df['outlier_class'].eq('suspicious').sum()) if not flags_df.empty else 0,
        'n_structural':            int(flags_df['outlier_class'].eq('structural').sum()) if not flags_df.empty else 0,
        'n_rows_with_outliers':    n_rows_out,
        'pct_rows_with_outliers':  round(n_rows_out / n_rows * 100, 1) if n_rows > 0 else 0.0,
        'context_missing':         False,  # patched by analyse_outliers after _build_outputs
    }

    return flags_df, summary_df, meta


# ── HTML report ────────────────────────────────────────────────────────────────

BADGE_LABELS_CLASS = {
    'invalid':    'Invalid',
    'legitimate': 'Legitimate',
    'suspicious': 'Suspicious',
}

_HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Outliers (Numerical) — {{ stem }}</title>
<style>
  * { box-sizing: border-box; }
  body { font-family: 'Segoe UI', system-ui, sans-serif; background: #f5f6fa; color: #222; margin: 0; padding: 24px; }
  h1 { font-size: 1.5rem; font-weight: 700; color: #1a1a2e; margin-bottom: 4px; }
  h2 { font-size: 1.1rem; font-weight: 600; color: #333; margin: 28px 0 10px; }
  .subtitle { font-size: 0.82rem; color: #888; margin-bottom: 22px; }

  /* Summary strip */
  .summary-strip { display: flex; gap: 14px; flex-wrap: wrap; margin-bottom: 26px; }
  .metric { background: #fff; border-radius: 10px; padding: 14px 20px; min-width: 130px;
            box-shadow: 0 1px 4px rgba(0,0,0,.08); flex: 1; }
  .metric-label { font-size: 0.72rem; color: #aaa; text-transform: uppercase; letter-spacing: .04em; }
  .metric-value { font-size: 1.5rem; font-weight: 700; color: #1a1a2e; margin-top: 3px; }
  .metric-value.ok   { color: #2e7d32; }
  .metric-value.warn { color: #e65100; }
  .metric-value.bad  { color: #c62828; }

  /* Badges */
  .badge {
    display: inline-block; padding: 2px 9px; border-radius: 10px;
    font-size: 0.72rem; font-weight: 600; white-space: nowrap;
  }
  .badge-invalid    { background: #ffebee; color: #c62828; }
  .badge-legitimate { background: #e8f5e9; color: #2e7d32; }
  .badge-suspicious { background: #fff8e1; color: #f57f17; }
  .badge-structural { background: #e3f2fd; color: #1565c0; }
  .badge-type       { background: #f3e5f5; color: #6a1b9a; }
  .badge-context    { background: #e8eaf6; color: #3949ab; font-family: monospace; }
  .badge-warn       { background: #fff3e0; color: #e65100; cursor: default; }
  .badge-severe     { background: #fce4ec; color: #880e4f; }

  /* Legend */
  .legend { display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 24px; align-items: center; }
  .legend-item { display: flex; align-items: center; gap: 5px; font-size: 0.8rem; color: #555; }

  /* Tables */
  .table-wrap { overflow-x: auto; margin-bottom: 8px; }
  table {
    border-collapse: collapse; width: 100%; background: #fff;
    border-radius: 10px; box-shadow: 0 1px 4px rgba(0,0,0,.10); overflow: hidden;
  }
  th {
    background: #f8f9ff; font-size: 0.72rem; text-transform: uppercase;
    letter-spacing: .04em; color: #888; padding: 10px 14px;
    text-align: left; font-weight: 600;
  }
  td { padding: 8px 14px; border-top: 1px solid #f0f0f0; font-size: 0.88rem; vertical-align: middle; }
  tr:hover td { background: #fafbff; }

  /* Outlier bar */
  .out-bar-wrap { display: flex; align-items: center; gap: 8px; min-width: 130px; }
  .out-bar-bg   { flex: 1; height: 7px; background: #e0e0e0; border-radius: 4px; overflow: hidden; }
  .out-bar-fill { height: 100%; border-radius: 4px; }
  .out-val      { font-size: 0.78rem; min-width: 44px; text-align: right; color: #555; }
  .bar-green  { background: #4caf50; }
  .bar-amber  { background: #ff9800; }
  .bar-red    { background: #f44336; }

  /* Detail cards */
  .cards { display: grid; grid-template-columns: repeat(auto-fill, minmax(480px, 1fr)); gap: 20px; margin-bottom: 32px; }
  .card  { background: #fff; border-radius: 10px; box-shadow: 0 1px 4px rgba(0,0,0,.10); padding: 18px 22px; }
  .card-header { display: flex; align-items: center; gap: 8px; margin-bottom: 14px; flex-wrap: wrap; }
  .card-title  { font-size: 1rem; font-weight: 600; color: #1a1a2e; }
  .section-label {
    font-size: 0.68rem; color: #aaa; text-transform: uppercase;
    letter-spacing: .05em; margin: 12px 0 5px;
  }
  .stats-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 6px 16px; font-size: 0.83rem; }
  .stats-grid dt { color: #888; }
  .stats-grid dd { font-weight: 600; margin: 0; font-family: monospace; }
  .class-row { display: flex; gap: 10px; flex-wrap: wrap; margin: 6px 0; }
  .warn-box {
    background: #fff8f3; border-left: 3px solid #e65100;
    padding: 9px 13px; border-radius: 0 6px 6px 0;
    font-size: 0.83rem; line-height: 1.5; color: #333; margin: 8px 0;
  }
  .warn-box.neg { border-left-color: #f57f17; background: #fffdf5; }
  .rec-box { padding: 9px 13px; border-radius: 0 6px 6px 0; border-left: 3px solid #ccc; font-size: 0.83rem; line-height: 1.5; color: #333; margin: 5px 0; }
  .rec-box.rec-invalid    { background: #ffebee; border-left-color: #c62828; }
  .rec-box.rec-structural { background: #e3f2fd; border-left-color: #1565c0; }
  .rec-box.rec-suspicious { background: #fff8e1; border-left-color: #f57f17; }
  .rec-box.rec-legitimate { background: #e8f5e9; border-left-color: #2e7d32; }
  .instance-table { width: 100%; border-collapse: collapse; font-size: 0.8rem; margin-top: 6px; }
  .instance-table th { background: #f8f9ff; padding: 5px 8px; text-align: left;
                       font-size: 0.7rem; color: #888; border-bottom: 1px solid #e8e8e8; }
  .instance-table td { padding: 5px 8px; border-bottom: 1px solid #f4f4f4; vertical-align: middle; }
  .instance-table tr:last-child td { border-bottom: none; }
  .check   { color: #2e7d32; font-weight: 700; }
  .dash    { color: #bbb; }
  .more-note { font-size: 0.75rem; color: #999; text-align: right; margin-top: 4px; }
</style>
</head>
<body>

<h1>Outliers (Numerical) — {{ stem }}</h1>
<div class="subtitle">
  Source: {{ source_file }} &nbsp;·&nbsp;
  {{ meta.n_rows }} rows &nbsp;·&nbsp;
  {{ meta.n_cols }} numerical column(s) analysed
  &nbsp;·&nbsp; Generated {{ generated }}
</div>

{% if meta.context_missing %}
<div class="warn-box" style="margin-bottom: 16px;">
  ⚠ Context file not available — domain-bound validation (<span class="badge badge-invalid" style="font-size:0.75rem;">invalid</span> classification) is disabled.
  Run the <code>context-numerical</code> skill first to enable it.
</div>
{% endif %}

<!-- Summary strip -->
<div class="summary-strip">
  <div class="metric">
    <div class="metric-label">Total rows</div>
    <div class="metric-value">{{ meta.n_rows }}</div>
  </div>
  <div class="metric">
    <div class="metric-label">Rows with outliers</div>
    <div class="metric-value {{ 'ok' if meta.n_rows_with_outliers == 0 else 'warn' }}">
      {{ meta.pct_rows_with_outliers }}%
    </div>
  </div>
  <div class="metric">
    <div class="metric-label">Columns affected</div>
    <div class="metric-value {{ 'ok' if meta.n_cols_with_outliers == 0 else 'warn' }}">
      {{ meta.n_cols_with_outliers }} / {{ meta.n_cols }}
    </div>
  </div>
  <div class="metric">
    <div class="metric-label">Invalid</div>
    <div class="metric-value {{ 'bad' if meta.n_invalid > 0 else 'ok' }}">{{ meta.n_invalid }}</div>
  </div>
  <div class="metric">
    <div class="metric-label">Structural</div>
    <div class="metric-value {{ 'warn' if meta.n_structural > 0 else 'ok' }}">{{ meta.n_structural }}</div>
  </div>
  <div class="metric">
    <div class="metric-label">Suspicious</div>
    <div class="metric-value {{ 'warn' if meta.n_suspicious > 0 else 'ok' }}">{{ meta.n_suspicious }}</div>
  </div>
  <div class="metric">
    <div class="metric-label">Legitimate</div>
    <div class="metric-value">{{ meta.n_legitimate }}</div>
  </div>
</div>

<!-- Legend -->
<div class="legend">
  <strong style="font-size:.8rem; color:#555;">Classification:</strong>
  <div class="legend-item"><span class="badge badge-invalid">Invalid</span> violates domain bound</div>
  <div class="legend-item"><span class="badge badge-structural">Structural</span> repeated sentinel value — likely coding artefact</div>
  <div class="legend-item"><span class="badge badge-suspicious">Suspicious</span> statistically extreme, needs review</div>
  <div class="legend-item"><span class="badge badge-legitimate">Legitimate</span> corroborated by other columns</div>
</div>

<!-- Overview table -->
<h2>Column overview</h2>
<div class="table-wrap">
<table>
  <thead>
    <tr>
      <th>Column</th>
      <th>Context</th>
      <th>Outliers</th>
      <th>Invalid</th>
      <th>Structural</th>
      <th>Suspicious</th>
      <th>Legitimate</th>
      <th>Flags</th>
    </tr>
  </thead>
  <tbody>
  {% for col in summary %}
    <tr>
      <td><strong>{{ col.column_name }}</strong></td>
      <td>
        {% if col.context %}<span class="badge badge-context">{{ col.context }}</span>{% else %}—{% endif %}
      </td>
      <td>
        <div class="out-bar-wrap">
          <div class="out-bar-bg">
            <div class="out-bar-fill {{ 'bar-green' if col.pct_outliers <= 2 else ('bar-amber' if col.pct_outliers <= 10 else 'bar-red') }}"
                 style="width: {{ [col.pct_outliers, 100]|min }}%"></div>
          </div>
          <span class="out-val">{{ col.n_outliers }} ({{ col.pct_outliers }}%)</span>
        </div>
      </td>
      <td>{{ col.n_invalid if col.n_invalid > 0 else '—' }}</td>
      <td>{{ col.n_structural if col.n_structural > 0 else '—' }}</td>
      <td>{{ col.n_suspicious if col.n_suspicious > 0 else '—' }}</td>
      <td>{{ col.n_legitimate if col.n_legitimate > 0 else '—' }}</td>
      <td>
        {% if col.structural %}<span class="badge badge-structural">Structural</span> {% endif %}
        {% if col.neg_amount_warning %}<span class="badge badge-warn" title="Negative values in this column — may be credits/refunds">⚠ negative values</span>{% endif %}
        {% if col.iqr_zero %}<span class="badge badge-warn" title="IQR = 0: most values are identical; all deviations flagged">IQR = 0</span>{% endif %}
      </td>
    </tr>
  {% endfor %}
  </tbody>
</table>
</div>

<!-- Co-occurrence: rows with multiple outlier columns -->
{% if co_occurrence %}
<h2>Rows with outliers in multiple columns</h2>
<p style="font-size:.83rem; color:#666; margin-bottom:8px;">
  {{ co_occurrence|length }} row(s) have outlier values in 2 or more columns simultaneously.
  These are candidates for genuine extreme events (corroborated) rather than data entry errors.
</p>
<div class="table-wrap">
<table>
  <thead>
    <tr>
      <th>Row index</th>
      <th>Columns (value)</th>
    </tr>
  </thead>
  <tbody>
  {% for row in co_occurrence %}
    <tr>
      <td>{{ row.row_index }}</td>
      <td>{{ row.cols_summary }}</td>
    </tr>
  {% endfor %}
  </tbody>
</table>
</div>
{% endif %}

<!-- Column detail cards -->
<h2>Column analysis</h2>
<div class="cards">
{% for col in summary %}
  {% if col.n_outliers > 0 %}
  <div class="card">
    <div class="card-header">
      <span class="card-title">{{ col.column_name }}</span>
      <span class="badge badge-type">numerical</span>
      {% if col.context %}<span class="badge badge-context">{{ col.context }}</span>{% endif %}
      {% if col.structural %}<span class="badge badge-structural">Structural</span>{% endif %}
    </div>

    <div class="section-label">Detection bounds</div>
    <dl class="stats-grid">
      <dt>IQR fence</dt><dd>{{ col.iqr_lower }} – {{ col.iqr_upper }}</dd>
      <dt>Z-score (|z| &gt; {{ zscore_threshold }})</dt><dd>{{ '✓ active' if col.zscore_available else '— unavailable' }}</dd>
      <dt>Mod. z-score (|mz| &gt; {{ mzscore_threshold }})</dt><dd>{{ '✓ active' if col.mzscore_available else '— unavailable' }}</dd>
      {% if col.iqr_zero %}<dt style="color:#e65100">IQR = 0</dt><dd style="color:#e65100">All non-modal values flagged</dd>{% endif %}
    </dl>

    <div class="section-label">Classification</div>
    <div class="class-row">
      {% if col.n_invalid > 0 %}<span class="badge badge-invalid">{{ col.n_invalid }} invalid</span>{% endif %}
      {% if col.n_structural > 0 %}<span class="badge badge-structural">{{ col.n_structural }} structural</span>{% endif %}
      {% if col.n_suspicious > 0 %}<span class="badge badge-suspicious">{{ col.n_suspicious }} suspicious</span>{% endif %}
      {% if col.n_legitimate > 0 %}<span class="badge badge-legitimate">{{ col.n_legitimate }} legitimate</span>{% endif %}
    </div>

    <div class="section-label">Recommendations</div>
    {% if col.n_invalid > 0 %}
    <div class="rec-box rec-invalid">
      <strong>Invalid ({{ col.n_invalid }}):</strong> Set to NaN and investigate the data source — these values violate a domain constraint (e.g. negative count, ratio &gt; 100%). If systematic, trace and fix the upstream extraction process.
    </div>
    {% endif %}
    {% if col.n_structural > 0 %}
    <div class="rec-box rec-structural">
      <strong>Structural ({{ col.n_structural }}):</strong> Likely sentinel placeholders. Confirm the intended meaning with the data owner, then apply a bulk substitution (replace with NaN or the correct value).
    </div>
    {% endif %}
    {% if col.n_suspicious > 0 %}
    <div class="rec-box rec-suspicious">
      <strong>Suspicious ({{ col.n_suspicious }}):</strong> Statistically extreme value(s) flagged by one or more detection methods. Winsorize at the IQR fences ({{ col.iqr_lower }} – {{ col.iqr_upper }}), or investigate individually. Prioritise multi-method detections (strength ≥ 2).
    </div>
    {% endif %}
    {% if col.n_legitimate > 0 %}
    <div class="rec-box rec-legitimate">
      <strong>Legitimate ({{ col.n_legitimate }}):</strong> Corroborated by outliers in other columns in the same row — likely genuine extreme events. Retain and document; if downstream models are sensitive to extremes, consider robust scaling.
    </div>
    {% endif %}

    {% if col.neg_amount_warning %}
    <div class="warn-box neg">
      ⚠ Negative values detected in <code>{{ col.context }}</code> column —
      may represent credits or refunds. Verify with data owner before treating as invalid.
    </div>
    {% endif %}

    <div class="section-label">Outlier instances{% if instances[col.column_name]|length > 50 %} (top 50 shown){% endif %}</div>
    <table class="instance-table">
      <thead>
        <tr>
          <th>Row</th>
          <th>Value</th>
          <th>IQR</th>
          <th>Severe</th>
          <th>Z</th>
          <th>MZ</th>
          <th>Strength</th>
          <th>Class</th>
        </tr>
      </thead>
      <tbody>
      {% for inst in instances[col.column_name][:50] %}
        <tr>
          <td>{{ inst.row_index }}</td>
          <td><strong>{{ inst.value }}</strong></td>
          <td class="{{ 'check' if inst.by_iqr else 'dash' }}">{{ '✓' if inst.by_iqr else '—' }}</td>
          <td class="{{ 'check' if inst.iqr_severe else 'dash' }}">{{ '✓' if inst.iqr_severe else '—' }}</td>
          <td class="{{ 'check' if inst.by_zscore else 'dash' }}">{{ '✓' if inst.by_zscore else '—' }}</td>
          <td class="{{ 'check' if inst.by_mzscore else 'dash' }}">{{ '✓' if inst.by_mzscore else '—' }}</td>
          <td>{{ inst.detection_strength }}/3</td>
          <td><span class="badge badge-{{ inst.outlier_class }}">{{ inst.outlier_class }}</span></td>
        </tr>
      {% endfor %}
      </tbody>
    </table>
    {% if instances[col.column_name]|length > 50 %}
    <div class="more-note">… {{ instances[col.column_name]|length - 50 }} more instances not shown — see flags CSV for full list.</div>
    {% endif %}
  </div>
  {% else %}
  <div class="card">
    <div class="card-header">
      <span class="card-title">{{ col.column_name }}</span>
      <span class="badge badge-type">numerical</span>
      {% if col.context %}<span class="badge badge-context">{{ col.context }}</span>{% endif %}
    </div>
    <p style="color:#888; font-size:.85rem; margin:0;">No outliers detected.</p>
  </div>
  {% endif %}
{% endfor %}
</div>

</body>
</html>
"""


def render_html(
    flags_df: pd.DataFrame,
    summary_df: pd.DataFrame,
    co_occurrence: list[dict],
    meta: dict,
    stem: str,
    source_file: str,
) -> str:
    summary = summary_df.to_dict(orient='records')

    # Per-column instance lists (sorted by detection_strength desc, then abs value desc)
    instances: dict[str, list] = {}
    if not flags_df.empty:
        for col, grp in flags_df.groupby('column_name', sort=False):
            grp_sorted = grp.sort_values(
                ['detection_strength', 'value'],
                ascending=[False, False],
            )
            instances[col] = grp_sorted.to_dict(orient='records')
    for col_row in summary:
        instances.setdefault(col_row['column_name'], [])

    env = Environment(loader=BaseLoader())
    env.filters['min'] = min
    tmpl = env.from_string(_HTML_TEMPLATE)
    return tmpl.render(
        stem=stem,
        source_file=source_file,
        meta=meta,
        summary=summary,
        instances=instances,
        co_occurrence=co_occurrence,
        zscore_threshold=ZSCORE_THRESHOLD,
        mzscore_threshold=MZSCORE_THRESHOLD,
        generated=datetime.now().strftime('%Y-%m-%d %H:%M'),
    )


# ── Public API ─────────────────────────────────────────────────────────────────

def analyse_outliers(
    cleaned_path: str | Path,
    context_flags_path: str | Path | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame, list[dict], dict]:
    cleaned_path         = Path(cleaned_path)
    context_flags_path   = Path(context_flags_path) if context_flags_path else None
    context_missing      = context_flags_path is None or not context_flags_path.exists()
    if context_missing:
        path_str = str(context_flags_path) if context_flags_path else 'not provided'
        print(f'  ⚠  Context file not found ({path_str}).')
        print('     Domain-bound validation (invalid class) is disabled.')
        print('     Run context-numerical first to enable it.')
    df           = pd.read_csv(cleaned_path)
    context_map  = _load_context_map(None if context_missing else context_flags_path)

    flags_df, summary_df, meta = _build_outputs(df, context_map)
    meta['context_missing'] = context_missing

    # Co-occurrence: rows with outliers in 2+ columns
    co_occurrence: list[dict] = []
    if not flags_df.empty:
        grp = (
            flags_df.groupby('row_index')
            .apply(lambda g: list(zip(g['column_name'], g['value'])))
            .reset_index()
        )
        grp.columns = ['row_index', 'col_val_pairs']
        grp = grp[grp['col_val_pairs'].apply(len) >= 2].copy()
        grp['n_cols'] = grp['col_val_pairs'].apply(len)
        grp = grp.sort_values('n_cols', ascending=False).head(20)
        for _, row in grp.iterrows():
            pairs = row['col_val_pairs']
            co_occurrence.append({
                'row_index':   int(row['row_index']),
                'cols_summary': ', '.join(f'{c} = {v:.4g}' for c, v in pairs),
            })

    return flags_df, summary_df, co_occurrence, meta


def save_outputs(stem: str) -> None:
    cleaned_path = INPUT_DIR   / f'{stem}_numerical_cleaned.csv'
    context_path = CONTEXT_DIR / f'{stem}_type_flags_context.csv'

    flags_df, summary_df, co_occurrence, meta = analyse_outliers(
        cleaned_path=cleaned_path,
        context_flags_path=context_path,
    )

    flags_path   = OUTPUT_DIR / f'{stem}_outlier_flags.csv'
    summary_path = OUTPUT_DIR / f'{stem}_outlier_summary.csv'
    html_path    = OUTPUT_DIR / f'{stem}_outlier_report.html'

    flags_df.to_csv(flags_path,   index=False)
    summary_df.to_csv(summary_path, index=False)

    html = render_html(
        flags_df=flags_df,
        summary_df=summary_df,
        co_occurrence=co_occurrence,
        meta=meta,
        stem=stem,
        source_file=cleaned_path.name,
    )
    html_path.write_text(html, encoding='utf-8')

    print(f'Flags CSV    -> {flags_path}')
    print(f'Summary CSV  -> {summary_path}')
    print(f'HTML report  -> {html_path}')
    print()
    n_out = meta['total_outlier_instances']
    n_inv = meta['n_invalid']
    n_sus = meta['n_suspicious']
    n_leg = meta['n_legitimate']
    print(
        f'  {n_out} outlier instance(s) across {meta["n_cols_with_outliers"]}/{meta["n_cols"]} column(s) '
        f'({meta["pct_rows_with_outliers"]}% of rows affected)'
    )
    if n_out:
        print(f'  invalid={n_inv}  structural={meta["n_structural"]}  suspicious={n_sus}  legitimate={n_leg}')
    print()

    summary_rows = summary_df[summary_df['n_outliers'] > 0]
    for _, row in summary_rows.iterrows():
        structural_note = ' [structural]' if row['structural'] else ''
        neg_note        = ' [⚠ negative values]' if row['neg_amount_warning'] else ''
        print(
            f'  {row["column_name"]:<30} '
            f'{row["n_outliers"]:>4} outliers ({row["pct_outliers"]:5.1f}%)  '
            f'invalid={row["n_invalid"]}  structural={row["n_structural"]}  '
            f'suspicious={row["n_suspicious"]}  legitimate={row["n_legitimate"]}'
            f'{structural_note}{neg_note}'
        )


# ── Entry point ────────────────────────────────────────────────────────────────

if __name__ == '__main__':
    stems = [sys.argv[1]] if len(sys.argv) > 1 else STEMS
    for stem in stems:
        print('=' * 60)
        print(f'Analysing: {stem}')
        print('=' * 60)
        save_outputs(stem)
