# Methodology: Analyse Outliers — Numerical Columns

## Purpose

This skill is the sixth step in the AI Data Cleaning pipeline. It takes the output of the `clean-numerical` skill and performs a four-step outlier analysis on every **numerical** column. The skill does **not** modify any data — its sole output is a diagnosis and a set of targeted recommendations per outlier instance.

---

## Folder Structure

```
skill/
├── clean_numerical/
│   └── output/
│       └── <name>_numerical_cleaned.csv     ← input: cleaned numerical columns
├── context_numerical/
│   └── output/
│       └── <name>_type_flags_context.csv    ← input (optional)
└── analyse_outliers_numerical/
    ├── analyse_outliers_numerical.py
    ├── METHODOLOGY.md
    ├── SKILL.md
    ├── requirements.txt
    └── output/
        ├── <name>_outlier_flags.csv         ← output: one row per outlier instance
        ├── <name>_outlier_summary.csv       ← output: one row per column
        └── <name>_outlier_report.html       ← output: HTML report
```

---

## Inputs

| File | Source | Purpose |
|---|---|---|
| `<name>_numerical_cleaned.csv` | `clean-numerical` skill | Cleaned numerical columns with proper NaN values |
| `<name>_type_flags_context.csv` | `context-numerical` skill (**strongly recommended**) | Semantic type labels for context-aware hard bounds and negative value warnings. Without this file the skill cannot classify any instance as `invalid`; a warning is printed to the console and shown in the HTML report. |

---

## Outputs

| File | Description |
|---|---|
| `<name>_outlier_flags.csv` | One row per outlier instance; columns: `column_name`, `row_index`, `value`, `iqr_lower`, `iqr_upper`, `by_iqr`, `iqr_severe`, `by_zscore`, `by_mzscore`, `detection_strength`, `structural`, `corroborated`, `outlier_class`, `mitigation` |
| `<name>_outlier_summary.csv` | One row per column; columns: `column_name`, `detected_type`, `context`, `n_non_null`, `n_outliers`, `pct_outliers`, `n_invalid`, `n_legitimate`, `n_suspicious`, `n_structural`, `structural`, `structural_value`, `structural_pct`, `structural_values`, `iqr_lower`, `iqr_upper`, `iqr_zero`, `zscore_available`, `mzscore_available`, `neg_amount_warning` |
| `<name>_outlier_report.html` | Self-contained HTML — all CSS inlined, no external assets required |

The `_outlier_flags.csv` is designed to be consumed by a future `clean-outliers` skill.

---

## Analysis Steps

### Step 1 — Detect outlier candidates (three independent methods)

Each non-null value in every column is tested against three independent detection methods:

**IQR (Tukey's fence)**
```
iqr_lower = Q1 − 1.5 × IQR
iqr_upper = Q3 + 1.5 × IQR
```
A value is flagged (`by_iqr = True`) if it falls outside this range. An additional severity flag (`iqr_severe`) is set when the value lies beyond the extreme fence (3 × IQR multiplier).

**Z-score**
```
z = (x − mean) / std
```
Flagged (`by_zscore = True`) when |z| > `ZSCORE_THRESHOLD` (default 3.0). Assumes approximate normality. Skipped when std = 0 or when fewer than `MIN_SAMPLE_FOR_STATS` (default 10) non-null values are available.

**Modified z-score (MAD-based)**
```
mz = 0.6745 × (x − median) / MAD
```
Flagged (`by_mzscore = True`) when |mz| > `MZSCORE_THRESHOLD` (default 3.5, per Iglewicz & Hoaglin 1993). More robust than the standard z-score because it uses the median and MAD instead of mean and standard deviation. Skipped when MAD = 0 or sample is too small.

**Detection strength**

`detection_strength = by_iqr + by_zscore + by_mzscore` (range 0–3). A value is an outlier candidate when `detection_strength ≥ 1`. Higher strength indicates greater evidence.

**IQR = 0 edge case**

When IQR = 0 (most values are identical), the IQR fence collapses to Q1 = Q3. Every value that differs from the modal value is then flagged by IQR. This is correct behaviour but may produce many candidates for columns with very low variance. The summary CSV and HTML report flag this condition explicitly (`iqr_zero = True`).

---

### Step 2 — Structural vs incidental

After detection, each column's **statistical** outlier instances (detection_strength ≥ 1) are examined for repeating values:

- Any individual value that accounts for ≥ `STRUCTURAL_VALUE_MIN_FREQ` (default 20%) of statistical outlier instances in that column is treated as a structural sentinel. Multiple values can qualify simultaneously — all are recorded in the `structural_values` summary field.
- A column is classified as **structural** if at least one such value exists, suggesting sentinel placeholders or systematic coding errors.
- Otherwise the column is **incidental** (diverse values, one-off extremes).

> **Note:** bounds-only violations (detection_strength = 0, e.g. negative duration values) are excluded from the structural frequency calculation so that a large batch of domain-invalid values does not dilute the frequency of true sentinel values.

Structural patterns warrant bulk correction; incidental patterns require case-by-case review.

---

### Step 3 — Validation

Two validation checks run on every outlier candidate:

**Context-aware hard bounds (→ invalid)**

| Context | Rule |
|---|---|
| `count` | value < 0 |
| `ratio` / `percentage` | value < 0 or value > 100 |
| `duration` | value < 0 |

A value that violates a hard bound is classified as `invalid` regardless of detection strength or corroboration.

**Negative value warning (soft)**

Columns with context `amount`, `cost`, or `price` may legitimately have negative values (credits, refunds). These are not classified as invalid but trigger a warning note appended to the mitigation text.

**Cross-column corroboration (→ legitimate candidate)**

For each row, the number of numerical columns with at least one outlier instance is counted. If ≥ 2 columns on the same row are simultaneously extreme, those instances are corroboration candidates — more likely to be genuine extreme events than isolated data entry errors.

---

### Step 4 — Final classification

Each outlier instance receives one of four labels, evaluated in strict priority order:

| Priority | Class | Condition |
|---|---|---|
| 1 | `invalid` | Violates a context-aware hard bound — overrides all other checks |
| 2 | `structural` | Column has a structural pattern — bulk-correction recommended regardless of corroboration |
| 3 | `legitimate` | Row is corroborated (≥ 2 outlier columns simultaneously) and not invalid or structural |
| 4 | `suspicious` | All remaining cases |

Mitigation text scales with the class and detection strength:

| Condition | Mitigation |
|---|---|
| `structural` | Likely sentinel placeholders — confirm with data owner; bulk substitution recommended |
| `suspicious`, detection_strength = 1 | Flag for manual review; may be legitimate |
| `suspicious`, detection_strength = 2 | Winsorize (cap at IQR fence) or set to NaN after domain review |
| `suspicious`, detection_strength = 3 | Cap at IQR fence or treat as missing; consult data owner |

---

## Tuning Parameters

| Constant | Default | Effect |
|---|---|---|
| `IQR_MULTIPLIER` | `1.5` | Standard Tukey fence multiplier |
| `IQR_EXTREME_MULTIPLIER` | `3.0` | Extreme fence multiplier; sets `iqr_severe` flag |
| `ZSCORE_THRESHOLD` | `3.0` | |z| above which a value is flagged by z-score |
| `MZSCORE_THRESHOLD` | `3.5` | |mz| above which a value is flagged by modified z-score (Iglewicz & Hoaglin) |
| `STRUCTURAL_VALUE_MIN_FREQ` | `0.20` | Minimum fraction of **statistical** outlier instances a single value must represent to be classified as a structural sentinel; multiple values can qualify per column |
| `MIN_SAMPLE_FOR_STATS` | `10` | Minimum non-null rows required to compute z-score and modified z-score |

---

## Known Boundary Cases

- **Corroboration ≠ legitimacy**: two columns being simultaneously extreme proves they are related but not that either value is correct. `legitimate` is a candidate label — final legitimacy still requires domain review.
- **Structural detection is multi-value**: all individual values that each account for ≥ `STRUCTURAL_VALUE_MIN_FREQ` (20%) of statistical outlier instances are recorded. The `structural_values` field in the summary CSV lists all qualifying values with their individual percentages (e.g. `999 (50%), 9999 (50%)`). `structural_pct` contains the collective sum of those percentages. The legacy `structural_value` field retains the first qualifying value for backward compatibility.
- **IQR fence may miss bimodal outliers**: for heavily skewed or bimodal distributions, the IQR fence can be asymmetric and may not capture outliers on one tail. The z-score and modified z-score provide complementary coverage.
- **Context map not available**: the skill runs normally; no hard bounds are applied and no negative-value warnings are raised.

---

## Observed Results on Defence Datasets

| Column | Dataset | Outliers | Structural | Key finding |
|---|---|---|---|---|
| `hersteltijd_uur` | onderhoud_materieel | 115 (2.2%) | Yes — 999 (50%), 9999 (50%) | 53 invalid (negative duration); 62 structural (31 × 999 and 31 × 9999 — sentinel placeholders); bulk correction needed |
| `kosten_eur` | onderhoud_materieel | 159 (3.0%) | No | Diverse extreme repair costs; 2 legitimate corroborated events; 157 suspicious for review |
| `aantal_uitzendingen` | personeel_hr | 13 (0.2%) | Yes (all −1) | 13 invalid negative count values; structural pattern confirms systematic entry error |
