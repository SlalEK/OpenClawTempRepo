"""
Analyse Missing Values — Numerical Columns
-------------------------------------------
Reads the clean_numerical output (numerical columns only), the detect_data_types
raw copy (full dataset, for cross-column patterns), and optionally the
context_numerical output, then runs a five-step missing-value analysis:

    1. Identify     -- NaN count and % per numerical column
    2. Patterns     -- co-occurrence pairs and row-level missingness distribution
                       computed over the FULL dataset (all column types) so that
                       structural data-collection gaps are visible even when the
                       missing column is non-numerical
    3. Correlate    -- point-biserial correlation between each numerical column's
                       missingness indicator and all numerical values in the full
                       dataset (MAR detection across the whole record)
    4. Classify     -- assigns one of:
                         none         -- no missing values
                         trace        -- < 1 % NaN, negligible
                         mcar_likely  -- random, uncorrelated with other columns
                         mar_likely   -- missingness correlates with observed values
                         mnar_suspect -- high rate, no observable cause
                         ambiguous    -- count column with blank cells; true mechanism
                                        cannot be determined until data owner confirms
                                        whether blanks represent 0 or missing values

The skill does NOT impute or modify any data. It recommends mitigation strategies.

Inputs
    <name>_numerical_cleaned.csv        from skill/clean_numerical/output/
    <name>_raw_copy.csv                 from skill/detect_data_types/output/  (full-dataset patterns)
    <name>_type_flags_context.csv       from skill/context_numerical/output/ (optional)

Outputs
    <name>_missing_flags.csv      -- one row per missing value instance (row index, raw value, miss type, mitigation)
    <name>_missing_summary.csv    -- machine-readable per-column classification
    <name>_missing_report.html    -- self-contained HTML report
"""

import pandas as pd
import numpy as np
import sys
from pathlib import Path
from jinja2 import Environment, BaseLoader


# ── Folder layout ─────────────────────────────────────────────────────────────
BASE_DIR        = Path(__file__).parent
OUTPUT_DIR      = BASE_DIR / 'output'
INPUT_DIR       = BASE_DIR.parent / 'clean_numerical' / 'output'
RAW_COPY_DIR    = BASE_DIR.parent / 'detect_data_types' / 'output'
CONTEXT_DIR     = BASE_DIR.parent / 'context_numerical' / 'output'


# ── Tuning parameters ─────────────────────────────────────────────────────────

# Null-like string tokens that should be treated as missing in the raw copy
# (mirrored from clean_numerical so pattern analysis is consistent)
NULL_LIKE_TOKENS = {
    'na', 'n/a', 'n.v.t.', 'nvt',
    'null', 'none', 'nil',
    'nan', '-', '--', '---',
    '?', 'onbekend', 'unknown',
    'missing', 'leeg', '',
}

# |r| >= this between a missingness indicator and another column's values -> MAR
MAR_CORR_THRESHOLD = 0.15
# > this % NaN with no MAR signal → MNAR suspect
MNAR_MISS_THRESHOLD = 10.0
# < this % NaN → classify as trace / trivially MCAR
TRACE_MISS_THRESHOLD = 1.0

# ── Step 1: (null-like normalisation handled upstream by clean_numerical) ─────

def _normalise_nulls_for_patterns(df: pd.DataFrame) -> pd.DataFrame:
    """
    Replace null-like string tokens with NaN across all object columns.

    Applied to the raw copy before using it for pattern analysis so that
    values like 'nvt', '-', 'onbekend' are counted as missing even in
    columns that have not yet been cleaned by a dedicated cleaning skill.
    """
    df = df.copy()
    for col in df.select_dtypes(include=['object', 'string']).columns:
        mask = df[col].astype(str).str.strip().str.lower().isin(NULL_LIKE_TOKENS)
        df.loc[mask, col] = np.nan
    return df


# ── Step 2: Pattern analysis ──────────────────────────────────────────────────

def _cooccurrence_pairs(
    df: pd.DataFrame,
    numerical_cols: set[str],
) -> list[dict]:
    """
    Pairs of columns (from the full dataset) that are missing on the same rows,
    filtered to pairs where at least one column is a numerical column being
    analysed. Sorted by co-missing count descending.
    """
    miss_cols = [c for c in df.columns if df[c].isna().any()]
    pairs, n = [], len(df)
    for i, c1 in enumerate(miss_cols):
        for c2 in miss_cols[i + 1:]:
            # Skip pairs that have no connection to the numerical columns
            if c1 not in numerical_cols and c2 not in numerical_cols:
                continue
            both = int((df[c1].isna() & df[c2].isna()).sum())
            if both > 0:
                pairs.append({
                    'col1': c1, 'col2': c2,
                    'both_missing': both,
                    'pct_of_rows': round(both / n * 100, 2),
                })
    return sorted(pairs, key=lambda x: x['both_missing'], reverse=True)


def _row_miss_distribution(df: pd.DataFrame) -> list[dict]:
    """How many rows have exactly 0, 1, 2 … k missing columns."""
    counts = df.isna().sum(axis=1).value_counts().sort_index()
    n = len(df)
    return [
        {'n_missing_cols': int(k), 'row_count': int(v), 'pct': round(int(v) / n * 100, 1)}
        for k, v in counts.items()
    ]


# ── Step 3: MAR correlation ───────────────────────────────────────────────────

def _value_vs_miss_correlations(
    df_target: pd.DataFrame,
    df_context: pd.DataFrame,
) -> dict[str, list[tuple[str, float]]]:
    """
    Point-biserial correlation: for each numerical column in *df_target* that
    has NaN values, compute the Pearson correlation between its binary
    missingness indicator (1=missing, 0=present) and the numeric values of
    every column in *df_context*.

    Using the full dataset as *df_context* means the MAR search covers all
    column types, not just the cleaned numerical subset.

    Returns {column: [(correlated_col, r), ...]} sorted by |r| descending,
    filtered to |r| ≥ MAR_CORR_THRESHOLD.
    """
    # Coerce all context columns to numeric; non-convertible values become NaN
    num_context = df_context.apply(pd.to_numeric, errors='coerce')
    result: dict[str, list[tuple[str, float]]] = {}

    for col in df_target.columns:
        n_miss = int(df_target[col].isna().sum())
        if n_miss == 0 or n_miss == len(df_target):
            result[col] = []
            continue

        indicator = df_target[col].isna().astype(float)
        corrs: list[tuple[str, float]] = []

        for other in num_context.columns:
            if other == col:
                continue
            aligned = pd.concat(
                [indicator.rename('miss'), num_context[other].rename('val')], axis=1
            ).dropna()
            if len(aligned) < 20:
                continue
            if aligned['miss'].std() == 0 or aligned['val'].std() == 0:
                continue
            r = float(aligned['miss'].corr(aligned['val']))
            if pd.notna(r) and abs(r) >= MAR_CORR_THRESHOLD:
                corrs.append((other, round(r, 3)))

        corrs.sort(key=lambda x: abs(x[1]), reverse=True)
        result[col] = corrs

    return result


# ── Step 4: Classification ────────────────────────────────────────────────────

def _classify(pct_missing: float, mar_cors: list[tuple[str, float]]) -> str:
    if pct_missing == 0.0:
        return 'none'
    if pct_missing < TRACE_MISS_THRESHOLD:
        return 'trace'
    if mar_cors:
        return 'mar_likely'
    if pct_missing > MNAR_MISS_THRESHOLD:
        return 'mnar_suspect'
    return 'mcar_likely'


# ── Step 5: Recommendations ───────────────────────────────────────────────────

_STATIC_RECS: dict[str, str] = {
    'none': 'No NaN values detected — no action required.',
    'ambiguous': (
        'Blank cells in a count column — the true missingness mechanism cannot be '
        'determined until the data owner confirms whether blanks represent 0 or '
        'missing observations. Verify before imputing.'
    ),
    # (kept as fallback; normally the zero-ambiguity block in _recommendation fires first)
    'trace': (
        'Fewer than 1% of values are missing. '
        'Safe to drop affected rows or impute with column median / mode '
        'with negligible data loss.'
    ),
    'mcar_likely': (
        'Missingness appears random and uncorrelated with other columns '
        '(MCAR — Missing Completely At Random). '
        'Impute with column median (numerical) or mode (categorical), '
        'or drop rows if the dataset is large enough. '
        'Note: low-rate MNAR is statistically indistinguishable from MCAR — '
        'if domain knowledge suggests that extreme or sensitive values in this '
        'column are systematically absent, treat as potential MNAR and consult '
        'the data owner before imputing.'
    ),
    'mnar_suspect': (
        'High missingness rate with no detectable correlation to other columns. '
        'Consistent with MNAR (Missing Not At Random) — values may be absent '
        'because of their own unobserved magnitude (e.g. extreme values are '
        'systematically not recorded). '
        'Do not impute without domain knowledge. Consult a data owner.'
    ),
}


def _recommendation(
    cls: str,
    mar_cors: list[tuple[str, float]],
    n_empty: int = 0,
    context: str = '',
    pct_missing: float = 0.0,
) -> str:
    # Zero-ambiguity override: count columns where blanks may be intentional zeros
    if context == 'count' and n_empty > 0:
        base = (
            f'{n_empty} of the missing value(s) are blank cells in a '
            f'<code>count</code> column. A blank entry may represent a genuine '
            f'zero rather than an unrecorded observation. '
            f'Verify with the data owner before imputing. '
            f'If confirmed as zeros: fill with 0. '
        )
        if cls == 'mar_likely':
            cols = ', '.join(f'{c} (r={r:+.2f})' for c, r in mar_cors[:3])
            return (
                base +
                f'Note: missingness also correlates with {cols} — '
                f'if blanks are truly missing (not zero), use model-based '
                f'imputation conditioned on those columns.'
            )
        return base + 'If blanks are truly missing (not zero): impute with column median or drop rows.'

    if cls == 'mar_likely':
        cols = ', '.join(f'{c} (r={r:+.2f})' for c, r in mar_cors[:3])
        rec = (
            f'Missingness correlates significantly with: {cols}. '
            'Consistent with MAR (Missing At Random — conditional on observed data). '
            'Use model-based imputation (KNN or regression) conditioned on those columns. '
            'Simple mean/median imputation ignores this pattern and will introduce bias.'
        )
        if pct_missing > MNAR_MISS_THRESHOLD:
            rec += (
                f' Note: the missing rate ({pct_missing:.1f}%) also exceeds the MNAR '
                f'threshold — even with a MAR predictor present, a structural or '
                f'self-selective cause cannot be ruled out. Verify with the data owner.'
            )
        return rec
    return _STATIC_RECS.get(cls, 'Unknown classification — manual review required.')


# ── Main analysis ─────────────────────────────────────────────────────────────

def analyse_missing(
    cleaned_path: str,
    raw_copy_path: str | None = None,
    context_flags_path: str | None = None,
) -> tuple[pd.DataFrame, dict]:
    """
    Run full missing-value analysis on the cleaned numerical columns.

    Parameters
    ----------
    cleaned_path       : path to <name>_numerical_cleaned.csv from clean_numerical output
    raw_copy_path      : (optional) path to <name>_raw_copy.csv from detect_data_types
                         output. When provided, co-occurrence patterns and row-level
                         missingness are computed over the full dataset so that
                         structural gaps involving non-numerical columns are visible.
                         MAR correlation also searches across all numerical-convertible
                         columns in the full dataset.
    context_flags_path : (optional) path to <name>_type_flags_context.csv from
                         context_numerical output

    Returns
    -------
    flags_df : pd.DataFrame  -- one row per column
    meta     : dict          -- dataset-level summary and pattern data
    """
    df = pd.read_csv(cleaned_path)

    if df.empty or df.shape[1] == 0:
        print('  No numerical columns found -- skipping.')
        return pd.DataFrame(), {}

    context_map: dict[str, str] = {}
    if context_flags_path and Path(context_flags_path).exists():
        ctx = pd.read_csv(context_flags_path)
        if 'context' in ctx.columns:
            context_map = (
                ctx[ctx['context'].notna()]
                .set_index('column_name')['context']
                .to_dict()
            )

    # Load full dataset for cross-column pattern analysis
    df_raw_unnorm: pd.DataFrame | None = None
    if raw_copy_path and Path(raw_copy_path).exists():
        # keep_default_na=False so truly empty cells stay as '' rather than
        # being silently promoted to NaN — lets us count blank cells separately
        df_raw_unnorm = pd.read_csv(raw_copy_path, dtype=str, keep_default_na=False)
        df_full = _normalise_nulls_for_patterns(
            pd.read_csv(raw_copy_path, dtype=str)
        )
        print(f'  [info] Full dataset loaded for patterns: '
              f'{len(df_full.columns)} columns, {len(df_full)} rows')
    else:
        df_full = df  # fallback: patterns restricted to numerical subset
        print('  [warn] raw_copy_path not provided — pattern analysis '
              'restricted to numerical columns only')

    n_rows        = len(df)
    numerical_cols = set(df.columns)
    cooccur  = _cooccurrence_pairs(df_full, numerical_cols)
    row_dist = _row_miss_distribution(df)   # only numerical columns per row
    val_cors = _value_vs_miss_correlations(df, df_full)

    rows = []
    instances_records = []
    for col in df.columns:
        n_miss        = int(df[col].isna().sum())
        pct_miss      = round(n_miss / n_rows * 100, 2) if n_rows > 0 else 0.0
        detected_type = 'numerical'
        context       = context_map.get(col, '')

        # Count cells that were blank/whitespace in the raw copy.
        # Uses the un-normalised read (keep_default_na=False) so that empty
        # cells are '' rather than NaN, making them directly countable.
        if df_raw_unnorm is not None and col in df_raw_unnorm.columns:
            n_empty = int((df_raw_unnorm[col].str.strip() == '').sum())
        else:
            n_empty = 0

        mar_cors  = val_cors.get(col, [])
        cls       = _classify(pct_miss, mar_cors)
        if context == 'count' and n_empty > 0:
            cls = 'ambiguous'
        rec       = _recommendation(cls, mar_cors, n_empty=n_empty, context=context, pct_missing=pct_miss)

        rows.append({
            'column_name':     col,
            'detected_type':   detected_type,
            'context':         context,
            'n_missing':       n_miss,
            'pct_missing':     pct_miss,
            'n_empty':         n_empty,
            'miss_type':       cls,
            'correlated_with': '; '.join(
                f'{c} (r={r:+.3f})' for c, r in mar_cors[:5]
            ),
            'recommendation':  rec,
        })

        if n_miss > 0:
            for idx in df.index[df[col].isna()]:
                raw_val = ''
                if df_raw_unnorm is not None and col in df_raw_unnorm.columns:
                    raw_val = str(df_raw_unnorm.at[idx, col]).strip()
                instances_records.append({
                    'column_name': col,
                    'row_index':   int(idx),
                    'raw_value':   raw_val,
                    'miss_type':   cls,
                    'mitigation':  rec,
                })

    flags_df = pd.DataFrame(rows)
    instances_df = (
        pd.DataFrame(instances_records)
        if instances_records
        else pd.DataFrame(columns=['column_name', 'row_index', 'raw_value', 'miss_type', 'mitigation'])
    )

    total_miss = int(df.isna().sum().sum())
    meta = {
        'n_rows':              n_rows,
        'n_cols':              len(df.columns),
        'n_cols_total':        len(df_full.columns),
        'total_cells':         n_rows * len(df.columns),
        'total_missing_cells': total_miss,
        'pct_complete':        round(
            (1 - total_miss / max(n_rows * len(df.columns), 1)) * 100, 2
        ),
        'n_cols_with_missing': int((df.isna().sum() > 0).sum()),
        'cooccurrence':        cooccur,
        'row_distribution':    row_dist,
    }

    return flags_df, instances_df, meta


# ── HTML report ───────────────────────────────────────────────────────────────

BADGE_LABELS = {
    'none':         'No missing',
    'trace':        'Trace (<1%)',
    'mcar_likely':  'MCAR',
    'mar_likely':   'MAR',
    'mnar_suspect': 'MNAR (suspect)',
    'ambiguous':    'Ambiguous',
}

_HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Missing Values (Numerical) — {{ stem }}</title>
<style>
  *, *::before, *::after { box-sizing: border-box; }
  body {
    font-family: 'Segoe UI', Arial, sans-serif;
    font-size: 14px;
    background: #f5f6fa;
    color: #222;
    margin: 0;
    padding: 24px 32px;
  }
  h1 { font-size: 1.5rem; margin-bottom: 4px; color: #1a1a2e; }
  h2 {
    font-size: 1.05rem; color: #1a1a2e; margin: 32px 0 12px;
    border-bottom: 1px solid #e0e0e0; padding-bottom: 6px;
  }
  .subtitle { color: #666; margin-bottom: 28px; font-size: 0.9rem; }

  /* Summary strip */
  .summary-strip { display: flex; gap: 16px; margin-bottom: 28px; flex-wrap: wrap; }
  .metric {
    background: #fff; border-radius: 10px;
    box-shadow: 0 1px 4px rgba(0,0,0,.10);
    padding: 16px 24px; min-width: 150px;
  }
  .metric-label { font-size: 0.7rem; color: #888; text-transform: uppercase; letter-spacing: .04em; }
  .metric-value { font-size: 1.6rem; font-weight: 700; color: #1a1a2e; line-height: 1.2; }
  .metric-value.warn { color: #e65100; }
  .metric-value.ok   { color: #2e7d32; }

  /* Badges */
  .badge {
    display: inline-block; padding: 2px 9px; border-radius: 10px;
    font-size: 0.72rem; font-weight: 600; white-space: nowrap;
  }
  .badge-none         { background: #f5f5f5; color: #757575; }
  .badge-trace        { background: #e8f5e9; color: #2e7d32; }
  .badge-mcar_likely  { background: #e3f2fd; color: #1565c0; }
  .badge-mar_likely   { background: #fff8e1; color: #f57f17; }
  .badge-mnar_suspect { background: #ffebee; color: #c62828; }
  .badge-ambiguous    { background: #fff3e0; color: #e65100; }
  .badge-type         { background: #f3e5f5; color: #6a1b9a; }
  .badge-context      { background: #e8eaf6; color: #3949ab; font-family: monospace; }
  .badge-warn         { background: #fff3e0; color: #e65100; cursor: default; }

  /* Legend */
  .legend { display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 24px; align-items: center; }
  .legend-item { display: flex; align-items: center; gap: 5px; font-size: 0.8rem; color: #555; }

  /* Tables */
  .table-wrap { overflow-x: auto; margin-bottom: 8px; }
  table {
    border-collapse: collapse; width: 100%; background: #fff;
    border-radius: 10px; box-shadow: 0 1px 4px rgba(0,0,0,.10); overflow: hidden;
  }
  th {
    background: #f8f9ff; font-size: 0.72rem; text-transform: uppercase;
    letter-spacing: .04em; color: #888; padding: 10px 14px;
    text-align: left; font-weight: 600;
  }
  td { padding: 8px 14px; border-top: 1px solid #f0f0f0; font-size: 0.88rem; vertical-align: middle; }
  tr:hover td { background: #fafbff; }

  /* Missing bar (in table) */
  .miss-bar-wrap { display: flex; align-items: center; gap: 8px; min-width: 130px; }
  .miss-bar-bg   { flex: 1; height: 7px; background: #e0e0e0; border-radius: 4px; overflow: hidden; }
  .miss-bar-fill { height: 100%; border-radius: 4px; }
  .miss-val      { font-size: 0.78rem; min-width: 44px; text-align: right; color: #555; }

  /* Row distribution bar */
  .rd-bar-bg   { width: 100px; height: 8px; background: #e0e0e0; border-radius: 4px; overflow: hidden; display: inline-block; vertical-align: middle; }
  .rd-bar-fill { height: 100%; border-radius: 4px; background: #5c6bc0; }

  /* Detail cards */
  .cards { display: grid; grid-template-columns: repeat(auto-fill, minmax(460px, 1fr)); gap: 20px; margin-bottom: 32px; }
  .card  { background: #fff; border-radius: 10px; box-shadow: 0 1px 4px rgba(0,0,0,.10); padding: 18px 22px; }
  .card-header { display: flex; align-items: center; gap: 8px; margin-bottom: 14px; flex-wrap: wrap; }
  .card-title  { font-size: 1rem; font-weight: 600; color: #1a1a2e; }
  .section-label {
    font-size: 0.68rem; color: #aaa; text-transform: uppercase;
    letter-spacing: .05em; margin: 12px 0 5px;
  }
  .rec-box {
    background: #f8f9ff; border-left: 3px solid #5c6bc0;
    padding: 10px 14px; border-radius: 0 6px 6px 0;
    font-size: 0.85rem; line-height: 1.55; color: #333;
  }
  .rec-box.mar_likely   { border-left-color: #f57f17; background: #fffdf5; }
  .rec-box.mnar_suspect { border-left-color: #c62828; background: #fff8f8; }
  .rec-box.trace        { border-left-color: #2e7d32; background: #f6fdf6; }
  .rec-box.ambiguous    { border-left-color: #e65100; background: #fff8f3; }
  .corr-chip {
    display: inline-block; background: #f0f4ff; border-radius: 4px;
    padding: 2px 8px; margin: 2px; font-family: monospace; font-size: 0.8rem; color: #333;
  }
  .instance-table { width: 100%; border-collapse: collapse; font-size: 0.8rem; margin-top: 6px; }
  .instance-table th { background: #f8f9ff; padding: 5px 8px; text-align: left;
                       font-size: 0.7rem; color: #888; border-bottom: 1px solid #e8e8e8; }
  .instance-table td { padding: 5px 8px; border-bottom: 1px solid #f4f4f4; vertical-align: middle; }
  .instance-table tr:last-child td { border-bottom: none; }
  .more-note { font-size: 0.75rem; color: #999; text-align: right; margin-top: 4px; }
</style>
</head>
<body>

<h1>Missing Values (Numerical) — {{ stem }}</h1>
<div class="subtitle">
  Source: {{ source_file }} &nbsp;·&nbsp;
  {{ meta.n_rows }} rows &nbsp;·&nbsp;
  {{ meta.n_cols }} numerical column(s) analysed
  {%- if meta.n_cols_total > meta.n_cols %} of {{ meta.n_cols_total }} total{% endif %}
  &nbsp;·&nbsp; Generated {{ generated }}
</div>

<!-- Summary strip -->
<div class="summary-strip">
  <div class="metric">
    <div class="metric-label">Total rows</div>
    <div class="metric-value">{{ meta.n_rows }}</div>
  </div>
  <div class="metric">
    <div class="metric-label">Completeness</div>
    <div class="metric-value {{ 'ok' if meta.pct_complete >= 95 else 'warn' }}">{{ meta.pct_complete }}%</div>
  </div>
  <div class="metric">
    <div class="metric-label">Columns with missing</div>
    <div class="metric-value {{ 'warn' if meta.n_cols_with_missing > 0 else 'ok' }}">
      {{ meta.n_cols_with_missing }} / {{ meta.n_cols }}
    </div>
  </div>
  <div class="metric">
    <div class="metric-label">Missing cells</div>
    <div class="metric-value {{ 'warn' if meta.total_missing_cells > 0 else 'ok' }}">
      {{ meta.total_missing_cells }}
    </div>
  </div>
</div>

<!-- Legend -->
<div class="legend">
  <strong style="font-size:.8rem; color:#555;">Classification:</strong>
  <div class="legend-item"><span class="badge badge-none">No missing</span> 0 % NaN</div>
  <div class="legend-item"><span class="badge badge-trace">Trace</span> &lt;1 % NaN</div>
  <div class="legend-item"><span class="badge badge-mcar_likely">MCAR</span> random, uncorrelated</div>
  <div class="legend-item"><span class="badge badge-mar_likely">MAR</span> correlates with other columns</div>
  <div class="legend-item"><span class="badge badge-mnar_suspect">MNAR (suspect)</span> high rate, no signal</div>
  <div class="legend-item"><span class="badge badge-ambiguous">Ambiguous</span> count column — blank may be 0</div>
</div>

<!-- Overview table -->
<h2>Column overview</h2>
<div class="table-wrap">
<table>
  <thead>
    <tr>
      <th>Column</th>
      <th>Type</th>
      <th>Context</th>
      <th>NaN count</th>
      <th style="min-width:150px">NaN %</th>
      <th>Blank in raw</th>
      <th>Classification</th>
    </tr>
  </thead>
  <tbody>
  {% for col in columns %}
  <tr>
    <td><strong>{{ col.column_name }}</strong></td>
    <td><span class="badge badge-type">{{ col.detected_type }}</span></td>
    <td>{% if col.context %}<span class="badge badge-context">{{ col.context }}</span>{% endif %}</td>
    <td>{{ col.n_missing }}</td>
    <td>
      <div class="miss-bar-wrap">
        <div class="miss-bar-bg">
          <div class="miss-bar-fill"
               style="width: {{ [col.pct_missing, 100]|min }}%;
                      background: {{ '#ef5350' if col.pct_missing > 20 else '#ffa726' if col.pct_missing > 5 else '#66bb6a' if col.pct_missing > 0 else '#e0e0e0' }};">
          </div>
        </div>
        <span class="miss-val">{{ col.pct_missing }}%</span>
      </div>
    </td>
    <td>
      {% if col.n_empty > 0 %}
        {{ col.n_empty }}
        {% if col.context == 'count' %}
          <span class="badge badge-warn" title="Count column: blank may mean 0, not missing">&#9888; may be 0</span>
        {% endif %}
      {% else %}
        <span style="color:#bbb;">—</span>
      {% endif %}
    </td>
    <td><span class="badge badge-{{ col.miss_type }}">{{ badge_labels[col.miss_type] }}</span></td>
  </tr>
  {% endfor %}
  </tbody>
</table>
</div>

<!-- Row-level missingness distribution -->
<h2>Row-level missingness (numerical columns)</h2>
<p style="font-size:.85rem; color:#666; margin: 0 0 10px;">How many rows have 0, 1, 2 … <em>numerical</em> columns missing.</p>
<div class="table-wrap">
<table style="max-width: 440px;">
  <thead>
    <tr>
      <th>Missing cols per row</th>
      <th>Row count</th>
      <th>%</th>
      <th style="min-width:110px"></th>
    </tr>
  </thead>
  <tbody>
  {% for row in meta.row_distribution %}
  <tr>
    <td>{{ row.n_missing_cols }}</td>
    <td>{{ row.row_count }}</td>
    <td>{{ row.pct }}%</td>
    <td>
      <div class="rd-bar-bg">
        <div class="rd-bar-fill" style="width: {{ [row.pct, 100]|min }}%;"></div>
      </div>
    </td>
  </tr>
  {% endfor %}
  </tbody>
</table>
</div>

<!-- Co-occurrence patterns -->
{% if meta.cooccurrence %}
<h2>Co-occurrence patterns</h2>
<p style="font-size:.85rem; color:#666; margin: 0 0 10px;">
  Column pairs (from the full dataset) that are missing on the same rows,
  where at least one column is a numerical column being analysed.
  A high count may indicate a shared data collection failure.
</p>
<div class="table-wrap">
<table style="max-width: 520px;">
  <thead>
    <tr>
      <th>Column A</th>
      <th>Column B</th>
      <th>Both missing</th>
      <th>% of rows</th>
    </tr>
  </thead>
  <tbody>
  {% for pair in meta.cooccurrence %}
  <tr>
    <td>{{ pair.col1 }}</td>
    <td>{{ pair.col2 }}</td>
    <td>{{ pair.both_missing }}</td>
    <td>{{ pair.pct_of_rows }}%</td>
  </tr>
  {% endfor %}
  </tbody>
</table>
</div>
{% endif %}

<!-- Per-column detail cards -->
{% set issue_cols = columns | selectattr('miss_type', 'ne', 'none') | list %}
{% if issue_cols %}
<h2>Column analysis</h2>
<div class="cards">
{% for col in issue_cols %}
<div class="card">
  <div class="card-header">
    <span class="card-title">{{ col.column_name }}</span>
    <span class="badge badge-type">{{ col.detected_type }}</span>
    {% if col.context %}<span class="badge badge-context">{{ col.context }}</span>{% endif %}
    <span class="badge badge-{{ col.miss_type }}">{{ badge_labels[col.miss_type] }}</span>
  </div>

  <div class="section-label">Missing values</div>
  <div class="miss-bar-wrap" style="max-width: 340px;">
    <div class="miss-bar-bg">
      <div class="miss-bar-fill"
           style="width: {{ [col.pct_missing, 100]|min }}%;
                  background: {{ '#ef5350' if col.pct_missing > 20 else '#ffa726' if col.pct_missing > 5 else '#66bb6a' }};">
      </div>
    </div>
    <span class="miss-val" style="min-width:auto;">{{ col.n_missing }} NaN &nbsp;({{ col.pct_missing }}%)</span>
  </div>

  {% if col.n_empty > 0 and col.context == 'count' %}
  <div class="section-label">Zero ambiguity warning</div>
  <div class="rec-box" style="border-left-color:#e65100; background:#fff8f3;">
    <strong>{{ col.n_empty }} blank cell(s)</strong> in a <code>count</code> column.
    A blank entry may represent a genuine zero (e.g. no visits, no incidents)
    rather than a missing observation. Imputing with median or mean will corrupt
    these rows if the true value is 0. Verify with the data owner before imputing.
  </div>
  {% endif %}

  {% if col.correlated_with %}
  <div class="section-label">Correlated columns (MAR signal)</div>
  <div style="margin-bottom: 4px;">
    {% for item in col.correlated_with.split('; ') %}
      {% if item %}<span class="corr-chip">{{ item }}</span>{% endif %}
    {% endfor %}
  </div>
  {% endif %}

  <div class="section-label">Recommendation</div>
  <div class="rec-box {{ col.miss_type }}">{{ col.recommendation }}</div>

  {% if instances[col.column_name] %}
  <div class="section-label">Missing instances{% if instances[col.column_name]|length > 50 %} (top 50 shown){% endif %}</div>
  <table class="instance-table">
    <thead>
      <tr>
        <th>Row</th>
        <th>Original cell</th>
        <th>Miss type</th>
      </tr>
    </thead>
    <tbody>
    {% for inst in instances[col.column_name][:50] %}
      <tr>
        <td>{{ inst.row_index }}</td>
        <td>{% if inst.raw_value %}<code>{{ inst.raw_value }}</code>{% else %}<span style="color:#bbb;">— blank —</span>{% endif %}</td>
        <td><span class="badge badge-{{ inst.miss_type }}">{{ badge_labels[inst.miss_type] }}</span></td>
      </tr>
    {% endfor %}
    </tbody>
  </table>
  {% if instances[col.column_name]|length > 50 %}
  <div class="more-note">… {{ instances[col.column_name]|length - 50 }} more instances not shown — see flags CSV for full list.</div>
  {% endif %}
  {% endif %}

</div>
{% endfor %}
</div>
{% else %}
<p style="color:#2e7d32; font-weight:600; margin-top: 24px;">
  No missing values found across any column — dataset is complete.
</p>
{% endif %}

</body>
</html>
"""


def render_html(stem: str, columns: list[dict], meta: dict, source_file: str, instances: dict | None = None) -> str:
    """Render the HTML report from template."""
    from datetime import datetime
    if instances is None:
        instances = {}
    for col in columns:
        instances.setdefault(col['column_name'], [])
    env  = Environment(loader=BaseLoader(), autoescape=False)
    tmpl = env.from_string(_HTML_TEMPLATE)
    return tmpl.render(
        stem=stem,
        columns=columns,
        meta=meta,
        badge_labels=BADGE_LABELS,
        source_file=source_file,
        instances=instances,
        generated=datetime.now().strftime('%Y-%m-%d %H:%M'),
    )


# ── Main pipeline ─────────────────────────────────────────────────────────────

def save_outputs(stem: str) -> None:
    """Run missing-value analysis for a dataset identified by its stem name."""
    cleaned_path       = INPUT_DIR    / f'{stem}_numerical_cleaned.csv'
    raw_copy_path      = RAW_COPY_DIR / f'{stem}_raw_copy.csv'
    context_flags_path = CONTEXT_DIR  / f'{stem}_type_flags_context.csv'

    if not cleaned_path.exists():
        print(f'  [skip] {stem}: cleaned file not found at {cleaned_path}')
        return

    print(f'\n{"=" * 60}')
    print(f'Analysing: {stem}')
    print('=' * 60)

    flags_df, instances_df, meta = analyse_missing(
        str(cleaned_path),
        raw_copy_path=str(raw_copy_path),
        context_flags_path=str(context_flags_path),
    )

    if flags_df.empty:
        return

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    # Per-instance flags CSV
    csv_path = OUTPUT_DIR / f'{stem}_missing_flags.csv'
    instances_df.to_csv(csv_path, index=False)
    print(f'Flags CSV        -> {csv_path}')

    # Per-column summary CSV
    summary_path = OUTPUT_DIR / f'{stem}_missing_summary.csv'
    flags_df.to_csv(summary_path, index=False)
    print(f'Summary CSV      -> {summary_path}')

    # Build instances dict for HTML (keyed by column_name)
    instances: dict[str, list] = {}
    if not instances_df.empty:
        for col_name, grp in instances_df.groupby('column_name', sort=False):
            instances[col_name] = grp.to_dict(orient='records')

    # HTML report
    html      = render_html(stem, flags_df.to_dict('records'), meta, cleaned_path.name, instances=instances)
    html_path = OUTPUT_DIR / f'{stem}_missing_report.html'
    html_path.write_text(html, encoding='utf-8')
    print(f'HTML report -> {html_path}')

    # Console summary
    print(f'\nCompleteness: {meta["pct_complete"]}%  |  '
          f'Columns with missing: {meta["n_cols_with_missing"]}/{meta["n_cols"]}  |  '
          f'Total missing cells: {meta["total_missing_cells"]}')
    print()
    for row in flags_df.to_dict('records'):
        if row['n_missing'] > 0:
            print(f'  {row["column_name"]:<28} {row["miss_type"]:<15} '
                  f'{row["n_missing"]:>5} NaN ({row["pct_missing"]:>5.1f}%)')


if __name__ == '__main__':
    stems = sys.argv[1:] if len(sys.argv) > 1 else [
        'onderhoud_materieel',
        'personeel_hr',
    ]
    for stem in stems:
        save_outputs(stem)
