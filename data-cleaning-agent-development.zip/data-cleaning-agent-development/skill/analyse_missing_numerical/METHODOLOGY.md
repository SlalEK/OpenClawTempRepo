# Methodology: Analyse Missing Values — Numerical Columns

## Purpose

This skill is the fifth step in the AI Data Cleaning pipeline. It takes the output of the `clean-numerical` skill and performs a full diagnostic on missing values across all **numerical** columns. Pattern analysis (co-occurrence, row-level missingness, MAR correlation) is computed on the **full dataset** from the `detect-data-types` raw copy so that structural data-collection gaps are visible even when the missing field is non-numerical. The skill does **not** modify any data — its sole output is a diagnosis and a set of targeted recommendations.

---

## Folder Structure

```
skill/
├── detect_data_types/
│   └── output/
│       └── <name>_raw_copy.csv              ← input: full dataset (all column types)
├── clean_numerical/
│   └── output/
│       └── <name>_numerical_cleaned.csv     ← input: cleaned numerical columns
├── context_numerical/
│   └── output/
│       └── <name>_type_flags_context.csv    ← input (optional)
└── analyse_missing_numerical/
    ├── analyse_missing_numerical.py
    ├── METHODOLOGY.md
    ├── SKILL.md
    ├── requirements.txt
    └── output/
        ├── <name>_missing_flags.csv         ← output: one row per missing instance
        ├── <name>_missing_summary.csv       ← output: one row per column
        └── <name>_missing_report.html       ← output: HTML report
```

---

## Inputs

| File | Source | Purpose |
|---|---|---|
| `<name>_numerical_cleaned.csv` | `clean-numerical` skill | Cleaned numerical columns with proper NaN values |
| `<name>_raw_copy.csv` | `detect-data-types` skill | Full dataset (all column types) for cross-column pattern analysis |
| `<name>_type_flags_context.csv` | `context-numerical` skill (optional) | Semantic type labels used for context-aware sentinel exclusions |

Null-like normalisation (replacing `nvt`, `-`, `onbekend` etc.) is **not** repeated for the cleaned numerical columns — it is already applied by `clean-numerical` upstream. The raw copy does receive a lightweight null-like replacement pass (`_normalise_nulls_for_patterns`) before pattern analysis so that string-encoded missing values in non-numerical columns are counted correctly.

---

## Outputs

| File | Description |
|---|---|
| `<name>_missing_flags.csv` | One row per missing value instance; columns: `column_name`, `row_index`, `raw_value`, `miss_type`, `mitigation` |
| `<name>_missing_summary.csv` | One row per column; columns: `column_name`, `detected_type`, `context`, `n_missing`, `pct_missing`, `n_empty`, `miss_type`, `correlated_with`, `recommendation` |
| `<name>_missing_report.html` | Self-contained HTML — all CSS inlined, no external assets required |

The `_missing_summary.csv` is designed to be consumed by a future `impute-missing` skill.

---

## Analysis Steps

### Step 1 — Identify NaN values

For each column, the skill counts the number of `NaN` values and computes the missing percentage:

```
pct_missing = n_missing / n_rows × 100
```

### Step 2 — Blank cell count (`n_empty`)

Before standard NaN analysis, the skill re-reads the **raw source file** with `keep_default_na=False` so that empty cells are loaded as empty strings rather than silently converted to `NaN`. For each numerical column it counts how many cells contain only whitespace (i.e. `str.strip() == ''`). This count is stored as `n_empty` in the flags CSV.

`n_empty` is meaningful primarily for columns with context label `count`. An empty cell in a count column could be either:
- a **genuine zero** (no events recorded) — should be filled with `0`, or
- a **missing observation** — should be imputed or dropped.

The skill cannot resolve this ambiguity automatically. Instead, it surfaces a zero-ambiguity warning in both the flags CSV recommendation and the HTML report card, directing the analyst to verify with the data owner before imputing.

For non-count columns `n_empty` is still reported in the CSV for completeness, but no special warning is raised.

### Step 3 — Co-occurrence patterns

`_cooccurrence_pairs()` iterates over all pairs of columns in the **full dataset** that each have at least one NaN and counts how many rows have both columns missing simultaneously. Results are sorted by count descending. Using the full dataset means pairs involving non-numerical columns (e.g. a datetime field that is always absent when a numerical field is absent) are captured.

A high co-occurrence count suggests a shared upstream cause — e.g. a field that is only populated when another field is present, or a data ingestion failure that affected multiple columns at once.

### Step 4 — Row-level missingness distribution

`_row_miss_distribution()` counts how many rows have exactly 0, 1, 2 … k columns missing. This shows whether missing values cluster on the same rows (structural missingness) or are spread independently across the dataset.

### Step 5 — MAR correlation (point-biserial)

`_value_vs_miss_correlations()` tests for **Missing At Random (MAR)** by computing the Pearson correlation between:
- the binary missingness indicator of column X (1 = missing, 0 = present), and
- the actual numeric values of every other column Y

This is the point-biserial correlation. A meaningful correlation (|r| ≥ `MAR_CORR_THRESHOLD`, default 0.15) indicates that whether X is missing depends on the observed value of Y — a MAR pattern. Model-based imputation conditioned on Y will then be more accurate than mean/median imputation.

**Minimum sample requirement:** pairs with fewer than 20 jointly non-null rows are skipped to avoid spurious correlations.

### Step 6 — Classification

Each column is assigned one of five missingness types:

| Label | Condition |
|---|---|
| `none` | `pct_missing == 0` |
| `trace` | `pct_missing < TRACE_MISS_THRESHOLD` (default 1%) |
| `mar_likely` | At least one column has |r| ≥ `MAR_CORR_THRESHOLD` |
| `mnar_suspect` | `pct_missing > MNAR_MISS_THRESHOLD` (default 10%) **and** no MAR signal |
| `mcar_likely` | All other cases (missing, not trace, no MAR, not high-rate) |
| `ambiguous` | `context == count` **and** `n_empty > 0` — overrides the above; mechanism cannot be determined until blank-cell intent is confirmed |

Classification is based solely on the NaN rate and MAR signal.

**Important limitation:** the MNAR/MCAR distinction made here is based on observable data. True MNAR (where the probability of missingness depends on the missing value itself) cannot be proven from the data alone — `mnar_suspect` is a flag for domain review, not a statistical proof.

### Step 7 — Recommendations

Recommendations are generated per classification label. For `mar_likely` columns the correlated columns and their r values are named explicitly so the analyst knows which columns to condition imputation on.

**Zero-ambiguity override:** when `context == 'count'` and `n_empty > 0`, the standard recommendation is replaced with a notice that blank cells may represent genuine zeros. The analyst is instructed to verify with the data owner before imputing; the classification-based fallback strategy is appended for cases where blanks are confirmed as truly missing.

| Classification | Condition | Recommendation |
|---|---|---|
| `none` | — | No action required |
| `trace` | — | Drop affected rows or impute with column median/mode — negligible data loss |
| `mcar_likely` | — | Impute with column median (numerical); or drop rows if dataset is large enough. If domain knowledge suggests extreme values may be systematically absent, treat as potential MNAR and consult the data owner |
| `mar_likely` | — | Use model-based imputation (KNN or regression) conditioned on the correlated columns named in the report |
| `mnar_suspect` | — | Do not impute without domain knowledge — consult a data owner |
| `ambiguous` | `context == count` and `n_empty > 0` | Zero-ambiguity override — verify with data owner; fill with 0 if confirmed zeros, otherwise apply the mechanism-appropriate strategy |

---

## Tuning Parameters

| Constant | Default | Effect |
|---|---|---|
| `MAR_CORR_THRESHOLD` | `0.15` | Minimum |r| to classify a column as MAR. Lower → more columns flagged as MAR; raise to require stronger signal |
| `MNAR_MISS_THRESHOLD` | `10.0` | % NaN above which a column is suspected MNAR (when no MAR signal exists) |
| `TRACE_MISS_THRESHOLD` | `1.0` | % NaN below which a column is classified as trace |

---

## Known Boundary Cases

- **With only one numerical column** (e.g. `personeel_hr`): no co-occurrence pairs are possible and MAR correlation has no other column to correlate against, so the column will default to `mcar_likely` or `mnar_suspect` based solely on rate.
- **IQR = 0 / constant columns**: point-biserial correlation is undefined (zero variance); these pairs are skipped.
- **Count column with blank cells**: `n_empty` is counted from a separate `keep_default_na=False` read of the raw file. If the cleaned file has already converted blanks to `NaN`, the `n_missing` and `n_empty` counts may overlap — both are reported so the analyst can see the full picture.
- **Context map not available**: the skill runs normally; `n_empty` is still counted but no zero-ambiguity warning is raised because the count context is unknown.

---

## Observed Results on Defence Datasets

| Column | Dataset | NaN | Blank (n_empty) | Classification | Key finding |
|---|---|---|---|---|---|
| `hersteltijd_uur` | onderhoud_materieel | 361 (6.9%) | 0 | `mcar_likely` | No MAR signal; rate below MNAR threshold |
| `kosten_eur` | onderhoud_materieel | 510 (9.7%) | 0 | `mcar_likely` | Near the MNAR threshold but no correlation signal |
| `aantal_uitzendingen` | personeel_hr | 325 (6.3%) | 325 | `ambiguous` | Count column — all 325 missing values are blank cells; mechanism cannot be determined until data owner confirms whether blanks are zeros |
