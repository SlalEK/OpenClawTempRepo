---
name: analyse-missing-numerical
description: 'Fifth step in the AI Data Cleaning pipeline, runs after clean-numerical. Reads cleaned numerical columns and the full-dataset raw copy from detect-data-types, then performs a five-step missing-value analysis: count NaN per column, count blank cells (n_empty) for zero-ambiguity detection, analyse co-occurrence patterns and row-level missingness across all columns in the dataset, test for MAR signal via point-biserial correlation against all numerical-convertible columns in the full dataset, and classify each numerical column as none / trace / mcar_likely / mar_likely / mnar_suspect. For count-context columns with blank cells, the recommendation is replaced with a zero-ambiguity notice directing the analyst to verify with the data owner before imputing. Outputs a machine-readable flags CSV and a self-contained HTML report. Does NOT impute or modify any data.'
argument-hint: 'Dataset stem name, e.g. onderhoud_materieel'
---

# Analyse Missing Values — Numerical Columns

## Purpose
Diagnose missing values across all **numerical** columns so that analysts can make informed decisions about imputation strategy before any data is modified. The skill identifies explicit `NaN` values and blank cells, classifies the missingness mechanism, and recommends a targeted mitigation. For count-context columns where a blank cell may represent a genuine zero, a zero-ambiguity warning is raised instead of a generic imputation recommendation.

Co-occurrence patterns and row-level missingness are computed on the **full dataset** (all column types) so that structural data-collection gaps are visible even when the missing field is non-numerical.

## Prerequisites
The `clean-numerical` skill must have been run first. The `detect-data-types` skill must also have been run (provides the raw copy for full-dataset pattern analysis). Optionally run `context-numerical` first to enable context-aware zero-ambiguity warnings for `count`-labelled columns.

## What It Does
1. **Identify** — counts `NaN` per numerical column and computes the missing percentage
2. **Sentinel detection** — scans non-null numeric values for known placeholder candidates (9999, -1, 999, etc.); flags any that exceed the frequency threshold (≥3% of non-null values)
3. **Co-occurrence patterns** — finds pairs of columns (across the **full dataset**) that are missing on the same rows simultaneously; a high count suggests a shared data-collection failure
4. **Row-level distribution** — counts how many rows have 0, 1, 2 … columns missing across the **full dataset**
5. **MAR correlation** — computes point-biserial correlation between each numerical column's binary missingness indicator and all numerical-convertible values in the **full dataset**
6. **Classify** — assigns a missingness type per numerical column based on NaN rate and MAR signal
7. **Recommend** — generates a targeted mitigation recommendation per classification
8. **Render** — writes a flags CSV and a self-contained HTML report

## Classification Labels

| Label | Meaning | Recommended action |
|---|---|---|
| `none` | No missing values | No action required |
| `trace` | < 1% NaN | Drop rows or median/mode impute — negligible data loss |
| `mcar_likely` | Random, uncorrelated with other columns | Median (numerical) or mode (categorical) imputation; or drop rows if dataset is large. If domain knowledge suggests extreme values may be systematically absent, treat as potential MNAR and consult the data owner |
| `mar_likely` | Missingness correlates with values in other columns | Model-based imputation (KNN or regression) conditioned on the correlated columns |
| `mnar_suspect` | High rate (> 10%), no MAR signal detected | Do not impute without domain knowledge — consult a data owner |
| `ambiguous` | Count column with blank cells — mechanism cannot be determined without domain input | Verify with data owner: fill with 0 if blanks are intentional zeros; otherwise apply mechanism-appropriate strategy |

The `ambiguous` label overrides all other classifications. If a count column has blank cells, the mechanism is unresolvable from data alone because a blank might be MNAR (value = 0, systematically encoded as blank) or genuinely missing. Domain confirmation is required before any imputation decision.

## Procedure

### Run on all configured datasets
```bash
python skill/analyse_missing_numerical/analyse_missing_numerical.py
```

### Run on a specific dataset
```bash
python skill/analyse_missing_numerical/analyse_missing_numerical.py onderhoud_materieel
```

### Import in another skill
```python
from skill.analyse_missing_numerical import analyse_missing

flags_df, meta = analyse_missing(
    cleaned_path='skill/clean_numerical/output/onderhoud_materieel_numerical_cleaned.csv',
    raw_copy_path='skill/detect_data_types/output/onderhoud_materieel_raw_copy.csv',
    context_flags_path='skill/context_numerical/output/onderhoud_materieel_type_flags_context.csv',
)
```

## Inputs
| File | Source folder | Required |
|---|---|---|
| `<name>_numerical_cleaned.csv` | `skill/clean_numerical/output/` | Yes |
| `<name>_raw_copy.csv` | `skill/detect_data_types/output/` | Recommended — enables full-dataset pattern analysis |
| `<name>_type_flags_context.csv` | `skill/context_numerical/output/` | No |

## Outputs
Written to `skill/analyse_missing_numerical/output/`:

| File | Description |
|---|---|
| `<name>_missing_flags.csv` | One row per missing value instance: row index, raw value, miss type, mitigation |
| `<name>_missing_summary.csv` | One row per column: NaN count/%, sentinel info, classification, correlated columns, recommendation |
| `<name>_missing_report.html` | Self-contained HTML report — no internet required |

## Reading the Report

| Section | What to look for |
|---|---|
| Summary strip | Overall completeness %; total missing cells; number of affected columns |
| Column overview table | NaN bar colour (green ≤5%, amber 5–20%, red >20%); ⚠ `may be 0` badge on blank-cell count for `count`-context columns |
| Row-level missingness | Rows with 2+ missing columns may indicate structural data gaps (e.g. a linked field that was never filled) |
| Co-occurrence patterns | Column pairs missing together frequently → shared source system issue |
| Column analysis cards | Full recommendation per column; zero-ambiguity warning card when `context == count` and `n_empty > 0`; correlated columns for MAR cases |

## Dependencies
```bash
pip install -r skill/analyse_missing_numerical/requirements.txt
```

## References
- [Statistical methodology and classification logic](./METHODOLOGY.md)
