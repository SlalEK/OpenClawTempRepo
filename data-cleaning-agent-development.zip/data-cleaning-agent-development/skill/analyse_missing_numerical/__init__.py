"""
analyse-missing-numerical skill — public API for downstream skills.

Usage
-----
    from skill.analyse_missing_numerical import analyse_missing

    flags_df, instances_df, meta = analyse_missing(
        cleaned_path='skill/clean_numerical/output/onderhoud_materieel_numerical_cleaned.csv',
        raw_copy_path='skill/detect_data_types/output/onderhoud_materieel_raw_copy.csv',
        context_flags_path='skill/context_numerical/output/onderhoud_materieel_type_flags_context.csv',
    )
"""

from .analyse_missing_numerical import analyse_missing, render_html, save_outputs

__all__ = ['analyse_missing', 'render_html', 'save_outputs']
