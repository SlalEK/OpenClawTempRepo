#!/usr/bin/env python3
"""diagnose_numerical – aggregate all numerical data-quality findings into a triage report.

Reads:
  analyse_missing_numerical      → _missing_summary.csv + _missing_flags.csv
  analyse_outliers_numerical     → _outlier_summary.csv + _outlier_flags.csv
  analyse_distribution_numerical → _distribution_summary.csv + _distribution_temporal.csv
  context_numerical              → _type_flags_context.csv
  detect_data_types              → _raw_copy.csv

Produces:
  <stem>_issues_report.csv   one row per (column, issue_type) with confidence + urgency
  <stem>_issues_report.html  self-contained HTML triage report
"""

import sys
from pathlib import Path
from datetime import datetime

import numpy as np
import pandas as pd
from jinja2 import Template

# ── Directory constants ────────────────────────────────────────────────────────
MISSING_DIR = Path("skill/analyse_missing_numerical/output")
OUTLIER_DIR = Path("skill/analyse_outliers_numerical/output")
DIST_DIR    = Path("skill/analyse_distribution_numerical/output")
CONTEXT_DIR = Path("skill/context_numerical/output")
RAW_DIR     = Path("skill/detect_data_types/output")
OUTPUT_DIR  = Path("skill/diagnose_numerical/output")

STEMS = ["onderhoud_materieel", "personeel_hr"]

# ── Date detection ─────────────────────────────────────────────────────────────
_DATE_LIKE_TOKENS = {
    "date", "datum", "dt", "dag", "time", "tijd", "created", "modified",
    "timestamp", "ts", "year", "jaar", "month", "maand",
}


def _detect_date_column(df: pd.DataFrame) -> str | None:
    """Return the first parseable date-like column name, or None."""
    for col in df.columns:
        if not any(tok in col.lower() for tok in _DATE_LIKE_TOKENS):
            continue
        sample = df[col].dropna().head(200)
        if len(sample) == 0:
            continue
        try:
            parsed = pd.to_datetime(sample, format="mixed", dayfirst=True, errors="coerce")
            if parsed.notna().mean() >= 0.50:
                return col
        except Exception:
            try:
                parsed = pd.to_datetime(sample, dayfirst=True, errors="coerce")
                if parsed.notna().mean() >= 0.50:
                    return col
            except Exception:
                pass
    return None


def _parse_periods(ts_series: pd.Series) -> pd.Series:
    """Parse a raw string date series to monthly period strings (YYYY-MM)."""
    parsed = pd.to_datetime(ts_series, format="mixed", dayfirst=True, errors="coerce")
    return parsed.dt.to_period("M").astype(str).where(parsed.notna(), other=pd.NA)


# ── Temporal concentration analysis ───────────────────────────────────────────
def _temporal_pattern(
    row_indices,
    raw_copy: pd.DataFrame | None,
    time_col: str | None,
) -> dict:
    """Detect whether flagged rows are concentrated in certain time periods.

    Returns:
        pattern         : "none" | "uniform" | "localized" | "widespread" | "increasing" | "decreasing"
        worst_period    : str | None
        worst_period_pct: float | None   (% of that period's rows that are flagged)
        n_periods_flagged: int
    """
    result = {
        "pattern":          "none",
        "worst_period":     None,
        "worst_period_pct": None,
        "n_periods_flagged": 0,
    }
    if raw_copy is None or time_col is None:
        return result
    row_indices = list(row_indices) if not hasattr(row_indices, "__len__") else list(row_indices)
    if len(row_indices) == 0:
        return result

    periods = _parse_periods(raw_copy[time_col])
    periods.index = range(len(raw_copy))

    period_totals = periods.dropna().value_counts()

    valid_flagged_idx = [i for i in row_indices if 0 <= i < len(periods) and pd.notna(periods.iloc[i])]
    if len(valid_flagged_idx) == 0:
        return result

    flagged_periods = periods.iloc[valid_flagged_idx]
    period_flag_counts = flagged_periods.value_counts()

    rates: dict[str, float] = {}
    for p, n_flag in period_flag_counts.items():
        n_tot = period_totals.get(p, 0)
        if n_tot > 0:
            rates[p] = n_flag / n_tot

    if not rates:
        return result

    rate_series = pd.Series(rates).sort_index()
    worst       = rate_series.idxmax()
    worst_rate  = float(rate_series.max())
    mean_rate   = float(rate_series.mean())
    n_flagged   = int((rate_series > 0).sum())

    result["worst_period"]      = worst
    result["worst_period_pct"]  = round(worst_rate * 100, 1)
    result["n_periods_flagged"] = n_flagged

    # Trend: look at last 6 periods that have data
    window = rate_series.tail(min(8, len(rate_series)))
    if len(window) >= 4:
        diffs = window.diff().dropna()
        if (diffs > 0).sum() >= len(diffs) * 0.75:
            result["pattern"] = "increasing"
            return result
        if (diffs < 0).sum() >= len(diffs) * 0.75:
            result["pattern"] = "decreasing"
            return result

    concentration = worst_rate / mean_rate if mean_rate > 0 else 1.0
    total_periods = len(rate_series)

    if concentration >= 3.0 and n_flagged <= max(2, total_periods * 0.15):
        result["pattern"] = "localized"
    elif n_flagged / max(1, total_periods) >= 0.55:
        result["pattern"] = "widespread"
    else:
        result["pattern"] = "uniform"

    return result


# ── Confidence scoring ─────────────────────────────────────────────────────────
# Confidence answers: "How certain are we that this finding is correctly identified?"
# It reflects detection method reliability, sample size, and interpretation ambiguity.
# It does NOT reflect how severe or urgent the issue is — that is captured by urgency.

_BASE_CONFIDENCE = {
    # Rule-based / deterministic detection → high certainty
    "invalid_outliers":                         0.95,
    # Strong statistical clustering pattern → high certainty
    "structural_sentinels":                     0.87,
    # Values are unambiguously absent; MCAR interpretation has some statistical uncertainty
    "missing_data_mcar_likely":                 0.80,
    # Boundary / spike detection is fairly reliable
    "distribution_anomaly_data_quality_issue":  0.78,
    # MAR harder to establish statistically than MCAR
    "missing_data_mar":                         0.70,
    # MNAR statistically indistinguishable from MCAR at low rates
    "missing_data_mnar":                        0.65,
    # MAD-based test is robust but seasonal variation can produce false positives
    "temporal_shift":                           0.65,
    # Shape detection reliable; whether it is a "problem" is less certain
    "distribution_anomaly_suspicious":          0.60,
    # Statistical test with known false-positive rate (non-normal distributions)
    "suspicious_outliers":                      0.60,
    # Classified as expected/acceptable — confident it is not a problem
    "distribution_anomaly_legitimate":          0.84,
    # Genuinely unclear what the null values represent
    "missing_data_ambiguous":                   0.42,
    # Judgment call on extreme-but-valid values
    "legitimate_outliers":                      0.55,
    # Generic fallback
    "missing_data":                             0.72,
}


def _confidence(
    issue_type: str,
    severity: str,
    n_count: int = 0,
    n_total: int = 0,
    miss_type: str = "",
    structural_pct: float | None = None,
    n_shifted: int = 0,
    n_windows: int = 0,
) -> float:
    """How certain are we that this finding is correctly identified?"""
    if issue_type == "missing_data":
        mt  = miss_type.lower().replace(" ", "_")
        key = f"missing_data_{mt}" if f"missing_data_{mt}" in _BASE_CONFIDENCE else "missing_data"
    elif issue_type == "distribution_anomaly":
        key = f"distribution_anomaly_{severity}"
    else:
        key = issue_type
    base = _BASE_CONFIDENCE.get(key, 0.60)

    # suspicious_outliers: small instance count → detection less reliable
    if issue_type == "suspicious_outliers":
        if n_count < 3:
            base -= 0.15
        elif n_count < 10:
            base -= 0.07
        elif n_count > 50:
            base += 0.04

    # structural_sentinels: if the sentinel does not dominate the outlier set, pattern is weaker
    if issue_type == "structural_sentinels" and structural_pct is not None:
        if structural_pct < 50:
            base -= 0.05

    # temporal_shift: a single shifted window may be noise; many windows = strong pattern
    if issue_type == "temporal_shift" and n_windows > 0:
        if n_shifted == 1:
            base -= 0.08
        elif n_shifted >= 5:
            base += 0.06

    # invalid_outliers: very few instances could be isolated edge cases
    if issue_type == "invalid_outliers":
        if n_count < 3:
            base -= 0.08
        elif n_count < 10:
            base -= 0.03

    return round(min(0.97, max(0.10, base)), 2)


def _urgency(issue_type: str, severity: str, affected_pct: float, tp_pattern: str) -> str:
    """How urgent is it to address this issue? Based on severity class, scale, and temporal trend."""
    # Hard rules for definitively broken values — must be fixed regardless of scale
    if issue_type == "invalid_outliers":
        return "critical" if affected_pct > 5 else "high"
    if issue_type == "structural_sentinels":
        return "critical" if affected_pct > 5 else "high"
    # Scale-based rules for missingness
    if issue_type == "missing_data":
        if affected_pct > 20:
            return "critical"
        if affected_pct > 5:
            return "high"
        if affected_pct > 2:
            return "medium"
        return "low"
    # Legitimate findings never require urgent action
    if issue_type == "legitimate_outliers":
        return "low"
    # Score-based for the rest: severity class + scale of impact + temporal trend
    sev_score   = {"data_quality_issue": 3, "suspicious": 2, "legitimate": 1}.get(severity, 1)
    scale_score = (3 if affected_pct > 20 else
                   2 if affected_pct > 10 else
                   1 if affected_pct > 5  else
                   0 if affected_pct >= 1 else -1)
    trend_score = {"increasing": 2, "widespread": 1, "decreasing": 1, "localized": -1}.get(tp_pattern, 0)
    total = sev_score + scale_score + trend_score
    if total >= 7: return "critical"
    if total >= 5: return "high"
    if total >= 3: return "medium"
    return "low"


# ── Issue builders ─────────────────────────────────────────────────────────────
def _issues_from_missing(
    missing_summary: pd.DataFrame | None,
    missing_flags: pd.DataFrame | None,
    raw_copy: pd.DataFrame | None,
    time_col: str | None,
) -> list[dict]:
    if missing_summary is None or missing_summary.empty:
        return []
    issues = []
    for _, row in missing_summary.iterrows():
        col  = row["column_name"]
        pct  = float(row["pct_missing"])
        mtyp = str(row.get("miss_type", ""))

        row_idx: list[int] = []
        if missing_flags is not None:
            row_idx = missing_flags.loc[missing_flags["column_name"] == col, "row_index"].tolist()

        tp   = _temporal_pattern(row_idx, raw_copy, time_col)
        conf = _confidence("missing_data", "data_quality_issue", miss_type=mtyp)
        urg  = _urgency("missing_data", "data_quality_issue", pct, tp["pattern"])

        detail = f"{pct:.1f}% of values are missing (pattern: {mtyp})."
        if tp["worst_period"]:
            detail += f" Highest rate in period {tp['worst_period']} ({tp['worst_period_pct']:.1f}% of rows in that period)."

        if "ambiguous" in mtyp:
            mitigation = (
                "Verify with data owner whether blanks represent genuine zeros or missing "
                "observations before imputing. If zeros: fill with 0. "
                "If truly missing: impute with column median."
            )
        elif "mnar" in mtyp.lower():
            mitigation = (
                "MNAR pattern — imputing blindly introduces bias. Consult the data owner, "
                "model missingness explicitly, or document and exclude the affected rows."
            )
        elif "mar" in mtyp.lower():
            mitigation = (
                "MAR pattern — use model-based imputation (predict missing values from correlated "
                "columns). Simple median imputation is a fallback but may introduce bias."
            )
        else:
            mitigation = (
                "Impute with column median (robust to outliers). "
                "Alternatively drop rows if the dataset is large enough (>10 000 rows, <5% missing)."
            )

        issues.append({
            "column_name":       col,
            "issue_type":        "missing_data",
            "severity":          "data_quality_issue",
            "affected_pct":      round(pct, 2),
            "confidence":        conf,
            "urgency":           urg,
            "temporal_pattern":  tp["pattern"],
            "worst_period":      tp["worst_period"] or "",
            "worst_period_pct":  tp["worst_period_pct"] if tp["worst_period_pct"] is not None else "",
            "n_periods_flagged": tp["n_periods_flagged"],
            "detail":            detail,
            "mitigation":        mitigation,
        })
    return issues


def _issues_from_outliers(
    outlier_summary: pd.DataFrame | None,
    outlier_flags: pd.DataFrame | None,
    raw_copy: pd.DataFrame | None,
    time_col: str | None,
) -> list[dict]:
    if outlier_summary is None or outlier_summary.empty:
        return []
    issues = []
    for _, row in outlier_summary.iterrows():
        col     = row["column_name"]
        n_total = int(row["n_non_null"])

        def _make(issue_type: str, n_count: int, class_name: str, severity: str) -> dict | None:
            if n_count == 0:
                return None
            pct = round(n_count / n_total * 100, 2) if n_total > 0 else 0.0

            row_idx: list[int] = []
            if outlier_flags is not None:
                row_idx = outlier_flags.loc[
                    (outlier_flags["column_name"] == col) & (outlier_flags["outlier_class"] == class_name),
                    "row_index",
                ].tolist()

            tp   = _temporal_pattern(row_idx, raw_copy, time_col)
            spct = float(row.get("structural_pct") or 0) if issue_type == "structural_sentinels" else None
            conf = _confidence(issue_type, severity, n_count=n_count, n_total=n_total, structural_pct=spct)
            urg  = _urgency(issue_type, severity, pct, tp["pattern"])

            if issue_type == "invalid_outliers":
                detail = (
                    f"{n_count} rows ({pct:.1f}%) contain domain-invalid values "
                    "(e.g. impossible negatives, out-of-range codes)."
                )
                mitigation = (
                    "Correct or set to NaN. Apply domain rules (e.g. negative count → NaN "
                    "or abs(value) if sign error is suspected) before re-cleaning."
                )
            elif issue_type == "structural_sentinels":
                sv  = str(row.get("structural_values", "unknown"))
                spct = row.get("structural_pct", "")
                detail = (
                    f"{n_count} rows ({pct:.1f}%) contain structural sentinel value(s): {sv} "
                    f"(representing {spct}% of all outliers in this column)."
                )
                mitigation = (
                    "Replace sentinel values with NaN and impute, or map to the correct coded "
                    "value. Consult the data owner to confirm the intended replacement."
                )
            elif issue_type == "legitimate_outliers":
                detail = (
                    f"{n_count} rows ({pct:.1f}%) contain extreme values flagged as legitimate "
                    "(statistically extreme but not domain-invalid)."
                )
                mitigation = (
                    "No action required unless specific analyses are sensitive to extreme values. "
                    "Consider winsorization at p1/p99 for regression-based models."
                )
            else:  # suspicious_outliers
                detail = (
                    f"{n_count} rows ({pct:.1f}%) are statistical outliers (IQR / z-score) "
                    "without a definitive domain violation."
                )
                mitigation = (
                    "Review with domain expert. Apply winsorization at p1/p99 if confirmed "
                    "noise; retain if genuinely extreme but valid observations."
                )

            if tp["worst_period"]:
                detail += (
                    f" Highest concentration in period {tp['worst_period']} "
                    f"({tp['worst_period_pct']:.1f}% of that period's rows)."
                )

            return {
                "column_name":       col,
                "issue_type":        issue_type,
                "severity":          severity,
                "affected_pct":      pct,
                "confidence":        conf,
                "urgency":           urg,
                "temporal_pattern":  tp["pattern"],
                "worst_period":      tp["worst_period"] or "",
                "worst_period_pct":  tp["worst_period_pct"] if tp["worst_period_pct"] is not None else "",
                "n_periods_flagged": tp["n_periods_flagged"],
                "detail":            detail,
                "mitigation":        mitigation,
            }

        for itype, n_val, cls_name, sev in [
            ("invalid_outliers",    int(row["n_invalid"]),    "invalid",    "data_quality_issue"),
            ("structural_sentinels",int(row["n_structural"]), "structural", "data_quality_issue"),
            ("suspicious_outliers", int(row["n_suspicious"]), "suspicious", "suspicious"),
            ("legitimate_outliers", int(row["n_legitimate"]), "legitimate", "legitimate"),
        ]:
            rec = _make(itype, n_val, cls_name, sev)
            if rec:
                issues.append(rec)
    return issues


def _issues_from_distribution(
    dist_summary: pd.DataFrame | None,
    dist_temporal: pd.DataFrame | None,
) -> list[dict]:
    if dist_summary is None or dist_summary.empty:
        return []
    issues = []
    for _, row in dist_summary.iterrows():
        col      = row["column_name"]
        cls      = row["overall_class"]
        shape    = row["shape"]
        modality = row["modality"]
        skewness = float(row.get("skewness", 0) or 0)
        kurtosis = float(row.get("kurtosis", 0) or 0)
        zeros_pct = float(row.get("zeros_pct", 0) or 0)

        col_temporal = (
            dist_temporal[dist_temporal["column_name"] == col]
            if dist_temporal is not None else pd.DataFrame()
        )

        # ── Distribution shape / anomaly issue ────────────────────────────────
        if cls != "no_issue":
            pct_affected = 100.0  # shape issues characterise the whole column
            tp_pattern   = "none"

            detail_parts = [f"Column shape: {shape}, modality: {modality}"]
            detail_parts.append(f"(skewness={skewness:.3f}, kurtosis={kurtosis:.3f})")
            if zeros_pct > 0:
                detail_parts.append(f"Zero inflation: {zeros_pct:.1f}% zeros")
            detail = ". ".join(detail_parts) + "."

            if cls == "data_quality_issue":
                mitigation = (
                    "Investigate the source of truncation, dominant value spike, or unexpected "
                    "zero-inflation. Check for system-imposed caps, default fill values, or "
                    "batch import artifacts. Correct at source if possible."
                )
            elif cls == "suspicious":
                mitigation = (
                    "Verify whether the distribution shape is inherent to the domain or introduced "
                    "by collection bias. For heavy-skewed financial or duration data, log-transform "
                    "before statistical modelling. For bimodal data, consider whether the column "
                    "mixes two distinct sub-populations."
                )
            else:  # legitimate
                mitigation = (
                    "Distribution shape is expected for this column context. "
                    "No corrective action needed; note the shape for downstream model selection "
                    "(e.g. use log-transform for log-normal data)."
                )

            conf = _confidence("distribution_anomaly", cls)
            urg  = _urgency("distribution_anomaly", cls, pct_affected, tp_pattern)
            # Override urgency for "legitimate" — never above low
            if cls == "legitimate":
                urg = "low"

            issues.append({
                "column_name":       col,
                "issue_type":        "distribution_anomaly",
                "severity":          cls,
                "affected_pct":      pct_affected,
                "confidence":        conf,
                "urgency":           urg,
                "temporal_pattern":  tp_pattern,
                "worst_period":      "",
                "worst_period_pct":  "",
                "n_periods_flagged": 0,
                "detail":            detail,
                "mitigation":        mitigation,
            })

        # ── Temporal shift issue ───────────────────────────────────────────────
        if not col_temporal.empty:
            n_total_windows  = len(col_temporal)
            n_shifted        = int((col_temporal["shift"] == True).sum())
            if n_shifted > 0:
                shifted_rows  = col_temporal[col_temporal["shift"] == True]
                overall_med   = float(row["median"])
                worst_idx     = (shifted_rows["median"] - overall_med).abs().idxmax()
                worst_p       = str(shifted_rows.loc[worst_idx, "period"])
                worst_med     = float(shifted_rows.loc[worst_idx, "median"])
                pct_windows   = round(n_shifted / n_total_windows * 100, 1)
                tp_pattern    = "localized" if n_shifted <= 2 else "widespread"

                conf = _confidence("temporal_shift", "suspicious", n_shifted=n_shifted, n_windows=n_total_windows)
                urg  = _urgency("temporal_shift", "suspicious", pct_windows, tp_pattern)

                detail = (
                    f"{n_shifted} of {n_total_windows} time windows show a significant median "
                    f"shift (>3 x MAD from overall median of {overall_med:.2f}). "
                    f"Largest deviation in period {worst_p} (window median: {worst_med:.2f})."
                )
                mitigation = (
                    "Investigate process or source-system changes around the affected period(s). "
                    "Common causes: batch import errors, sensor recalibration, tariff/rate changes, "
                    "methodology changes. Confirm with data owner before imputing or correcting."
                )

                issues.append({
                    "column_name":       col,
                    "issue_type":        "temporal_shift",
                    "severity":          "suspicious",
                    "affected_pct":      pct_windows,
                    "confidence":        conf,
                    "urgency":           urg,
                    "temporal_pattern":  tp_pattern,
                    "worst_period":      worst_p,
                    "worst_period_pct":  "",
                    "n_periods_flagged": n_shifted,
                    "detail":            detail,
                    "mitigation":        mitigation,
                })
    return issues


# ── Main aggregation ───────────────────────────────────────────────────────────
def diagnose(
    cleaned_path: str | Path,
    missing_summary_path: str | Path | None = None,
    missing_flags_path:   str | Path | None = None,
    outlier_summary_path: str | Path | None = None,
    outlier_flags_path:   str | Path | None = None,
    dist_summary_path:    str | Path | None = None,
    dist_temporal_path:   str | Path | None = None,
    context_flags_path:   str | Path | None = None,
    raw_copy_path:        str | Path | None = None,
) -> tuple[pd.DataFrame, dict]:
    """Aggregate all numerical analysis outputs into a unified issues DataFrame.

    Returns (issues_df, meta).
    issues_df — one row per (column, issue_type) with confidence, urgency, and mitigation
    meta      — run metadata dict
    """

    def _load(path, **kwargs):
        p = Path(path) if path else None
        if p and p.exists():
            return pd.read_csv(p, **kwargs)
        return None

    missing_summary = _load(missing_summary_path)
    missing_flags   = _load(missing_flags_path)
    outlier_summary = _load(outlier_summary_path)
    outlier_flags   = _load(outlier_flags_path)
    dist_summary    = _load(dist_summary_path)
    dist_temporal   = _load(dist_temporal_path)
    context_flags   = _load(context_flags_path)
    raw_copy        = _load(raw_copy_path, dtype=str) if raw_copy_path else None

    time_col: str | None = None
    if raw_copy is not None:
        time_col = _detect_date_column(raw_copy)
        if time_col:
            print(f"  [info] Temporal grouping using column: '{time_col}'")

    # Collect all issues
    all_issues: list[dict] = []
    all_issues.extend(_issues_from_missing(missing_summary, missing_flags, raw_copy, time_col))
    all_issues.extend(_issues_from_outliers(outlier_summary, outlier_flags, raw_copy, time_col))
    all_issues.extend(_issues_from_distribution(dist_summary, dist_temporal))

    if all_issues:
        issues_df = pd.DataFrame(all_issues)
        # Attach context
        if context_flags is not None:
            ctx_map = dict(zip(context_flags["column_name"], context_flags["context"].fillna("")))
            issues_df.insert(1, "context", issues_df["column_name"].map(ctx_map).fillna(""))
        else:
            issues_df.insert(1, "context", "")
    else:
        issues_df = pd.DataFrame(columns=[
            "column_name", "context", "issue_type", "severity", "affected_pct",
            "confidence", "urgency", "temporal_pattern", "worst_period",
            "worst_period_pct", "n_periods_flagged", "detail", "mitigation",
        ])

    _urg_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
    if not issues_df.empty:
        issues_df["_urg_sort"] = issues_df["urgency"].map(_urg_order)
        issues_df = issues_df.sort_values(["_urg_sort", "column_name"]).drop(columns=["_urg_sort"]).reset_index(drop=True)

    def _cnt(urg):
        return int((issues_df["urgency"] == urg).sum()) if not issues_df.empty else 0

    # Determine which inputs were present
    sources = {
        "missing":      missing_summary is not None,
        "outliers":     outlier_summary is not None,
        "distribution": dist_summary    is not None,
    }

    meta = {
        "stem":          Path(cleaned_path).stem.replace("_numerical_cleaned", ""),
        "n_issues":      len(issues_df),
        "n_critical":    _cnt("critical"),
        "n_high":        _cnt("high"),
        "n_medium":      _cnt("medium"),
        "n_low":         _cnt("low"),
        "n_columns":     int(issues_df["column_name"].nunique()) if not issues_df.empty else 0,
        "time_col":      time_col,
        "sources":       sources,
        "generated":     datetime.now().strftime("%Y-%m-%d %H:%M"),
    }
    return issues_df, meta


# ── HTML template ──────────────────────────────────────────────────────────────
_HTML_TEMPLATE = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Numerical Diagnosis — {{ meta.stem }}</title>
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Segoe UI', system-ui, sans-serif; background: #f7f8fa;
         color: #1a1a2e; font-size: 14px; }
  h1   { font-size: 1.4rem; font-weight: 700; padding: 24px 32px 4px; }
  h2   { font-size: 1.05rem; font-weight: 600; margin-bottom: 12px; }
  .subtitle { color: #666; font-size: 0.82rem; padding: 0 32px 20px; }

  /* summary strip */
  .strip { display: flex; gap: 12px; padding: 0 32px 24px; flex-wrap: wrap; }
  .scard { background: #fff; border: 1px solid #e0e0e0; border-radius: 8px;
           padding: 10px 18px; min-width: 120px; text-align: center; }
  .snum  { font-size: 1.55rem; font-weight: 700; }
  .slbl  { font-size: 0.72rem; color: #888; text-transform: uppercase; letter-spacing: .04em; }
  .snum.c { color: #c62828; } .snum.h { color: #e65100; }
  .snum.m { color: #f57f17; } .snum.l { color: #757575; } .snum.t { color: #283593; }

  /* column overview table */
  .section { padding: 0 32px 28px; }
  table { width: 100%; border-collapse: collapse; background: #fff;
          border: 1px solid #e0e0e0; border-radius: 8px; overflow: hidden;
          font-size: 0.82rem; }
  th { background: #f0f0f5; font-weight: 600; padding: 8px 12px; text-align: left;
       border-bottom: 1px solid #e0e0e0; white-space: nowrap; }
  td { padding: 8px 12px; border-bottom: 1px solid #f0f0f0; vertical-align: top; }
  tr:last-child td { border-bottom: none; }

  /* badges */
  .badge { display: inline-block; font-size: 0.72rem; font-weight: 600;
           padding: 2px 7px; border-radius: 10px; white-space: nowrap; }
  .urg-critical { background: #ffebee; color: #c62828; }
  .urg-high     { background: #fff3e0; color: #e65100; }
  .urg-medium   { background: #fffde7; color: #f57f17; }
  .urg-low      { background: #f5f5f5; color: #757575; }
  .sev-dqi      { background: #fce4ec; color: #ad1457; }
  .sev-sus      { background: #fff3e0; color: #e65100; }
  .sev-leg      { background: #e8f5e9; color: #2e7d32; }
  .ctx-badge    { background: #e8eaf6; color: #283593; }
  .itype-badge  { background: #f3e5f5; color: #6a1b9a; }
  .tp-badge     { background: #e0f2f1; color: #00695c; }

  /* issue cards */
  .urgency-section { padding: 0 32px 28px; }
  .urgency-header { font-size: 1rem; font-weight: 700; padding: 10px 16px;
                    border-radius: 6px 6px 0 0; color: #fff; margin-bottom: 0; }
  .uh-critical { background: #c62828; } .uh-high { background: #e65100; }
  .uh-medium   { background: #f57f17; } .uh-low  { background: #757575; }

  .card { background: #fff; border: 1px solid #e0e0e0; border-top: none;
          padding: 16px 20px; }
  .card + .card { border-top: 1px solid #f0f0f0; }
  .card:last-child { border-radius: 0 0 6px 6px; }
  .card-header { display: flex; align-items: flex-start; gap: 10px; flex-wrap: wrap;
                 margin-bottom: 10px; }
  .col-name { font-weight: 700; font-size: 0.95rem; font-family: monospace; }
  .card-meta { display: flex; gap: 8px; flex-wrap: wrap; align-items: center; }

  .conf-wrap { display: flex; align-items: center; gap: 6px; font-size: 0.78rem; }
  .conf-bar  { width: 72px; height: 7px; background: #e0e0e0; border-radius: 4px; overflow: hidden; }
  .conf-fill { height: 100%; border-radius: 4px; }
  .conf-fill.c { background: #c62828; } .conf-fill.h { background: #e65100; }
  .conf-fill.m { background: #f57f17; } .conf-fill.l { background: #9e9e9e; }

  .card-body p { font-size: 0.83rem; color: #333; margin-bottom: 6px; line-height: 1.5; }
  .card-body .label { font-weight: 600; color: #555; display: inline-block;
                      min-width: 90px; font-size: 0.78rem; text-transform: uppercase;
                      letter-spacing: .03em; }
  .mitigation { background: #e8f5e9; border-left: 3px solid #2e7d32;
                padding: 8px 12px; border-radius: 0 4px 4px 0;
                font-size: 0.82rem; color: #1b5e20; margin-top: 8px; }
  .no-issues  { color: #888; font-style: italic; padding: 20px 32px; }
</style>
</head>
<body>

<h1>Numerical Data Diagnosis — {{ meta.stem }}</h1>
<p class="subtitle">
  Generated {{ meta.generated }}
  &nbsp;|&nbsp; {{ meta.n_columns }} column(s) with issues
  &nbsp;|&nbsp; Sources: {% for s, ok in meta.sources.items() %}{{ s }}{% if ok %} ✓{% else %} —{% endif %}{% if not loop.last %}, {% endif %}{% endfor %}
  {% if meta.time_col %}&nbsp;|&nbsp; Temporal axis: {{ meta.time_col }}{% endif %}
</p>

<!-- Summary strip -->
<div class="strip">
  <div class="scard"><div class="snum t">{{ meta.n_issues }}</div><div class="slbl">Total Issues</div></div>
  <div class="scard"><div class="snum c">{{ meta.n_critical }}</div><div class="slbl">Critical</div></div>
  <div class="scard"><div class="snum h">{{ meta.n_high }}</div><div class="slbl">High</div></div>
  <div class="scard"><div class="snum m">{{ meta.n_medium }}</div><div class="slbl">Medium</div></div>
  <div class="scard"><div class="snum l">{{ meta.n_low }}</div><div class="slbl">Low</div></div>
</div>

<!-- Column overview table -->
{% if col_overview %}
<div class="section">
  <h2>Column overview</h2>
  <table>
    <thead>
      <tr>
        <th>Column</th><th>Context</th><th>Issues</th><th>Worst urgency</th>
      </tr>
    </thead>
    <tbody>
      {% for row in col_overview %}
      <tr>
        <td><code>{{ row.column_name }}</code></td>
        <td>{% if row.context %}<span class="badge ctx-badge">{{ row.context }}</span>{% else %}—{% endif %}</td>
        <td>
          {% for it in row.issue_types %}
            <span class="badge itype-badge">{{ it }}</span>
          {% endfor %}
        </td>
        <td><span class="badge urg-{{ row.worst_urgency }}">{{ row.worst_urgency }}</span></td>
      </tr>
      {% endfor %}
    </tbody>
  </table>
</div>
{% endif %}

<!-- Issue cards by urgency -->
{% for urg in ["critical", "high", "medium", "low"] %}
{% set urg_issues = issues | selectattr("urgency", "equalto", urg) | list %}
{% if urg_issues %}
<div class="urgency-section">
  <div class="urgency-header uh-{{ urg }}">
    {{ urg | upper }} — {{ urg_issues | length }} issue(s)
  </div>
  {% for issue in urg_issues %}
  {% set conf_pct = (issue.confidence * 100) | int %}
  {% set conf_cls = "c" if issue.urgency == "critical" else ("h" if issue.urgency == "high" else ("m" if issue.urgency == "medium" else "l")) %}
  <div class="card">
    <div class="card-header">
      <span class="col-name">{{ issue.column_name }}</span>
      <div class="card-meta">
        {% if issue.context %}<span class="badge ctx-badge">{{ issue.context }}</span>{% endif %}
        <span class="badge itype-badge">{{ issue.issue_type }}</span>
        <span class="badge sev-{{ "dqi" if issue.severity == "data_quality_issue" else ("sus" if issue.severity == "suspicious" else "leg") }}">{{ issue.severity }}</span>
        {% if issue.affected_pct != "" and issue.affected_pct != 100.0 %}
        <span class="badge" style="background:#e3f2fd;color:#0d47a1;">{{ issue.affected_pct }}% affected</span>
        {% endif %}
        {% if issue.temporal_pattern and issue.temporal_pattern != "none" %}
        <span class="badge tp-badge">{{ issue.temporal_pattern }}</span>
        {% endif %}
        <div class="conf-wrap">
          <div class="conf-bar"><div class="conf-fill {{ conf_cls }}" style="width:{{ conf_pct }}%"></div></div>
          <span style="color:#555;font-size:0.78rem;">confidence: {{ issue.confidence }}</span>
        </div>
      </div>
    </div>
    <div class="card-body">
      <p><span class="label">Finding</span> {{ issue.detail }}</p>
      {% if issue.worst_period %}
      <p><span class="label">Worst period</span> {{ issue.worst_period }}{% if issue.worst_period_pct %} ({{ issue.worst_period_pct }}% of that period's rows){% endif %}
        &nbsp;|&nbsp; {{ issue.n_periods_flagged }} period(s) affected</p>
      {% endif %}
      <div class="mitigation"><strong>Mitigation:</strong> {{ issue.mitigation }}</div>
    </div>
  </div>
  {% endfor %}
</div>
{% endif %}
{% endfor %}

{% if not issues %}
<p class="no-issues">No data quality issues detected across all numerical columns.</p>
{% endif %}

</body>
</html>"""


def render_html(issues_df: pd.DataFrame, meta: dict, stem: str) -> str:
    """Render the issues report as a self-contained HTML string."""
    issues = issues_df.to_dict(orient="records")

    # Build column overview (one row per column, worst urgency + all issue types)
    _urg_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
    col_overview = []
    if issues:
        for col_name, grp in issues_df.groupby("column_name", sort=False):
            worst = grp["urgency"].map(_urg_order).idxmin()
            col_overview.append({
                "column_name":  col_name,
                "context":      grp["context"].iloc[0] if "context" in grp.columns else "",
                "issue_types":  grp["issue_type"].tolist(),
                "worst_urgency": grp.loc[worst, "urgency"],
            })
        col_overview.sort(key=lambda r: _urg_order.get(r["worst_urgency"], 99))

    tmpl = Template(_HTML_TEMPLATE)
    return tmpl.render(meta=meta, issues=issues, col_overview=col_overview, stem=stem)


# ── Save outputs ───────────────────────────────────────────────────────────────
def save_outputs(stem: str) -> None:
    print(f"\n{'='*60}")
    print(f"  diagnose_numerical  ->  {stem}")
    print(f"{'='*60}")

    cleaned_path         = Path("skill/clean_numerical/output") / f"{stem}_numerical_cleaned.csv"
    missing_summary_path = MISSING_DIR / f"{stem}_missing_summary.csv"
    missing_flags_path   = MISSING_DIR / f"{stem}_missing_flags.csv"
    outlier_summary_path = OUTLIER_DIR / f"{stem}_outlier_summary.csv"
    outlier_flags_path   = OUTLIER_DIR / f"{stem}_outlier_flags.csv"
    dist_summary_path    = DIST_DIR    / f"{stem}_distribution_summary.csv"
    dist_temporal_path   = DIST_DIR    / f"{stem}_distribution_temporal.csv"
    context_flags_path   = CONTEXT_DIR / f"{stem}_type_flags_context.csv"
    raw_copy_path        = RAW_DIR     / f"{stem}_raw_copy.csv"

    issues_df, meta = diagnose(
        cleaned_path,
        missing_summary_path=missing_summary_path,
        missing_flags_path=missing_flags_path,
        outlier_summary_path=outlier_summary_path,
        outlier_flags_path=outlier_flags_path,
        dist_summary_path=dist_summary_path,
        dist_temporal_path=dist_temporal_path,
        context_flags_path=context_flags_path,
        raw_copy_path=raw_copy_path,
    )

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    csv_path    = OUTPUT_DIR / f"{stem}_issues_report.csv"
    report_path = OUTPUT_DIR / f"{stem}_issues_report.html"

    issues_df.to_csv(csv_path, index=False)

    html = render_html(issues_df, meta, stem)
    report_path.write_text(html, encoding="utf-8")

    print(f"  Issues found     : {meta['n_issues']}")
    print(f"  Critical         : {meta['n_critical']}")
    print(f"  High             : {meta['n_high']}")
    print(f"  Medium           : {meta['n_medium']}")
    print(f"  Low              : {meta['n_low']}")
    print(f"  Temporal axis    : {meta['time_col'] or '(none detected)'}")
    print(f"  -> {csv_path.name}")
    print(f"  -> {report_path.name}")


# ── Entry point ────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    stems = [sys.argv[1]] if len(sys.argv) > 1 else STEMS
    for stem in stems:
        save_outputs(stem)
