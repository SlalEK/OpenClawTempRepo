# Methodology: diagnose_numerical

## Overview

This skill aggregates the outputs of all upstream numerical analysis steps into a single triage report. It does not perform new statistical computations; instead it interprets, enriches, and cross-references existing findings to produce confidence scores, urgency classifications, temporal concentration patterns, and actionable mitigation advice.

## Issue collection

Issues are collected from three sources:

### 1. Missing data (from `_missing_summary.csv` + `_missing_flags.csv`)
One issue record is created per column where `pct_missing > 0`. The miss type (`mcar_likely`, `mar`, `mnar`, `ambiguous`) is passed to the confidence function and also determines the mitigation template.

### 2. Outlier classes (from `_outlier_summary.csv` + `_outlier_flags.csv`)
Four potential issue records are created per column, one per class:

| Class | Issue type |
|-------|-----------|
| `invalid` | `invalid_outliers` |
| `structural` | `structural_sentinels` |
| `suspicious` | `suspicious_outliers` |
| `legitimate` | `legitimate_outliers` |

Records are only created when the count for that class is > 0.

### 3. Distribution and temporal (from `_distribution_summary.csv` + `_distribution_temporal.csv`)
- One `distribution_anomaly` record per column where `overall_class != "no_issue"`.
- One `temporal_shift` record per column where at least one time window has `shift == True`.

## Temporal concentration analysis

For issue types with per-row flags (missing_data, invalid_outliers, structural_sentinels, suspicious_outliers), the flagged row indices are joined to the raw date column from `_raw_copy.csv` and grouped into monthly periods. For each period, the flagged fraction is computed as:

$$\text{rate}(p) = \frac{\text{flagged rows in period } p}{\text{total rows in period } p}$$

The concentration pattern is then classified:

1. **Trend detection** — the last 6–8 periods with data are examined. If ≥ 75% of consecutive differences are positive → `increasing`; if ≥ 75% negative → `decreasing`.
2. **Concentration ratio** — defined as $\max(\text{rate}) / \text{mean}(\text{rate})$.
   - If ratio ≥ 3.0 and at most 15% of periods are flagged → `localized`.
   - If ≥ 55% of all periods have a non-zero flag rate → `widespread`.
   - Otherwise → `uniform`.

If no date column is available or no flagged rows can be matched to a period, the pattern is `none`.

## Confidence scoring

Confidence answers: **"How certain are we that this finding is correctly identified?"**

It reflects detection method reliability, sample size characteristics, and interpretation ambiguity. It does **not** reflect how severe or urgent the issue is — that is captured separately by urgency.

### Base confidence values

| Issue type | Base | Rationale |
|---|---|---|
| `invalid_outliers` | 0.95 | Rule-based, deterministic detection |
| `structural_sentinels` | 0.87 | Strong statistical clustering pattern |
| `distribution_anomaly` (legitimate) | 0.84 | Confident the expected pattern is correctly classified |
| `missing_data` (mcar_likely) | 0.80 | Values clearly absent; MCAR interpretation has statistical uncertainty |
| `distribution_anomaly` (data_quality_issue) | 0.78 | Boundary/spike detection is fairly reliable |
| `missing_data` (mar) | 0.70 | MAR harder to establish statistically |
| `missing_data` (mnar) | 0.65 | MNAR statistically indistinguishable from MCAR at low rates |
| `temporal_shift` | 0.65 | MAD-based test is robust but seasonal variation can fool it |
| `suspicious_outliers` | 0.60 | Statistical test; false positives possible for non-normal distributions |
| `distribution_anomaly` (suspicious) | 0.60 | Shape detection reliable; interpretation less certain |
| `legitimate_outliers` | 0.55 | Judgment call on extreme-but-valid values |
| `missing_data` (ambiguous) | 0.42 | Genuinely unclear what the null values represent |

### Sample and pattern adjustments

| Condition | Adjustment |
|---|---|
| `suspicious_outliers`, n_count < 3 | −0.15 (too few instances to be reliable) |
| `suspicious_outliers`, n_count < 10 | −0.07 |
| `suspicious_outliers`, n_count > 50 | +0.04 (large sample → more reliable) |
| `structural_sentinels`, structural_pct < 50% | −0.05 (pattern less dominant) |
| `temporal_shift`, n_shifted == 1 | −0.08 (single window may be noise) |
| `temporal_shift`, n_shifted ≥ 5 | +0.06 (strong recurring pattern) |
| `invalid_outliers`, n_count < 3 | −0.08 (very few instances may be isolated edge cases) |
| `invalid_outliers`, n_count < 10 | −0.03 |

Result is clamped to [0.10, 0.97].

## Urgency classification

Urgency answers: **"How urgently does this issue need to be addressed?"**

It is derived from severity class, scale of impact, and temporal trend. It does **not** depend on confidence.

### Hard rules

| Issue type | Logic |
|---|---|
| `invalid_outliers` | `critical` if > 5% affected; else `high` |
| `structural_sentinels` | `critical` if > 5% affected; else `high` |
| `missing_data` | `critical` > 20%; `high` > 5%; `medium` > 2%; `low` otherwise |
| `legitimate_outliers` | always `low` |

The rationale for hard rules on invalid/structural is that these represent definitively incorrect values — regardless of scale or confidence, they must be corrected before any downstream analysis.

### Score-based (all other issue types)

For `suspicious_outliers`, `distribution_anomaly`, and `temporal_shift`:

$$\text{total} = \text{sev\_score} + \text{scale\_score} + \text{trend\_score}$$

| Component | Value |
|---|---|
| `sev_score` | data_quality_issue = 3, suspicious = 2, legitimate = 1 |
| `scale_score` | > 20% = 3, > 10% = 2, > 5% = 1, ≥ 1% = 0, < 1% = −1 |
| `trend_score` | increasing = +2, widespread = +1, decreasing = +1, localized = −1, otherwise = 0 |

| Total | Urgency |
|---|---|
| ≥ 7 | `critical` |
| ≥ 5 | `high` |
| ≥ 3 | `medium` |
| < 3 | `low` |

## Mitigation advice

Mitigation text is templated per issue type and adjusted where relevant:

| Issue type | Mitigation approach |
|---|---|
| `missing_data` (mcar_likely) | Impute with median or drop rows |
| `missing_data` (ambiguous) | Verify with data owner: zero fill vs. median imputation |
| `missing_data` (mar) | Model-based imputation using correlated columns |
| `missing_data` (mnar) | Document and exclude, or address at source — median imputation introduces bias |
| `invalid_outliers` | Correct or set to NaN; apply domain rules |
| `structural_sentinels` | Replace with NaN and impute; consult data owner for correct mapping |
| `suspicious_outliers` | Review with domain expert; winsorise at p1/p99 if confirmed noise |
| `legitimate_outliers` | No action required; consider winsorisation for regression models |
| `distribution_anomaly` (data_quality_issue) | Investigate truncation, spike, or zero-inflation at source |
| `distribution_anomaly` (suspicious) | Verify shape; consider log-transform or sub-population split |
| `distribution_anomaly` (legitimate) | No action; note shape for model selection |
| `temporal_shift` | Investigate process or source-system changes around affected periods |

## Output schema (`_issues_report.csv`)

| Column | Type | Description |
|--------|------|-------------|
| `column_name` | str | Column in the source dataset |
| `context` | str | Semantic context label (amount, duration, count, etc.) |
| `issue_type` | str | One of the seven issue types |
| `severity` | str | `data_quality_issue`, `suspicious`, or `legitimate` |
| `affected_pct` | float | % of rows (or % of windows for temporal_shift) affected |
| `confidence` | float | Confidence score [0.10, 0.97] |
| `urgency` | str | `critical`, `high`, `medium`, or `low` |
| `temporal_pattern` | str | Concentration pattern (none / uniform / localized / widespread / increasing / decreasing) |
| `worst_period` | str | ISO period (YYYY-MM) with highest flag rate |
| `worst_period_pct` | float | Flag rate in the worst period (%) |
| `n_periods_flagged` | int | Number of time periods with at least one flag |
| `detail` | str | Human-readable explanation of the finding |
| `mitigation` | str | Recommended corrective action |
