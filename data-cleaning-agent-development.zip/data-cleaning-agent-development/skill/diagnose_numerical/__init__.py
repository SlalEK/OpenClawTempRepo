from skill.diagnose_numerical.diagnose_numerical import (
    diagnose, render_html, save_outputs,
)

# Programmatic usage:
# issues_df, meta = diagnose(
#     cleaned_path="skill/clean_numerical/output/<stem>_numerical_cleaned.csv",
#     missing_summary_path=..., outlier_summary_path=..., dist_summary_path=..., ...
# )
