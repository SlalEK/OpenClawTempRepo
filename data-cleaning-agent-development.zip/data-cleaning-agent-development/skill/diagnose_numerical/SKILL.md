# Skill: diagnose_numerical

Aggregates all numerical data-quality findings from the upstream analysis skills into a unified triage report with confidence scores, urgency levels, temporal concentration analysis, and actionable mitigation advice.

## Pipeline position

```
detect_data_types
context_numerical
clean_numerical
profile_numerical
analyse_missing_numerical       ← feeds this skill
analyse_outliers_numerical      ← feeds this skill
analyse_distribution_numerical  ← feeds this skill
→ diagnose_numerical               ← this skill (final wrap-up)
```

## Inputs

| File | Source skill | Required | Purpose |
|------|-------------|----------|---------|
| `<stem>_missing_summary.csv` | `analyse_missing_numerical` | Recommended | Missing data rates and miss type per column |
| `<stem>_missing_flags.csv` | `analyse_missing_numerical` | Recommended | Per-row missing flags for temporal grouping |
| `<stem>_outlier_summary.csv` | `analyse_outliers_numerical` | Recommended | Outlier counts per class per column |
| `<stem>_outlier_flags.csv` | `analyse_outliers_numerical` | Recommended | Per-row outlier flags for temporal grouping |
| `<stem>_distribution_summary.csv` | `analyse_distribution_numerical` | Recommended | Shape classification and anomaly class per column |
| `<stem>_distribution_temporal.csv` | `analyse_distribution_numerical` | Recommended | Per-window median shift flags |
| `<stem>_type_flags_context.csv` | `context_numerical` | Optional | Column context labels for display |
| `<stem>_raw_copy.csv` | `detect_data_types` | Optional | Raw date column for temporal concentration grouping |

All inputs are optional — the skill gracefully skips any that are absent and reports only from available sources.

## Outputs

| File | Description |
|------|-------------|
| `<stem>_issues_report.csv` | One row per (column, issue_type) with confidence score, urgency, temporal pattern, and mitigation |
| `<stem>_issues_report.html` | Self-contained HTML triage report with summary strip, column overview table, and urgency-grouped issue cards |

## Issue types

| Issue type | Source | Severity |
|---|---|---|
| `missing_data` | `_missing_summary.csv` | `data_quality_issue` |
| `invalid_outliers` | `_outlier_summary.csv` | `data_quality_issue` |
| `structural_sentinels` | `_outlier_summary.csv` | `data_quality_issue` |
| `suspicious_outliers` | `_outlier_summary.csv` | `suspicious` |
| `legitimate_outliers` | `_outlier_summary.csv` | `legitimate` |
| `distribution_anomaly` | `_distribution_summary.csv` | matches `overall_class` |
| `temporal_shift` | `_distribution_temporal.csv` | `suspicious` |

## Urgency classification

| Urgency | Criteria |
|---------|---------|
| `critical` | `invalid_outliers` / `structural_sentinels` with > 5% affected; or `missing_data` > 20% |
| `high` | `invalid_outliers` / `structural_sentinels` (any count); `missing_data` > 5%; confidence ≥ 0.80 for other types |
| `medium` | `missing_data` 2–5%; confidence ≥ 0.55 for other types |
| `low` | `legitimate_outliers` (always); small missing < 2%; low confidence findings |

## Confidence score

A value between 0.10 and 0.97 representing certainty that the finding represents a real, actionable data quality problem.

Base confidence per issue type is adjusted by:
- **Scale of impact** — higher affected % increases confidence
- **Temporal concentration** — increasing/decreasing trend +0.05 to +0.08; localized to 1–2 periods −0.09
- **Ambiguity** — ambiguous miss type reduces confidence by 0.14

## Temporal concentration patterns

When `_raw_copy.csv` is available and contains a parseable date column, per-row flags are grouped by monthly period to detect temporal concentration:

| Pattern | Meaning |
|---------|---------|
| `none` | No temporal data available |
| `uniform` | Issue rate is evenly distributed across all periods |
| `widespread` | Issue present in ≥ 55% of time periods |
| `localized` | Issue concentrated in ≤ 2 periods (≥ 3× average rate) |
| `increasing` | Issue rate is monotonically increasing over recent periods |
| `decreasing` | Issue rate is monotonically decreasing over recent periods |

## Usage

```python
from skill.diagnose_numerical.diagnose_numerical import diagnose, render_html, save_outputs

# High-level: run and write all outputs
save_outputs("onderhoud_materieel")

# Low-level: programmatic access
issues_df, meta = diagnose(
    cleaned_path="skill/clean_numerical/output/onderhoud_materieel_numerical_cleaned.csv",
    missing_summary_path="skill/analyse_missing_numerical/output/onderhoud_materieel_missing_summary.csv",
    missing_flags_path="skill/analyse_missing_numerical/output/onderhoud_materieel_missing_flags.csv",
    outlier_summary_path="skill/analyse_outliers_numerical/output/onderhoud_materieel_outlier_summary.csv",
    outlier_flags_path="skill/analyse_outliers_numerical/output/onderhoud_materieel_outlier_flags.csv",
    dist_summary_path="skill/analyse_distribution_numerical/output/onderhoud_materieel_distribution_summary.csv",
    dist_temporal_path="skill/analyse_distribution_numerical/output/onderhoud_materieel_distribution_temporal.csv",
    context_flags_path="skill/context_numerical/output/onderhoud_materieel_type_flags_context.csv",
    raw_copy_path="skill/detect_data_types/output/onderhoud_materieel_raw_copy.csv",
)
```

## CLI

```bash
python -m skill.diagnose_numerical.diagnose_numerical
python -m skill.diagnose_numerical.diagnose_numerical onderhoud_materieel
```
