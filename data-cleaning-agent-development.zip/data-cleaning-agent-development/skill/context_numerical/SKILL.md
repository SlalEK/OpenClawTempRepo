---
name: context-numerical
description: 'Second step in the AI Data Cleaning pipeline, runs after detect-data-types and before clean-numerical. Classifies each numerical column with a semantic type: price, duration, count, percentage, ratio, measure, or score. Adds the result as a context column to a copy of the type flags file. Scale profiling, outlier detection, and missing value analysis are handled by dedicated later skills.'
argument-hint: 'Dataset stem name, e.g. onderhoud_materieel'
---

# Context: Numerical Columns

## Purpose
Determine the semantic meaning of each numerical column so that downstream skills know what kind of number they are handling.

## Prerequisites
The `detect-data-types` skill must have been run first.

## Semantic Types

| Label | Meaning |
|---|---|
| `price` | Monetary value (cost, amount, fee) |
| `duration` | Time span (hours, days, years) |
| `count` | Whole-number tally or frequency |
| `percentage` | Value on a 0–100 scale |
| `ratio` | Value on a 0–1 scale |
| `measure` | Physical measurement (distance, weight, temperature) |
| `score` | Rating, grade, or index |
| `unknown` | Could not be determined — review manually |

## Procedure

### Run on all configured datasets
```bash
python skill/context_numerical/context_numerical.py
```

### Run on a specific dataset
```bash
python skill/context_numerical/context_numerical.py onderhoud_materieel
```

### Import in another skill
```python
from skill.context_numerical import build_context

context = build_context(
    copy_path='skill/detect_data_types/output/onderhoud_materieel_raw_copy.csv',
    flags_path='skill/detect_data_types/output/onderhoud_materieel_type_flags.csv',
)
```

## Inputs
Read from `skill/detect_data_types/output/`:

| File | Description |
|---|---|
| `<name>_raw_copy.csv` | Unmodified data copy from detect_data_types |
| `<name>_type_flags.csv` | Column type flags from detect_data_types |

## Output
Written to `skill/context_numerical/output/`:

| File | Description |
|---|---|
| `<name>_type_flags_context.csv` | Copy of type_flags with `context` column added for numerical columns |

The original `detect_data_types` output is never modified.

## Dependencies
```bash
pip install -r skill/context_numerical/requirements.txt
```

## References
- [Detection logic and keyword rules](./METHODOLOGY.md)
