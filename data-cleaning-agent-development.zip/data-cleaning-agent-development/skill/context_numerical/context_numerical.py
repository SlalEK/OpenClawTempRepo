"""
Context Numerical Columns Skill
---------------------------------
Reads the output of the detect_data_types skill and determines the semantic
type for every numerical column:

    price | duration | count | percentage | ratio | measure | score | unknown

The result is written as a copy of the type_flags CSV with a 'context' column
added. Outlier detection, scale profiling, and missing value analysis are
handled by dedicated later skills.

Output:
    <filename>_type_flags_context.csv   — copy of type_flags + 'context' column
"""

import pandas as pd
import numpy as np
from pathlib import Path
import sys


# ── Folder layout ─────────────────────────────────────────────────────────────
BASE_DIR   = Path(__file__).parent
OUTPUT_DIR = BASE_DIR / 'output'
FLAGS_DIR  = BASE_DIR.parent / 'detect_data_types' / 'output'


# ── Semantic type keyword rules ───────────────────────────────────────────────
# Each entry: (semantic_type, unit, [keywords])
# Keywords are matched case-insensitively against the full column name.
# Rules are evaluated in order; first match wins.

KEYWORD_RULES = [
    ('price',      ['eur', 'euro', 'prijs', 'kosten', 'bedrag', 'tarief',
                    'cost', 'costs', 'amount', 'fee', 'price', 'salary',
                    'loon', 'salaris', 'waarde', 'value']),
    ('duration',   ['_uur', '_uren', '_min', '_minuten', '_minutes',
                    '_sec', '_seconden', '_seconds', '_dag', '_dagen', '_days',
                    '_maand', '_maanden', '_months', '_jaar', '_jaren', '_years',
                    'duur', 'duration', 'looptijd', 'hersteltijd', 'tijd']),
    ('count',      ['aantal', 'count', 'n_', 'num_', 'totaal', 'total',
                    'frequentie', 'frequency', 'uitzendingen', 'missions']),
    ('percentage', ['pct', 'perc', 'percent', 'procent', 'percentage']),
    ('ratio',      ['ratio', 'rate', 'factor', 'coeff', 'coefficient',
                    'verhouding']),
    ('score',      ['score', 'index', 'rank', 'rang', 'grade', 'cijfer',
                    'rating', 'beoordeling']),
    ('measure',    ['gewicht', 'weight', 'afstand', 'distance', 'lengte',
                    'length', 'hoogte', 'height', 'snelheid', 'speed',
                    'temperatuur', 'temperature', 'druk', 'pressure']),
]

# Outlier detection: values above (p95 * OUTLIER_FACTOR) are flagged.
# Kept for future use by a dedicated outlier skill.
# OUTLIER_FACTOR = 5.0


# ── Core detection logic ──────────────────────────────────────────────────────

def _detect_by_column_name(col: str) -> str | None:
    """Return semantic_type based on keyword match, or None."""
    col_lower = col.lower()
    for sem_type, keywords in KEYWORD_RULES:
        for kw in keywords:
            if kw in col_lower:
                return sem_type
    return None


def _detect_by_value_range(series: pd.Series) -> str:
    """Fallback: infer semantic type from the statistical profile."""
    non_null = series.dropna()
    if len(non_null) == 0:
        return 'unknown'

    vmin, vmax = non_null.min(), non_null.max()
    all_integers = (non_null % 1 == 0).all()

    if all_integers and vmin >= 0:
        return 'count'
    if 0 <= vmin and vmax <= 1:
        return 'ratio'
    if 0 <= vmin and vmax <= 100 and not all_integers:
        return 'percentage'

    return 'unknown'


def _compute_outlier_threshold(series: pd.Series) -> float | None:
    """Return a threshold above which values are considered outliers/sentinels."""
    non_null = series.dropna()
    if len(non_null) < 10:
        return None
    p95 = non_null.quantile(0.95)
    if p95 <= 0:
        return None
    return round(p95 * OUTLIER_FACTOR, 2)


def build_context(copy_path: str, flags_path: str) -> pd.DataFrame:
    """
    Determine the semantic type for all numerical columns.

    Parameters
    ----------
    copy_path  : path to <name>_raw_copy.csv from detect_data_types output
    flags_path : path to <name>_type_flags.csv from detect_data_types output

    Returns
    -------
    pd.DataFrame with columns: column_name, semantic_type
    """
    flags    = pd.read_csv(flags_path)
    num_cols = flags[flags['detected_type'] == 'numerical']['column_name'].tolist()

    if not num_cols:
        print('  No numerical columns found — skipping.')
        return pd.DataFrame()

    df = pd.read_csv(copy_path, usecols=num_cols)

    records = []
    for col in num_cols:
        s = pd.to_numeric(df[col], errors='coerce')

        sem_type = _detect_by_column_name(col)
        if sem_type is None:
            sem_type = _detect_by_value_range(s)

        records.append({
            'column_name':   col,
            'semantic_type': sem_type,
        })

    return pd.DataFrame(records)


# ── Main pipeline ─────────────────────────────────────────────────────────────

def save_outputs(stem: str) -> None:
    copy_path  = FLAGS_DIR / f'{stem}_raw_copy.csv'
    flags_path = FLAGS_DIR / f'{stem}_type_flags.csv'

    print(f'\n{"=" * 60}')
    print(f'Processing: {stem}')
    print('=' * 60)

    context = build_context(str(copy_path), str(flags_path))
    if context.empty:
        return

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    # ── Enriched flags CSV — copy of type_flags with context column added ─
    flags = pd.read_csv(flags_path)
    context_map = context.set_index('column_name')['semantic_type']
    flags['context'] = flags['column_name'].map(context_map).fillna('')
    enriched_flags_path = OUTPUT_DIR / f'{stem}_type_flags_context.csv'
    flags.to_csv(enriched_flags_path, index=False)

    print(f'Enriched flags   → {enriched_flags_path}')
    print()
    print(flags.to_string(index=False))


if __name__ == '__main__':
    stems = sys.argv[1:] if len(sys.argv) > 1 else [
        'onderhoud_materieel',
        'personeel_hr',
    ]
    for stem in stems:
        save_outputs(stem)
