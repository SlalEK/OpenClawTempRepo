# Methodology: Context Numerical Columns Skill

## Purpose

This skill is the second step in the AI Data Cleaning pipeline (before `clean-numerical`). It determines the **semantic type** of every numerical column — what kind of value it represents — and adds this as a `context` column to a copy of the type flags file.

Scale profiling, outlier detection, negative-value analysis, and missing value handling are deferred to dedicated later skills.

---

## Folder Structure

```
skill/
├── detect_data_types/output/
│   ├── <name>_raw_copy.csv               ← input
│   └── <name>_type_flags.csv             ← input
├── context_numerical/
│   ├── context_numerical.py
│   ├── METHODOLOGY.md
│   └── output/
│       └── <name>_type_flags_context.csv    ← output
└── clean_numerical/                      ← reads original type_flags
```

---

## Output

| File | Description |
|---|---|
| `<name>_type_flags_context.csv` | Copy of `type_flags.csv` with a `context` column added for numerical columns. The original `detect_data_types` output is never modified. |

The `context` column contains the semantic type label for numerical columns and is empty for all other column types.

---

## Semantic Type Classification

Detection is attempted in two stages. The first stage that produces a result wins.

### Stage 1 — Column name keyword matching

The column name is matched (case-insensitive, substring) against a fixed keyword vocabulary. Rules are evaluated in priority order; the first match wins.

| Semantic type | Example keywords |
|---|---|
| `price` | `eur`, `euro`, `kosten`, `prijs`, `bedrag`, `cost`, `amount`, `fee`, `salary` |
| `duration` | `_uur`, `_uren`, `_min`, `_dag`, `_jaar`, `hersteltijd`, `tijd`, `duration` |
| `count` | `aantal`, `count`, `totaal`, `total`, `uitzendingen`, `missions` |
| `percentage` | `pct`, `perc`, `percent`, `procent`, `percentage` |
| `ratio` | `ratio`, `rate`, `factor`, `coeff`, `verhouding` |
| `score` | `score`, `index`, `rank`, `rang`, `grade`, `cijfer`, `rating` |
| `measure` | `gewicht`, `weight`, `afstand`, `distance`, `lengte`, `height`, `druk` |

### Stage 2 — Value range heuristic (fallback)

If no keyword matches, the distribution of actual values is inspected:

| Condition | Assigned type |
|---|---|
| All non-null values are whole numbers ≥ 0 | `count` |
| All values in [0, 1] | `ratio` |
| All values in [0, 100] with decimals | `percentage` |
| Otherwise | `unknown` |

When the fallback is used, the result has lower confidence. **Review `unknown` assignments manually** before cleaning.

---

## Tuning Parameters

| Constant | Effect |
|---|---|
| `KEYWORD_RULES` | Add, remove, or reorder semantic type keywords |

---

## Known Boundary Cases

- **`hersteltijd_uur`**: matched by keyword `hersteltijd` → `duration`.
- **`kosten_eur`**: matched by keyword `eur` → `price`.
- **`aantal_uitzendingen`**: matched by keyword `uitzendingen` → `count`.
- **Ambiguous column names**: if no keyword matches, the value range heuristic is used. Columns returning `unknown` should be reviewed and the keyword list extended if needed.

