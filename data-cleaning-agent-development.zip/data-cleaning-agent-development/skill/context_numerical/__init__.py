"""
context-numerical skill — public API for downstream skills.

Usage
-----
    from skill.context_numerical import build_context

    context = build_context(
        copy_path='skill/detect_data_types/output/onderhoud_materieel_raw_copy.csv',
        flags_path='skill/detect_data_types/output/onderhoud_materieel_type_flags.csv',
    )
"""

from .context_numerical import build_context

__all__ = ['build_context']
