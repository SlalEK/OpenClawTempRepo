# Methodology: Clean Categorical Columns Skill

## Purpose

This skill is part of the AI Data Cleaning pipeline. It takes the output of the `detect-data-types` skill, filters to columns flagged as `categorical`, and applies four structural normalisation steps. The output contains only those columns, ready for analysis or further transformation such as typo correction or semantic deduplication.

---

## Folder Structure

```
skill/
├── detect_data_types/
│   └── output/
│       ├── <name>_raw_copy.csv          ← input: unmodified data copy
│       └── <name>_type_flags.csv        ← input: column type flags
└── clean_categorical/
    ├── clean_categorical.py
    ├── METHODOLOGY.md
    └── output/
        └── <name>_categorical_cleaned.csv   ← output: cleaned categorical columns
```

---

## Inputs

| File | Source |
|---|---|
| `<name>_raw_copy.csv` | Output of `detect-data-types` skill |
| `<name>_type_flags.csv` | Output of `detect-data-types` skill |

---

## Output

| File | Description |
|---|---|
| `<name>_categorical_cleaned.csv` | Only the categorical columns, structurally normalised |

---

## Cleaning Steps

The function `clean_categorical_columns()` applies four steps to every categorical column, in order.

### Step 1 — Whitespace normalisation

Leading and trailing whitespace is stripped from every string value. Runs of multiple internal whitespace characters (spaces, tabs, non-breaking spaces that were not yet converted) are collapsed to a single space.

| Input | Output |
|---|---|
| `"  in onderhoud "` | `"in onderhoud"` |
| `"in  onderhoud"` | `"in onderhoud"` |

This step is applied before all others so that subsequent comparisons and token lookups are not confused by extraneous whitespace.

### Step 2 — Unicode normalisation

Two passes are applied to every string value:

1. **NFKC normalisation** (`unicodedata.normalize('NFKC', …)`) — decomposes compatibility characters and recomposes them in canonical form. This converts ligatures (`ﬁ` → `fi`), full-width letters (`Ａ` → `A`), superscripts, and similar visually-similar-but-technically-distinct code points into their plain ASCII or standard Unicode equivalents.

2. **Typographic character replacement** — a fixed translation table (`_TYPOGRAPHIC_MAP`) converts characters that are commonly introduced by copy-paste from Word, PDFs, or web forms:

| Input character | Unicode code point | Replaced with |
|---|---|---|
| Left/right single quotation mark | U+2018, U+2019 | `'` (apostrophe) |
| Single low-9 quotation mark | U+201A | `'` |
| Left/right double quotation mark | U+201C, U+201D | `"` |
| Double low-9 quotation mark | U+201E | `"` |
| En dash | U+2013 | `-` |
| Em dash | U+2014 | `-` |
| Horizontal bar | U+2015 | `-` |
| Horizontal ellipsis | U+2026 | `...` |
| No-break space | U+00A0 | ` ` (regular space) |
| Narrow no-break space | U+202F | ` ` |
| Soft hyphen | U+00AD | *(removed)* |
| Zero-width space | U+200B | *(removed)* |
| Zero-width non-joiner | U+200C | *(removed)* |
| Zero-width joiner | U+200D | *(removed)* |
| Byte order mark | U+FEFF | *(removed)* |

A `[info]` message is printed for each column where at least one value was changed by this step.

### Step 3 — Null-like token replacement

String values that represent missing data but are not encoded as proper `NaN` are replaced with `NaN`. The check is case-insensitive and is applied to the stripped value (whitespace was removed in Step 1).

Default token vocabulary:

| Token | Notes |
|---|---|
| `` (empty string) | Empty cell stored as string |
| `-`, `--`, `---` | Placeholder dashes |
| `.` | Single-dot placeholder |
| `na`, `n/a`, `n.a.` | Common English missing markers |
| `n.v.t.`, `nvt` | Dutch: *niet van toepassing* |
| `n.b.`, `nb` | Dutch: *nota bene* / blank marker |
| `null`, `none`, `nil`, `nan`, `nat` | Programming conventions |
| `?` | Unknown marker |
| `onbekend`, `unknown` | Natural language missing labels |
| `missing`, `leeg` | Explicit missing labels |
| `niet van toepassing` | Full Dutch phrase |
| `not applicable` | Full English phrase |
| `undefined` | JavaScript / system default |

To add tokens, extend `NULL_LIKE_TOKENS` in the script.

A `[info]` message is printed for each column where at least one token was replaced, showing the count.

### Step 4 — Casefolding

Inconsistent casing within a column causes silent mismatches in grouping and downstream analysis (e.g. `"in onderhoud"` and `"IN ONDERHOUD"` are treated as distinct values without this step). Two strategies are applied based on the column's character:

| Column character | Criterion | Applied transformation |
|---|---|---|
| **Code / abbreviation column** | ≥ `UPPER_DOMINANCE_THRESHOLD` (default 80%) of non-null values are already ALL UPPER | `str.upper()` — uppercase is the canonical form |
| **Natural language / mixed column** | fewer than 80% of non-null values are ALL UPPER | `str.lower()` — lowercase is the canonical form |

**Rationale for the threshold approach:**

Columns like `onderdeel` (`CZSK`, `11AASLT BN`, `CLSK`) are institutionally defined ALL-UPPER codes where uppercase is the correct, standardised form. Lowercasing them would be semantically incorrect. The 80% threshold identifies these columns reliably while tolerating a small number of legacy lowercase entries in what is otherwise an all-caps column.

Columns like `status_materieel` (`"in onderhoud"`, `"IN ONDERHOUD"`, `"GEREPAREERD"`) are natural-language labels with inconsistent entry. Folding to lowercase unifies them while preserving the distinction between genuinely different values.

**What casefolding does not do:**

- It does not deduplicate semantically equivalent values across different spellings or languages (e.g. `"vast contract"` and `"vast"` remain distinct; `"gerepareerd"` and `"repaired"` remain distinct). That deduplication requires domain knowledge and is handled by a dedicated later skill.
- It does not correct typos or abbreviation expansions.

A `[info]` message is printed for every column showing the chosen style and the percentage of ALL-UPPER values observed.

---

## Boundary Cases

- **Mixed-case code columns** (e.g. `foutcode`: 75% ALL UPPER but not ≥ 80%) — folded to **lowercase**. Mixed entries like `"FC-038"` and `"f038"` both become `"fc-038"` / `"f038"`. Semantic deduplication of code variants is deferred.
- **Columns with no non-null values** — casefolding returns the column unchanged; no `[info]` message is printed.
- **NaN-like values already encoded as `NaN`** — not double-counted; the null-like token replacement checks `~was_null` before replacing.
- **Soft hyphens and zero-width characters** — removed silently by the unicode normalisation step. They are invisible in most editors but cause string comparisons to fail.
- **Columns with ligatures or full-width characters** — NFKC handles these before the typographic map is applied, so the map does not need to enumerate all compatibility variants.

---

## Tuning Parameters

| Constant | Default | Effect |
|---|---|---|
| `NULL_LIKE_TOKENS` | see above | Add or remove strings treated as missing values |
| `UPPER_DOMINANCE_THRESHOLD` | `0.80` | Lower to uppercase more columns; raise to be more conservative |
