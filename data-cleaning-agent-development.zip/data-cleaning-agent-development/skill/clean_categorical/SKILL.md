---
name: clean-categorical
description: 'Filters categorical columns from the detect_data_types output, normalises whitespace, applies NFKC unicode normalisation with typographic character replacement, replaces null-like tokens with NaN, and folds case consistently (ALL-UPPER code columns stay uppercase; all other columns fold to lowercase). Outputs a CSV containing only the cleaned categorical columns.'
argument-hint: 'Dataset stem name, e.g. onderhoud_materieel'
---

# Clean Categorical Columns

## Purpose
Isolate and clean all categorical columns from a dataset so they are structurally consistent and ready for analysis or further transformation.

## Pipeline position

```
detect_data_types
→ clean_categorical   ← this skill
```

## What It Does
1. **Filter** — selects only columns flagged as `categorical` in the detect_data_types output
2. **Whitespace normalisation** — strips leading/trailing whitespace; collapses multiple internal spaces to one (`"in  onderhoud"` → `"in onderhoud"`)
3. **Unicode normalisation** — applies NFKC normalisation (ligatures → ASCII, compatibility characters resolved) and replaces typographic characters with ASCII equivalents (curly quotes → straight, em-dash → hyphen, non-breaking space → space, zero-width characters removed)
4. **Null-like token replacement** — converts non-standard missing value representations (`N/A`, `-`, `onbekend`, `?`, `n.v.t.`, etc.) to proper `NaN`
5. **Casefolding** — ensures consistent case within each column:
   - Columns where ≥ 80% of non-null values are ALL UPPER → **uppercase** (code/abbreviation columns, e.g. `CZSK`, `FC-038`)
   - All other columns → **lowercase** (enables reliable grouping, e.g. `"in onderhoud"` / `"IN ONDERHOUD"` both become `"in onderhoud"`)

## What It Does Not Do
- Correct typos or spelling errors (deferred to a dedicated repair skill)
- Deduplicate semantically equivalent values (`"actief"` / `"active"`)
- Map domain-specific abbreviations to full forms
- Handle `free_text`, `id`, `date`, or `boolean` columns

## Procedure

### Run on all configured datasets
```bash
python -m skill.clean_categorical.clean_categorical
```

### Run on a specific dataset
```bash
python -m skill.clean_categorical.clean_categorical onderhoud_materieel
```

### Import in another skill
```python
from skill.clean_categorical import clean_categorical_columns

cleaned = clean_categorical_columns(
    copy_path='skill/detect_data_types/output/onderhoud_materieel_raw_copy.csv',
    flags_path='skill/detect_data_types/output/onderhoud_materieel_type_flags.csv',
)
```

## Inputs

| File | Source folder | Description |
|---|---|---|
| `<name>_raw_copy.csv` | `skill/detect_data_types/output/` | Unmodified data copy |
| `<name>_type_flags.csv` | `skill/detect_data_types/output/` | Column type flags |

## Output
Written to `skill/clean_categorical/output/`:

| File | Description |
|---|---|
| `<name>_categorical_cleaned.csv` | Only categorical columns, fully cleaned |

## Key tuning constants

| Constant | Default | Meaning |
|---|---|---|
| `UPPER_DOMINANCE_THRESHOLD` | 0.80 | Fraction of ALL-UPPER values required to uppercase a column |
| `NULL_LIKE_TOKENS` | (set) | Case-insensitive token set treated as missing values |
