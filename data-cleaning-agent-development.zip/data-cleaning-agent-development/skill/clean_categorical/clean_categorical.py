"""
Clean Categorical Columns Skill
---------------------------------
Reads the output of the detect_data_types skill (data copy + type flags),
filters to categorical columns only, and applies:

    1. Whitespace normalisation    — strip leading/trailing whitespace;
                                     collapse multiple internal spaces to one
    2. Unicode normalisation       — NFKC normalisation (ligatures, compatibility
                                     characters); typographic character replacement
                                     (curly quotes → straight, em-dash → hyphen,
                                     non-breaking space → regular space, etc.)
    3. Null-like token replacement — common non-standard missing value
                                     representations → NaN
    4. Casefolding                 — columns where ≥ 80% of non-null values are
                                     ALL UPPER (e.g. codes, abbreviations) are
                                     uppercased; all other columns are folded to
                                     lowercase to ensure consistent matching

String content (typos, mixed-language values, semantic deduplication) is left
to dedicated later skills; this skill only ensures structural consistency.

Output:
    <filename>_categorical_cleaned.csv   — only the categorical columns, cleaned
"""

import sys
import unicodedata
from pathlib import Path

import numpy as np
import pandas as pd


# ── Folder layout ─────────────────────────────────────────────────────────────
BASE_DIR   = Path(__file__).parent
OUTPUT_DIR = BASE_DIR / 'output'
FLAGS_DIR  = BASE_DIR.parent / 'detect_data_types' / 'output'


# ── Tuning parameters ─────────────────────────────────────────────────────────

# Strings (case-insensitive, after strip) that represent missing values
NULL_LIKE_TOKENS = {
    '', '-', '--', '---', '.',
    'na', 'n/a', 'n.a.', 'n.v.t.', 'nvt', 'n.b.', 'nb',
    'null', 'none', 'nil', 'nan', 'nat',
    '?', 'onbekend', 'unknown', 'missing', 'leeg',
    'niet van toepassing', 'not applicable', 'undefined',
}

# Fraction of non-null values that must be ALL UPPER to uppercase a column.
# All-uppercase columns are typically code / abbreviation columns (e.g. 'NL',
# 'CZSK', '11AASLT BN') whose uppercase form IS the canonical value.
UPPER_DOMINANCE_THRESHOLD = 0.80

# Typographic → ASCII replacements applied during unicode normalisation.
# These are visually similar but technically distinct characters that cause
# silent mismatches in comparisons and downstream analysis.
_TYPOGRAPHIC_MAP = str.maketrans({
    '\u2018': "'",   # LEFT SINGLE QUOTATION MARK
    '\u2019': "'",   # RIGHT SINGLE QUOTATION MARK
    '\u201a': "'",   # SINGLE LOW-9 QUOTATION MARK
    '\u201c': '"',   # LEFT DOUBLE QUOTATION MARK
    '\u201d': '"',   # RIGHT DOUBLE QUOTATION MARK
    '\u201e': '"',   # DOUBLE LOW-9 QUOTATION MARK
    '\u2013': '-',   # EN DASH
    '\u2014': '-',   # EM DASH
    '\u2015': '-',   # HORIZONTAL BAR
    '\u2026': '...', # HORIZONTAL ELLIPSIS
    '\u00a0': ' ',   # NO-BREAK SPACE
    '\u202f': ' ',   # NARROW NO-BREAK SPACE
    '\u00ad': '',    # SOFT HYPHEN (invisible — remove)
    '\u200b': '',    # ZERO WIDTH SPACE
    '\u200c': '',    # ZERO WIDTH NON-JOINER
    '\u200d': '',    # ZERO WIDTH JOINER
    '\ufeff': '',    # BYTE ORDER MARK
})


# ── Core cleaning functions ────────────────────────────────────────────────────

def _normalise_whitespace(series: pd.Series) -> pd.Series:
    """Strip leading/trailing whitespace; collapse multiple internal spaces to one."""
    result = series.str.strip()
    result = result.str.replace(r'\s+', ' ', regex=True)
    result[series.isna()] = np.nan
    return result


def _normalise_unicode(series: pd.Series, col_name: str) -> pd.Series:
    """Apply NFKC normalisation and replace typographic characters with ASCII equivalents."""
    def _fix(val: object) -> object:
        if not isinstance(val, str):
            return val
        val = unicodedata.normalize('NFKC', val)
        val = val.translate(_TYPOGRAPHIC_MAP)
        return val

    result = series.apply(_fix)
    changed = (result != series) & series.notna()
    if changed.any():
        print(f'  [info] {col_name}: unicode/typographic normalisation applied '
              f'to {changed.sum()} value(s)')
    return result


def _replace_null_like(series: pd.Series) -> pd.Series:
    """Replace null-like string tokens with NaN."""
    mask = series.astype(str).str.strip().str.lower().isin(NULL_LIKE_TOKENS)
    was_null = series.isna()
    series = series.copy()
    series[mask & ~was_null] = np.nan
    n_replaced = int((mask & ~was_null).sum())
    return series, n_replaced


def _casefold(series: pd.Series, col_name: str) -> pd.Series:
    """Apply consistent casefolding.

    Strategy
    --------
    - If ≥ UPPER_DOMINANCE_THRESHOLD of non-null values are ALL UPPER →
      uppercase the entire column.  These are code / abbreviation columns
      (e.g. 'CZSK', 'FC-038', 'D-DHG') where uppercase is the canonical form.
    - Otherwise → lowercase the entire column to ensure consistent matching
      (e.g. 'in onderhoud' / 'IN ONDERHOUD' / 'In Onderhoud' all become
      'in onderhoud').
    """
    non_null = series.dropna()
    if len(non_null) == 0:
        return series

    str_vals  = non_null.astype(str)
    pct_upper = (str_vals == str_vals.str.upper()).mean()

    if pct_upper >= UPPER_DOMINANCE_THRESHOLD:
        result = series.str.upper()
        style  = 'upper'
    else:
        result = series.str.lower()
        style  = 'lower'

    result[series.isna()] = np.nan
    print(f'  [info] {col_name}: casefolded to {style} '
          f'({pct_upper * 100:.0f}% of values were ALL UPPER)')
    return result


# ── Public API ─────────────────────────────────────────────────────────────────

def clean_categorical_columns(
    copy_path: str,
    flags_path: str,
) -> pd.DataFrame:
    """Filter, clean and standardise categorical columns.

    Parameters
    ----------
    copy_path  : path to <name>_raw_copy.csv from detect_data_types output
    flags_path : path to <name>_type_flags.csv from detect_data_types output

    Returns
    -------
    pd.DataFrame with only the cleaned categorical columns (object dtype)
    """
    flags    = pd.read_csv(flags_path)
    cat_cols = flags[flags['detected_type'] == 'categorical']['column_name'].tolist()

    if not cat_cols:
        print('  No categorical columns found — skipping.')
        return pd.DataFrame()

    # Read all categorical columns as strings; empty cells stay NaN
    df = pd.read_csv(copy_path, usecols=cat_cols, dtype=str)

    total_nulls_replaced = 0

    for col in cat_cols:
        original_null_count = df[col].isna().sum()

        df[col] = _normalise_whitespace(df[col])
        df[col] = _normalise_unicode(df[col], col)
        df[col], n_null = _replace_null_like(df[col])
        df[col] = _casefold(df[col], col)

        new_null_count = df[col].isna().sum()
        n_new_nulls    = new_null_count - original_null_count
        total_nulls_replaced += n_new_nulls
        if n_new_nulls > 0:
            print(f'  [info] {col}: {n_new_nulls} null-like token(s) replaced with NaN')

    print(f'  Null-like tokens replaced : {total_nulls_replaced}')
    return df


# ── Main pipeline ──────────────────────────────────────────────────────────────

def save_outputs(stem: str) -> None:
    """Run cleaning for a dataset identified by its stem name."""
    copy_path  = FLAGS_DIR / f'{stem}_raw_copy.csv'
    flags_path = FLAGS_DIR / f'{stem}_type_flags.csv'

    print(f'\n{"=" * 60}')
    print(f'Processing: {stem}')
    print('=' * 60)

    cleaned = clean_categorical_columns(str(copy_path), str(flags_path))

    if cleaned.empty:
        return

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    out_path = OUTPUT_DIR / f'{stem}_categorical_cleaned.csv'
    cleaned.to_csv(out_path, index=False)

    print(f'Output      -> {out_path.name}')
    print(f'Shape       : {cleaned.shape[0]} rows x {cleaned.shape[1]} columns')
    print()
    print(cleaned.dtypes.rename('dtype').to_frame().to_string())
    print()
    print('Missing values:')
    print(cleaned.isna().sum().rename('n_missing').to_frame().to_string())


if __name__ == '__main__':
    # Usage: python clean_categorical.py [stem1 stem2 ...]
    stems = sys.argv[1:] if len(sys.argv) > 1 else [
        'onderhoud_materieel',
        'personeel_hr',
    ]
    for stem in stems:
        save_outputs(stem)
