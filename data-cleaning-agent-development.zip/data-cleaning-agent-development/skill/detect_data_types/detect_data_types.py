"""
Data Type Detection Script
--------------------------
Reads a CSV file, makes a copy, and detects the data type per column.

Detected types:
    - numerical  : numeric values (int, float)
    - categorical: limited set of string values (e.g. status, type, rang)
    - datetime   : date or time values in any common format
    - boolean    : binary true/false or yes/no values
    - id         : structured unique identifiers (e.g. LOG-01438, TECH-617)
    - free_text  : open-ended descriptive text (e.g. aantekeningen)

Output:
    - <filename>_raw_copy.csv        : copy of the original data (unmodified)
    - <filename>_type_flags.csv  : one row per column with its detected type
"""

import pandas as pd
import re
import sys
from pathlib import Path

# ── Folder layout ─────────────────────────────────────────────────────────────
# skill/
#   detect_data_types.py   ← this file
#   output/                ← generated files land here
# data/                    ← input CSV files

BASE_DIR   = Path(__file__).parent              # skill/detect_data_types/
OUTPUT_DIR = BASE_DIR / 'output'                # skill/detect_data_types/output/
DATA_DIR   = BASE_DIR.parent.parent / 'data'    # data/


# ── Tuning parameters ────────────────────────────────────────────────────────

# Max fraction of unique values vs total rows before a column is NOT categorical
CATEGORICAL_CARDINALITY_THRESHOLD = 0.10
# Max number of unique values to always consider categorical (regardless of cardinality)
CATEGORICAL_MAX_UNIQUE = 20
# Min fraction of unique values vs total rows to consider a column an ID
ID_CARDINALITY_THRESHOLD = 0.15
# Max average string length for an ID column
ID_MAX_AVG_LENGTH = 25
# Fraction of values that must match the ID regex (no spaces, structured)
ID_PATTERN_MIN_MATCH = 0.90
# Min fraction of values that must contain at least one digit to qualify as ID
ID_DIGIT_MIN_MATCH = 0.50
# Fraction of sampled values that must parse as dates to call it datetime
DATETIME_SAMPLE_THRESHOLD = 0.80
# How many values to sample for the slow date-parse check
DATETIME_SAMPLE_SIZE = 30
# Min fraction of values that must contain a comma to trigger multi_categorical check
MULTI_CATEGORICAL_COMMA_MIN = 0.30
# Max number of unique individual tokens (after splitting) for multi_categorical
MULTI_CATEGORICAL_MAX_TOKENS = 200

# Regex for ID-like values: letters, digits, hyphens, underscores, dots, single spaces
_ID_PATTERN = re.compile(r'^[A-Za-z0-9\-_\. ]+$')

# Values considered boolean (case-insensitive)
_BOOLEAN_VALUES = {
    'true', 'false',
    'yes', 'no',
    'ja', 'nee',
    '1', '0',
    'y', 'n',
    'x', '',          # sometimes a checkbox column uses X / blank
}


# ── Core detection logic ──────────────────────────────────────────────────────

def _try_parse_datetime_series(series: pd.Series) -> bool:
    """Return True if pandas can parse the whole series as datetime."""
    try:
        pd.to_datetime(series, infer_datetime_format=True, errors='raise')
        return True
    except Exception:
        return False


def _sample_parse_datetime(series: pd.Series) -> bool:
    """Return True if most sampled values can be parsed as dates by dateutil."""
    try:
        from dateutil import parser as du_parser
    except ImportError:
        return False  # dateutil not installed — skip fuzzy check

    sample = series.dropna().head(DATETIME_SAMPLE_SIZE).astype(str)
    hits = 0
    for val in sample:
        try:
            du_parser.parse(val, fuzzy=False)
            hits += 1
        except Exception:
            pass

    return hits / max(len(sample), 1) >= DATETIME_SAMPLE_THRESHOLD


def detect_column_type(series: pd.Series) -> str:
    """Detect the semantic data type of a single pandas Series (column)."""

    non_null = series.dropna()
    n_total = len(series)
    n_non_null = len(non_null)

    if n_non_null == 0:
        return 'unknown'

    # ── 1. Boolean (native dtype) ─────────────────────────────────────────
    if series.dtype == bool:
        return 'boolean'

    # ── 2. Numeric dtype ─────────────────────────────────────────────────
    if pd.api.types.is_numeric_dtype(series):
        n_unique = non_null.nunique()
        # A numeric column with only 2 unique values (0/1) → boolean
        if n_unique == 2 and set(non_null.unique()).issubset({0, 1, 0.0, 1.0}):
            return 'boolean'
        return 'numerical'

    # ── From here the column is object/string dtype ───────────────────────
    str_series = non_null.astype(str).str.strip()

    # ── 3. Boolean (string representation) ───────────────────────────────
    unique_lower = set(str_series.str.lower().unique())
    if unique_lower <= _BOOLEAN_VALUES and 1 < len(unique_lower) <= 4:
        return 'boolean'

    # ── 4. Numeric stored as string ───────────────────────────────────────
    numeric_parsed = pd.to_numeric(str_series, errors='coerce')
    if numeric_parsed.notna().mean() >= 0.90:
        return 'numerical'

    # ── 5. Datetime ───────────────────────────────────────────────────────
    if _try_parse_datetime_series(non_null):
        return 'datetime'
    if _sample_parse_datetime(non_null):
        return 'datetime'

    # ── 6. Multi-categorical ─────────────────────────────────────────────
    # Detects columns that store multiple comma-separated values drawn from
    # a small closed vocabulary (e.g. opleiding: "EHBO, Verkenner, CBRN basis")
    comma_fraction = str_series.str.contains(',').mean()
    if comma_fraction >= MULTI_CATEGORICAL_COMMA_MIN:
        all_tokens = (
            str_series
            .str.split(',')
            .explode()
            .str.strip()
            .dropna()
        )
        if all_tokens.nunique() <= MULTI_CATEGORICAL_MAX_TOKENS:
            return 'multi_categorical'

    # ── 7. ID vs categorical vs free_text ────────────────────────────────
    n_unique = str_series.nunique()
    cardinality = n_unique / n_non_null
    avg_length = str_series.str.len().mean()
    id_pattern_match = str_series.str.match(_ID_PATTERN).mean()
    id_digit_match = str_series.str.contains(r'\d').mean()

    # ID: high cardinality, short structured tokens, must contain digits
    if (
        cardinality >= ID_CARDINALITY_THRESHOLD
        and id_pattern_match >= ID_PATTERN_MIN_MATCH
        and avg_length <= ID_MAX_AVG_LENGTH
        and id_digit_match >= ID_DIGIT_MIN_MATCH
    ):
        return 'id'

    # Categorical: low cardinality or small absolute number of unique values
    if cardinality <= CATEGORICAL_CARDINALITY_THRESHOLD or n_unique <= CATEGORICAL_MAX_UNIQUE:
        return 'categorical'

    # Everything else: free-form text
    return 'free_text'


# ── Main pipeline ─────────────────────────────────────────────────────────────

def flag_data_types(csv_path: str, sep: str = ',') -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Read a CSV, make a copy, and detect the data type per column.

    Returns
    -------
    data_copy : pd.DataFrame
        Exact copy of the source data (unmodified).
    type_flags : pd.DataFrame
        One row per column with columns:
            column_name, detected_type
    """
    source_path = Path(csv_path)
    df = pd.read_csv(source_path, sep=sep)

    # Make an explicit copy so the original DataFrame is untouched
    data_copy = df.copy()

    # Detect type per column
    records = []
    for col in df.columns:
        records.append({
            'column_name':   col,
            'detected_type': detect_column_type(df[col]),
        })

    type_flags = pd.DataFrame(records)
    return data_copy, type_flags


def save_outputs(csv_path: str, sep: str = ',') -> None:
    """Run detection and save both outputs next to the source file."""
    source_path = Path(csv_path)
    stem = source_path.stem

    data_copy, type_flags = flag_data_types(csv_path, sep=sep)

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    copy_path  = OUTPUT_DIR / f"{stem}_raw_copy.csv"
    flags_path = OUTPUT_DIR / f"{stem}_type_flags.csv"

    data_copy.to_csv(copy_path, index=False)
    type_flags.to_csv(flags_path, index=False)

    print(f"Data copy   → {copy_path}")
    print(f"Type flags  → {flags_path}")
    print()
    print(type_flags.to_string(index=False))


# ── Usage example / CLI ───────────────────────────────────────────────────────

if __name__ == '__main__':
    # Usage: python detect_data_types.py <path_to_csv>
    # Or run directly with the default files below.

    files = sys.argv[1:] if len(sys.argv) > 1 else [
        str(DATA_DIR / 'onderhoud_materieel.csv'),
        str(DATA_DIR / 'personeel_hr.csv'),
    ]

    for f in files:
        print(f"\n{'='*60}")
        print(f"Processing: {f}")
        print('='*60)
        save_outputs(f)
