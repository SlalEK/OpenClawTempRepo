# Methodology: Data Type Detection Skill

## Purpose

This skill is the first step in the AI Data Cleaning pipeline. It reads a CSV file, makes an unmodified copy of the data, and assigns each column a **semantic data type label**. The output can be used by downstream skills to filter, route, or apply type-specific cleaning logic to each column.

---

## Folder Structure

```
Defensie/
├── data/                        ← input CSV files
├── skill/
│   ├── detect_data_types.py     ← this skill
│   ├── METHODOLOGY.md           ← this file
│   └── output/                  ← generated files
│       ├── <name>_copy.csv
│       └── <name>_type_flags.csv
```

---

## Outputs

| File | Description |
|---|---|
| `<filename>_copy.csv` | Exact, unmodified copy of the input data |
| `<filename>_type_flags.csv` | One row per column: `column_name`, `detected_type` |

The flags file is intentionally minimal — it only records the type label. Statistical profiling (missing values, cardinality, etc.) is out of scope for this skill.

---

## Data Type Taxonomy

| Type | Description | Examples |
|---|---|---|
| `numerical` | Quantitative values (integer or float) | `hersteltijd_uur`, `kosten_eur` |
| `categorical` | Limited set of recurring string values | `status`, `rang`, `locatie` |
| `datetime` | Date or time values in any common format | `datum_melding`, `geboortedatum` |
| `boolean` | Binary true/false or yes/no values | checkbox columns, 0/1 flags |
| `id` | Structured identifier containing digits, may include spaces | `log_id`, `materieel_id`, `personeelsnummer` |
| `free_text` | Open-ended descriptive text | `achternaam`, `voornaam` |
| `multi_categorical` | Multiple comma-separated values drawn from a closed vocabulary | `opleiding`, `onderdelen_gebruikt` |
| `unknown` | Column contains no non-null values | — |

---

## Detection Logic

The function `detect_column_type()` applies a **waterfall of checks** in fixed priority order. The first check that matches determines the type; later checks are not evaluated.

### Step 1 — Boolean (native)
If the column's pandas dtype is `bool`, it is immediately labelled `boolean`.  
Additionally, a numeric column with exactly two unique values (`0` and `1`) is also labelled `boolean`.

### Step 2 — Numerical (native)
If pandas parsed the column as any numeric dtype (`int`, `float`, etc.), it is labelled `numerical`.

*Steps 3–6 apply only to columns with string/object dtype.*

### Step 3 — Boolean (string representation)
The unique string values (lowercased) are compared against a fixed vocabulary:

```
true, false, yes, no, ja, nee, 1, 0, y, n, x, <empty>
```

If all unique values are a subset of this vocabulary (and there are between 2 and 4 distinct values), the column is labelled `boolean`.

### Step 4 — Numerical stored as string
If ≥ 90% of the string values can be coerced to a number using `pd.to_numeric`, the column is labelled `numerical`. This handles cases where numbers were inadvertently stored as text.

### Step 5 — Datetime
Two detection attempts are made:

1. **Strict** — `pd.to_datetime()` is applied to the entire column. Handles formats like `2024-02-06`, `2020/07/02`, `28-09-2019`.
2. **Fuzzy sample** — up to 30 non-null values are parsed individually using `dateutil.parser`. If ≥ 80% of the sample parses successfully, the column is labelled `datetime`. This handles natural-language formats like `25 september 2019` or `12 mei 2014`.

### Step 6 — Multi-categorical
Detects columns that store multiple values from a closed vocabulary in a single cell, separated by commas (e.g. `"EHBO, Verkenner, CBRN basis"`).

Two conditions must both be met:
1. At least **30% of values** contain a comma
2. After splitting all values on `,` and stripping whitespace, the total number of **unique individual tokens is ≤ 200**

The token cap of 200 is intentionally generous to absorb typo variants — dirty data can produce many surface forms of a small real vocabulary (e.g. 12 real qualifications producing 140 unique tokens due to character substitutions like `3`→`e`, `1`→`i`). True free-text columns would not have a bounded token count combined with a high comma fraction.

### Step 7 — ID / Categorical / Free text
At this point the column is confirmed to be text. Four metrics are computed:

| Metric | Definition |
|---|---|
| **Cardinality** | Unique values ÷ total non-null rows |
| **ID pattern match** | Fraction of values matching `^[A-Za-z0-9\-_\. ]+$` (structured token, spaces allowed) |
| **Digit presence** | Fraction of values containing at least one digit |
| **Average string length** | Mean character length across all values |

The rules are applied in order:

1. **ID** — if cardinality ≥ 0.15 **and** ID pattern match ≥ 0.90 **and** average length ≤ 25 characters **and** digit presence ≥ 0.50 → `id`
2. **Categorical** — if cardinality ≤ 0.10 **or** fewer than 20 unique values → `categorical`
3. **Free text** — everything else → `free_text`

The digit-presence requirement is key to distinguishing IDs (e.g. `VTG 165`, `TECH-617`) from name columns (e.g. `achternaam`) which pass the pattern check but contain no digits.

---

## Tuning Parameters

All thresholds are defined as named constants at the top of the script and can be adjusted without changing the logic.

| Constant | Default | Effect |
|---|---|---|
| `CATEGORICAL_CARDINALITY_THRESHOLD` | `0.10` | Raise to classify more columns as categorical |
| `CATEGORICAL_MAX_UNIQUE` | `20` | Raise to treat wider vocabularies as categorical |
| `ID_CARDINALITY_THRESHOLD` | `0.15` | Lower to detect IDs that repeat frequently across rows |
| `ID_MAX_AVG_LENGTH` | `25` | Raise to allow longer structured identifiers |
| `ID_PATTERN_MIN_MATCH` | `0.90` | Lower to tolerate some dirty ID values |
| `ID_DIGIT_MIN_MATCH` | `0.50` | Lower to allow IDs without digits; raise to be stricter |
| `MULTI_CATEGORICAL_COMMA_MIN` | `0.30` | Raise if commas appear incidentally in non-list columns |
| `MULTI_CATEGORICAL_MAX_TOKENS` | `200` | Lower to exclude columns with very large vocabularies; set high enough to absorb typo variants |
| `DATETIME_SAMPLE_THRESHOLD` | `0.80` | Lower to be more permissive on mixed date formats |
| `DATETIME_SAMPLE_SIZE` | `30` | Raise for more reliable fuzzy date detection |

---

## Known Boundary Cases

- **`materieel_id`**: values use inconsistent casing and spacing (`VTG 144`, `Vtg-015`, `vtg038`). The ID pattern allows spaces and the digit-presence check confirms these are identifiers → `id`.
- **`technician_id`**: each technician appears in many rows, so cardinality (~18%) sits below traditional ID thresholds. With `ID_CARDINALITY_THRESHOLD = 0.15` it is correctly captured as `id`.
- **`achternaam` / `voornaam`**: surnames and first names pass the ID pattern (clean tokens) but contain no digits, so the digit-presence check correctly sends them to `free_text`.
- **`opleiding` / `onderdelen_gebruikt`**: comma-separated values from a closed vocabulary. The 12 real qualifications in `opleiding` produce 140 unique tokens due to typos (`V3rkenner`, `Verk3nner`, etc.), which is why `MULTI_CATEGORICAL_MAX_TOKENS` is set to 200 rather than a tight bound → `multi_categorical`.
- **Columns with all null values** are labelled `unknown`.
- The script does **not** modify the source data at any point. The data copy is an independent object.

---

## Usage

**Run on default files (configured in script):**
```bash
python skill/detect_data_types.py
```

**Run on a specific file:**
```bash
python skill/detect_data_types.py path/to/file.csv
```

**Use as a module in another script:**
```python
from skill.detect_data_types import flag_data_types

data_copy, type_flags = flag_data_types('data/onderhoud_materieel.csv')

# Filter to all datetime columns
datetime_cols = type_flags[type_flags['detected_type'] == 'datetime']['column_name'].tolist()
```
