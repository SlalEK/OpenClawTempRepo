"""
detect-data-types skill
-----------------------
Public API for use by downstream skills in the AI Data Cleaning pipeline.

Typical usage
-------------
    from skill import flag_data_types

    data_copy, type_flags = flag_data_types('data/onderhoud_materieel.csv')

    # Filter to all datetime columns
    datetime_cols = type_flags[type_flags['detected_type'] == 'datetime']['column_name'].tolist()
"""

from .detect_data_types import flag_data_types, detect_column_type

__all__ = ['flag_data_types', 'detect_column_type']
