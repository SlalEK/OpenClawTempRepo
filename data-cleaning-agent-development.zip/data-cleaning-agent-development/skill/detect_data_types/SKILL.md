---
name: detect-data-types
description: 'First step in the AI Data Cleaning pipeline. Reads a CSV file, makes an unmodified copy, and flags each column with a semantic data type: numerical, categorical, multi_categorical, datetime, boolean, id, or free_text. Use this skill before any cleaning, standardisation, or transformation skill. Outputs a data copy and a type-flags file to skill/output/.'
argument-hint: 'Path to a CSV file, e.g. data/onderhoud_materieel.csv'
---

# Detect Data Types

## Purpose
Assign a semantic data type label to every column in a CSV file so that downstream skills can filter, route, and apply type-specific cleaning logic.

## When to Use
- As the **first skill** before any data cleaning step
- When a new CSV is added to `data/` and its column types are unknown
- When column type assignments need to be reviewed or adjusted

## Data Type Labels

| Label | Meaning |
|---|---|
| `numerical` | Quantitative values (int or float) |
| `categorical` | Limited, recurring set of string values |
| `multi_categorical` | Comma-separated values from a closed vocabulary |
| `datetime` | Date or time values in any common format |
| `boolean` | Binary true/false or yes/no values |
| `id` | Structured identifiers containing digits |
| `free_text` | Open-ended descriptive text |
| `unknown` | Column contains no non-null values |

## Procedure

### Run on all configured files
```bash
python skill/detect_data_types.py
```

### Run on a specific file
```bash
python skill/detect_data_types.py data/my_file.csv
```

### Import in another skill
```python
from skill import flag_data_types

data_copy, type_flags = flag_data_types('data/onderhoud_materieel.csv')

# Filter to columns of a specific type
datetime_cols = type_flags[type_flags['detected_type'] == 'datetime']['column_name'].tolist()
```

## Outputs
Both files are written to `skill/output/`:

| File | Description |
|---|---|
| `<name>_copy.csv` | Unmodified copy of the input data |
| `<name>_type_flags.csv` | One row per column: `column_name`, `detected_type` |

## Dependencies
Install with:
```bash
pip install -r skill/requirements.txt
```

## References
- [Detection logic and tuning parameters](./METHODOLOGY.md)
