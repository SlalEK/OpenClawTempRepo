"""
Profile Numerical Columns Skill
---------------------------------
Reads the output of the clean_numerical skill and produces a self-contained
HTML report with per-column statistics and distribution charts.

Statistics computed per column
    count           — non-missing row count
    missing         — number and % of missing values
    zeros           — number and % of zero values
    distinct        — number of unique non-null values
    min / max       — range
    mean / median   — central tendency
    std             — standard deviation
    p05 / p25 /
    p75 / p95       — percentiles
    skewness        — direction and degree of asymmetry
    distribution    — ASCII-style histogram rendered as an SVG bar chart

Output
    <filename>_numerical_profile.html  — self-contained HTML (no external deps)
"""

import pandas as pd
import numpy as np
import math
import sys
import json
from pathlib import Path
from jinja2 import Environment, BaseLoader


# ── Folder layout ──────────────────────────────────────────────────────────────
BASE_DIR   = Path(__file__).parent
OUTPUT_DIR = BASE_DIR / 'output'
INPUT_DIR  = BASE_DIR.parent / 'clean_numerical' / 'output'


# ── Histogram helpers ────────────────────────────────────────────────────────

def _fmt_tick(v: float) -> str:
    """Format a tick value: integers shown without decimals, large values use .3g."""
    if v == int(v) and abs(v) < 1_000_000:
        return str(int(v))
    return f'{v:.3g}'


def _nice_ticks(lo: float, hi: float, n: int = 5) -> list[float]:
    """Generate ~n evenly-spaced round tick values spanning [lo, hi]."""
    if lo == hi:
        return [lo]
    span = hi - lo
    raw_step = span / max(n - 1, 1)
    magnitude = 10 ** math.floor(math.log10(abs(raw_step)))
    step = magnitude
    for nice in (1, 2, 2.5, 5, 10):
        if nice * magnitude >= raw_step:
            step = nice * magnitude
            break
    start = math.ceil(lo / step) * step
    ticks, v = [], start
    while v <= hi + step * 0.01:
        ticks.append(round(v, 10))
        v = round(v + step, 10)
    return ticks


def _histogram_data(
    series: pd.Series,
    n_bins: int = 20,
    lo: float | None = None,
    hi: float | None = None,
) -> dict:
    """Return histogram bins and x-axis ticks as {'bins': [...], 'ticks': [...]}."""
    clean = series.dropna().astype(float)
    if len(clean) == 0:
        return {'bins': [], 'ticks': []}
    actual_lo = lo if lo is not None else float(clean.min())
    actual_hi = hi if hi is not None else float(clean.max())
    if actual_lo == actual_hi:
        return {
            'bins':  [{'label': _fmt_tick(actual_lo), 'left': actual_lo,
                       'right': actual_lo, 'count': int(len(clean))}],
            'ticks': [{'x_frac': 0.5, 'label': _fmt_tick(actual_lo)}],
        }
    clipped = clean.clip(actual_lo, actual_hi)
    counts, edges = np.histogram(clipped, bins=n_bins, range=(actual_lo, actual_hi))
    bins = [
        {
            'label': f'{_fmt_tick(edges[i])}–{_fmt_tick(edges[i+1])}',
            'left':  float(edges[i]),
            'right': float(edges[i + 1]),
            'count': int(counts[i]),
        }
        for i in range(len(counts))
    ]
    span = actual_hi - actual_lo
    ticks = [
        {
            'x_frac': round(min(1.0, max(0.0, (v - actual_lo) / span)), 6),
            'label':  _fmt_tick(v),
        }
        for v in _nice_ticks(actual_lo, actual_hi, n=5)
        if actual_lo - span * 0.001 <= v <= actual_hi + span * 0.001
    ]
    return {'bins': bins, 'ticks': ticks}


def _histogram_zoom(series: pd.Series, clean: pd.Series) -> tuple[dict, str] | None:
    """
    Return an IQR×3-fenced histogram and a label string, or None.

    Computes the inner fence (q25 - 3×IQR, q75 + 3×IQR), clamps to the
    actual data range, and only returns a zoom chart when the fenced range
    is less than 60 % of the full range (i.e. outliers meaningfully compress
    the full distribution).
    """
    if len(clean) < 4:
        return None
    q25 = float(clean.quantile(0.25))
    q75 = float(clean.quantile(0.75))
    iqr = q75 - q25
    if iqr == 0:
        return None
    lo = max(q25 - 3 * iqr, float(clean.min()))
    hi = min(q75 + 3 * iqr, float(clean.max()))
    full_range = float(clean.max()) - float(clean.min())
    zoom_range = hi - lo
    if full_range == 0 or zoom_range / full_range > 0.60:
        return None
    label = f'Core distribution (outliers clipped — {_fmt_tick(lo)}–{_fmt_tick(hi)})'
    return _histogram_data(series, lo=lo, hi=hi), label


# ── Per-column stats ───────────────────────────────────────────────────────────

def _profile_column(col: str, series: pd.Series) -> dict:
    """Compute all statistics for a single column."""
    n_total   = len(series)
    n_missing = int(series.isna().sum())
    n_valid   = n_total - n_missing

    clean = series.dropna().astype(float)

    if n_valid == 0:
        return {
            'column':    col,
            'dtype':     str(series.dtype),
            'count':     0,
            'missing_n': n_missing,
            'missing_p': 100.0,
            'zeros_n':   0,
            'zeros_p':   0.0,
            'distinct':  0,
            'min': None, 'max': None,
            'mean': None, 'median': None, 'std': None,
            'p05': None, 'p25': None, 'p75': None, 'p95': None,
            'skewness': None,
            'histogram': {'bins': [], 'ticks': []},
            'histogram_zoom': None,
            'histogram_zoom_label': None,
        }

    zeros_n = int((clean == 0).sum())

    result = {
        'column':    col,
        'dtype':     str(series.dtype),
        'count':     n_valid,
        'missing_n': n_missing,
        'missing_p': round(n_missing / n_total * 100, 2),
        'zeros_n':   zeros_n,
        'zeros_p':   round(zeros_n / n_valid * 100, 2),
        'distinct':  int(clean.nunique()),
        'min':       round(float(clean.min()), 4),
        'max':       round(float(clean.max()), 4),
        'mean':      round(float(clean.mean()), 4),
        'median':    round(float(clean.median()), 4),
        'std':       round(float(clean.std()), 4),
        'p05':       round(float(clean.quantile(0.05)), 4),
        'p25':       round(float(clean.quantile(0.25)), 4),
        'p75':       round(float(clean.quantile(0.75)), 4),
        'p95':       round(float(clean.quantile(0.95)), 4),
        'skewness':  round(float(clean.skew()), 4),
        'histogram': _histogram_data(series),
    }
    zoom_result = _histogram_zoom(series, clean)
    if zoom_result:
        result['histogram_zoom'], result['histogram_zoom_label'] = zoom_result
    else:
        result['histogram_zoom'] = None
        result['histogram_zoom_label'] = None
    return result


def profile_numerical(cleaned_path: str) -> list[dict]:
    """Load a cleaned numerical CSV and return a list of per-column stat dicts."""
    df = pd.read_csv(cleaned_path)
    return [_profile_column(col, df[col]) for col in df.columns]


# ── HTML report ────────────────────────────────────────────────────────────────

_HTML_TEMPLATE = r"""
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Numerical Profile — {{ stem }}</title>
<style>
  *, *::before, *::after { box-sizing: border-box; }
  body {
    font-family: 'Segoe UI', Arial, sans-serif;
    font-size: 14px;
    background: #f5f6fa;
    color: #222;
    margin: 0;
    padding: 24px 32px;
  }
  h1 { font-size: 1.5rem; margin-bottom: 4px; color: #1a1a2e; }
  .subtitle { color: #666; margin-bottom: 32px; font-size: 0.9rem; }
  .grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(520px, 1fr));
    gap: 24px;
  }
  .card {
    background: #fff;
    border-radius: 10px;
    box-shadow: 0 1px 4px rgba(0,0,0,.10);
    padding: 20px 24px;
    overflow: hidden;
  }
  .card-title {
    font-size: 1rem;
    font-weight: 600;
    color: #1a1a2e;
    margin-bottom: 2px;
  }
  .dtype-badge {
    display: inline-block;
    background: #e8eaf6;
    color: #3949ab;
    font-size: 0.72rem;
    padding: 1px 7px;
    border-radius: 10px;
    margin-bottom: 14px;
    font-family: monospace;
  }
  .stats-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 8px 12px;
    margin-bottom: 16px;
  }
  .stat {
    background: #f8f9ff;
    border-radius: 6px;
    padding: 7px 10px;
  }
  .stat-label {
    font-size: 0.68rem;
    color: #888;
    text-transform: uppercase;
    letter-spacing: .03em;
    margin-bottom: 2px;
  }
  .stat-value {
    font-size: 0.92rem;
    font-weight: 600;
    color: #1a1a2e;
  }
  .stat-value.warn { color: #e65100; }
  .stat-value.zero-warn { color: #b8860b; }
  .section-label {
    font-size: 0.72rem;
    color: #aaa;
    text-transform: uppercase;
    letter-spacing: .05em;
    margin: 14px 0 6px;
  }
  /* distribution chart */
  .chart-wrap { width: 100%; overflow-x: auto; margin-bottom: 4px; }
  svg.hist { display: block; width: 100%; }
  .bar rect { transition: opacity .15s; }
  .bar rect:hover { opacity: .7; }
  .axis-label { font-size: 9px; fill: #888; }
  .tick-line { stroke: #ddd; stroke-width: 1; }
  .bar-count  { font-size: 8.5px; fill: #fff; text-anchor: middle; }
  /* missing bar */
  .missing-bar-wrap { display: flex; align-items: center; gap: 8px; margin-top: 4px; }
  .missing-bar-bg {
    flex: 1; height: 8px; background: #e0e0e0; border-radius: 4px; overflow: hidden;
  }
  .missing-bar-fill {
    height: 100%; border-radius: 4px;
    background: #66bb6a;
  }
  .missing-pct { font-size: 0.8rem; font-weight: 600; min-width: 40px; text-align: right; }
</style>
</head>
<body>
<h1>Numerical Profile — {{ stem }}</h1>
<div class="subtitle">
  Source: {{ source_file }} &nbsp;·&nbsp;
  {{ n_rows }} rows &nbsp;·&nbsp;
  {{ n_cols }} column{{ 's' if n_cols != 1 else '' }} &nbsp;·&nbsp;
  Generated {{ generated }}
</div>

{% macro render_hist(hist, bar_color, label) %}
{% if hist and hist.bins %}
<div class="section-label">{{ label }}</div>
<div class="chart-wrap">
  {% set bins = hist.bins %}
  {% set max_count = bins | map(attribute='count') | max %}
  {% set chart_w = 472 %}
  {% set chart_h = 90 %}
  {% set bar_w = (chart_w / bins|length) - 1 %}
  <svg class="hist" viewBox="0 0 {{ chart_w }} {{ chart_h + 26 }}" xmlns="http://www.w3.org/2000/svg">
    {% for bin in bins %}
      {% set bar_h = (bin.count / max_count * chart_h) if max_count > 0 else 0 %}
      {% set x = loop.index0 * (bar_w + 1) %}
      <g class="bar">
        <rect x="{{ x }}" y="{{ chart_h - bar_h }}"
              width="{{ bar_w }}" height="{{ bar_h }}"
              fill="{{ bar_color }}" rx="1">
          <title>{{ bin.label }}: {{ bin.count }}</title>
        </rect>
        {% if bar_h > 14 %}
        <text class="bar-count"
              x="{{ x + bar_w / 2 }}"
              y="{{ chart_h - bar_h + 11 }}">{{ bin.count }}</text>
        {% endif %}
      </g>
    {% endfor %}
    {% for tick in hist.ticks %}
      {% set tx = tick.x_frac * chart_w %}
      <line class="tick-line" x1="{{ tx }}" y1="{{ chart_h }}" x2="{{ tx }}" y2="{{ chart_h + 5 }}"/>
      <text class="axis-label"
            x="{{ tx }}"
            y="{{ chart_h + 18 }}"
            text-anchor="{{ 'start' if tick.x_frac < 0.1 else ('end' if tick.x_frac > 0.9 else 'middle') }}">
        {{ tick.label }}
      </text>
    {% endfor %}
  </svg>
</div>
{% endif %}
{% endmacro %}

<div class="grid">
{% for col in columns %}
<div class="card">
  <div class="card-title">{{ col.column }}</div>
  <span class="dtype-badge">{{ col.dtype }}</span>

  <div class="stats-grid">
    <div class="stat">
      <div class="stat-label">Count</div>
      <div class="stat-value">{{ col.count }}</div>
    </div>
    <div class="stat">
      <div class="stat-label">Distinct</div>
      <div class="stat-value">{{ col.distinct }}</div>
    </div>
    <div class="stat">
      <div class="stat-label">Min</div>
      <div class="stat-value">{{ col.min if col.min is not none else '—' }}</div>
    </div>
    <div class="stat">
      <div class="stat-label">Max</div>
      <div class="stat-value">{{ col.max if col.max is not none else '—' }}</div>
    </div>
    <div class="stat">
      <div class="stat-label">Mean</div>
      <div class="stat-value">{{ col.mean if col.mean is not none else '—' }}</div>
    </div>
    <div class="stat">
      <div class="stat-label">Median</div>
      <div class="stat-value">{{ col.median if col.median is not none else '—' }}</div>
    </div>
    <div class="stat">
      <div class="stat-label">Std Dev</div>
      <div class="stat-value">{{ col.std if col.std is not none else '—' }}</div>
    </div>
    <div class="stat">
      <div class="stat-label">Skewness</div>
      <div class="stat-value">{{ col.skewness if col.skewness is not none else '—' }}</div>
    </div>
    <div class="stat">
      <div class="stat-label">p05</div>
      <div class="stat-value">{{ col.p05 if col.p05 is not none else '—' }}</div>
    </div>
    <div class="stat">
      <div class="stat-label">p25</div>
      <div class="stat-value">{{ col.p25 if col.p25 is not none else '—' }}</div>
    </div>
    <div class="stat">
      <div class="stat-label">p75</div>
      <div class="stat-value">{{ col.p75 if col.p75 is not none else '—' }}</div>
    </div>
    <div class="stat">
      <div class="stat-label">p95</div>
      <div class="stat-value">{{ col.p95 if col.p95 is not none else '—' }}</div>
    </div>
  </div>

  <!-- Missing values bar -->
  <div class="section-label">Missing values</div>
  <div class="missing-bar-wrap">
    <div class="missing-bar-bg">
      <div class="missing-bar-fill"
           style="width: {{ [col.missing_p, 100]|min }}%;
                  background: {{ '#ef5350' if col.missing_p > 20 else ('#ffa726' if col.missing_p > 5 else '#66bb6a') }};">
      </div>
    </div>
    <span class="missing-pct
          {{ ' warn' if col.missing_p > 20 else '' }}">
      {{ col.missing_n }} ({{ col.missing_p }}%)
    </span>
  </div>

  <!-- Zeros bar -->
  <div class="section-label">Zero values</div>
  <div class="missing-bar-wrap">
    <div class="missing-bar-bg">
      <div class="missing-bar-fill"
           style="width: {{ [col.zeros_p, 100]|min }}%;
                  background: #b8860b;">
      </div>
    </div>
    <span class="missing-pct">{{ col.zeros_n }} ({{ col.zeros_p }}%)</span>
  </div>

  <!-- Distribution histograms -->
  {{ render_hist(col.histogram, '#5c6bc0', 'Distribution (full range)') }}
  {% if col.histogram_zoom %}
  {{ render_hist(col.histogram_zoom, '#26a69a', col.histogram_zoom_label) }}
  {% endif %}

</div>
{% endfor %}
</div>
</body>
</html>
"""


def render_html(stem: str, columns: list[dict], source_file: str, n_rows: int) -> str:
    """Render the Jinja2 template to an HTML string."""
    from datetime import datetime
    env = Environment(loader=BaseLoader(), autoescape=False)
    tmpl = env.from_string(_HTML_TEMPLATE)
    return tmpl.render(
        stem=stem,
        columns=columns,
        source_file=source_file,
        n_rows=n_rows,
        n_cols=len(columns),
        generated=datetime.now().strftime('%Y-%m-%d %H:%M'),
    )


# ── Main pipeline ──────────────────────────────────────────────────────────────

def save_report(stem: str) -> None:
    """Build and save the HTML profile report for one dataset stem."""
    input_path = INPUT_DIR / f'{stem}_numerical_cleaned.csv'

    if not input_path.exists():
        print(f'  [skip] {stem}: cleaned file not found at {input_path}')
        return

    print(f'\n{"=" * 60}')
    print(f'Profiling: {stem}')
    print('=' * 60)

    columns  = profile_numerical(str(input_path))
    n_rows   = pd.read_csv(input_path).shape[0]
    html     = render_html(stem, columns, input_path.name, n_rows)

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    out_path = OUTPUT_DIR / f'{stem}_numerical_profile.html'
    out_path.write_text(html, encoding='utf-8')

    print(f'Report      → {out_path}')
    print(f'Columns     : {len(columns)}')
    for col in columns:
        print(f'  {col["column"]:<30} '
              f'count={col["count"]}  '
              f'missing={col["missing_n"]} ({col["missing_p"]}%)  '
              f'zeros={col["zeros_n"]}  '
              f'mean={col["mean"]}  '
              f'std={col["std"]}')


if __name__ == '__main__':
    stems = sys.argv[1:] if len(sys.argv) > 1 else [
        'onderhoud_materieel',
        'personeel_hr',
    ]
    for stem in stems:
        save_report(stem)
