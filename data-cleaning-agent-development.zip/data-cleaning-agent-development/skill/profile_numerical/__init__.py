"""
profile-numerical skill — public API for downstream skills.

Usage
-----
    from skill.profile_numerical import profile_numerical

    columns = profile_numerical(
        'skill/clean_numerical/output/onderhoud_materieel_numerical_cleaned.csv'
    )
"""

from .profile_numerical import profile_numerical, render_html, save_report

__all__ = ['profile_numerical', 'render_html', 'save_report']
