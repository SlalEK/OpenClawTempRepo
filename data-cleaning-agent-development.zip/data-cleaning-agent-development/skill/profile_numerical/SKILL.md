---
name: profile-numerical
description: 'Fourth step in the AI Data Cleaning pipeline, runs after clean-numerical. Reads the cleaned numerical CSV and produces a self-contained HTML report with per-column statistics (count, missing, zeros, min/max, mean/median, std, skewness, percentiles p05/p25/p75/p95, distinct values), a full-range SVG histogram, and — when outliers significantly compress the visible distribution — a second IQR×3-fenced zoom histogram showing the core distribution. No external dependencies are required to open the report.'
argument-hint: 'Dataset stem name, e.g. onderhoud_materieel'
---

# Profile Numerical Columns

## Purpose
Generate a human-readable quality and statistics report for all cleaned numerical columns, so analysts can quickly identify data issues (high missingness, suspicious zeros, skewed distributions, extreme outliers) before modelling or further transformation.

## Prerequisites
The `clean-numerical` skill must have been run first. This skill reads its output from `skill/clean_numerical/output/`.

## What It Does
1. **Load** — reads `<name>_numerical_cleaned.csv` from the clean_numerical output folder
2. **Profile each column** — computes count, missing n/%, zero n/%, distinct, min, max, mean, median, std, skewness, and percentiles p05/p25/p75/p95
3. **Build full-range distribution** — bins each column into 20 equal-width bins over the full `[min, max]` range
4. **Build zoom distribution** — if outliers compress the visible distribution (fenced range < 60 % of full range), compute a second histogram clipped to the IQR × 3 inner fence; otherwise no zoom chart is shown
5. **Render HTML** — produces a self-contained report (no internet required) with one card per column, colour-coded missing/zero bars, ~5-tick x-axis labels, and SVG histograms

## Procedure

### Run on all configured datasets
```bash
python skill/profile_numerical/profile_numerical.py
```

### Run on a specific dataset
```bash
python skill/profile_numerical/profile_numerical.py onderhoud_materieel
```

### Import in another skill
```python
from skill.profile_numerical import profile_numerical, render_html

columns = profile_numerical(
    'skill/clean_numerical/output/onderhoud_materieel_numerical_cleaned.csv'
)
html = render_html('onderhoud_materieel', columns, source_file='...', n_rows=5250)
```

## Inputs
Read from `skill/clean_numerical/output/`:

| File | Description |
|---|---|
| `<name>_numerical_cleaned.csv` | Cleaned numerical columns from clean_numerical |

## Output
Written to `skill/profile_numerical/output/`:

| File | Description |
|---|---|
| `<name>_numerical_profile.html` | Self-contained HTML quality report |

## Reading the Report

| Visual element | What to look for |
|---|---|
| Missing bar — green | ≤5% missing — acceptable |
| Missing bar — amber | 5–20% missing — investigate source |
| Missing bar — red | >20% missing — column may be unreliable |
| Zeros bar | High zero % for `price` or `duration` columns suggests sentinel values; for `count` columns it is often structurally valid |
| Skewness | Values >2 or <−2 indicate a heavily skewed distribution; consider log-transform |
| Full-range histogram (indigo) | Shows complete data extent; isolated far-right spike — likely sentinel (e.g. 9999) |
| Zoom histogram (teal) | Only shown when outliers compress the full-range view; clip bounds in the title show what was excluded. Reveals the true shape of the core distribution |

## Dependencies
```bash
pip install -r skill/profile_numerical/requirements.txt
```

## References
- [Statistical methodology and metric definitions](./METHODOLOGY.md)
